<template>

  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="80px" class="demo-ruleForm"
           style="margin:20px;width:80%;min-width:600px;" v-loading="addloading">

    <el-form-item label="选择时间"  prop="value4" label-width="100px">
      <el-time-picker
        is-range
        v-model="ruleForm2.value4"
        range-separator="至"
        start-placeholder="开始时间"
        end-placeholder="结束时间"
        placeholder="选择时间范围">
      </el-time-picker>
    </el-form-item>


    <el-form-item label="签到(签退)"  prop="is_open"  label-width="100px" >
      <el-radio v-model="ruleForm2.is_open" :label="'SignIn'" >签到</el-radio>
      <el-radio v-model="ruleForm2.is_open" :label="'SignOut'">签退</el-radio>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
  import {addTime} from '../../api/signIn'
  export default {
    data() {
      return {
        addloading:false,
        ruleForm2: {
          start_time: '',
          value4:'',
          end_time: '',
          is_open: "",
          token:localStorage.getItem('token'),
        },
        rules2: {
          start_time: [
            {required: true, message: '请输开始时间', trigger: 'blur'}
          ],
          end_time: [
            {required: true, message: '请输结束时间', trigger: 'blur'}
          ],
          value4:[{required: true, message: '请选择时间', trigger: 'blur'}],
          is_open: [
            {required: true, message: '请输签到或是签退', trigger: 'blur'}
          ],
        },
      };
    },

    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {

            this.ruleForm2.start_time=this.ruleForm2.value4[0];
             this.ruleForm2.end_time=this.ruleForm2.value4[1];
             var h=this.ruleForm2.start_time.getHours();
             var m=this.ruleForm2.start_time.getMinutes();
             var s=this.ruleForm2.start_time.getSeconds();
            var h1=this.ruleForm2.end_time.getHours();
            var m1=this.ruleForm2.end_time.getMinutes();
            var s1=this.ruleForm2.end_time.getSeconds();
            if(h<10){
                h='0'+h
            }
            if(m<10){
              m='0'+m
            }
            if(s<10){
              s='0'+s
            }

            if(h1<10){
              h1='0'+h1
            }
            if(m1<10){
              m1='0'+m1
            }
            if(s1<10){
              s1='0'+s1
            }
            let para = {
              start_time: h+':'+m+':'+s,
              end_time: h1+':'+m1+':'+s1,
              type_code: this.ruleForm2.is_open,
              token:this.ruleForm2.token,
            };

            this.addloading=true;
            addTime(para).then(response => {
              this.addloading=false;
              this.$router.push({path: '/sign'});
            }).catch(err => {
                setTimeout(() => {
                  this.addloading = false;
                }, 2000);
            });
          } else {
            this.$message.error('提交失败');
            return false;
          }
        });
      },
    },

  }
</script>
<style>
  .el-form-item__content {
    line-height: 50px;
    position: relative;
    font-size: 14px;
  }

</style>
