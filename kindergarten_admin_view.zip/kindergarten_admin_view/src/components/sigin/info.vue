<template>
  <section>
    <!--工具条-->
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true">
        <el-form-item style="float: right">
          <el-button type="primary" @click="goAddPath()">添加</el-button>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <h1>签到时间信息</h1>
    <el-card class="box-card" >
      <el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="50" label="ID">
        </el-table-column>
        <el-table-column prop="start_time" width="600" label="开始时间">
        </el-table-column>

        <el-table-column prop="end_time" width="600" label="结束时间">
        </el-table-column>



        <el-table-column label="操作" min-width="450" fixed="right">
          <template scope="scope">

            <el-button type="danger" size="small" @click="deleteRobot(scope.row)">删除</el-button>
            <el-button type="warning" size="small" @click="editSign(scope.row)">修改</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>


    <!--列表-->
    <h1>签退时间信息</h1>
    <el-card class="box-card" >
      <el-table :data="tableData1" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="50" label="ID">
        </el-table-column>

        <el-table-column prop="start_time" width="600" label="开始时间">
        </el-table-column>

        <el-table-column prop="end_time" width="600" label="结束时间">
        </el-table-column>
        <el-table-column label="操作" min-width="450" fixed="right">
          <template scope="scope">
            <el-button type="danger" size="small" @click="deleteRobot(scope.row)">删除</el-button>
            <el-button type="warning" size="small" @click="editSign(scope.row)">修改</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

  </section>
</template>
<script>
  import {signOutTime} from '../../api/signIn';
  import {signInTime} from '../../api/signIn';
  import {deleteTime} from '../../api/signIn'
  import util from '../../api/util'
  export default {
    data() {
      return {
        tableData: [],
        tableData1:[],
        loading:false,
        token:localStorage.getItem('token'),
      }
    },
    methods: {
      //跳转到添加页面
      goAddPath(){
        this.$router.push({path:'/add_sign'});
      },
      //跳转到修改页面
      editSign(row){
        this.$router.push({path:'/edit_sign',query: {sid: row.id}});
      },
      //得到分页信息
      signInInfo(){
        let para = {
          token:this.token,
        };
        this.loading=true;
        signInTime(para).then(response => {
          this.tableData=response.data;

          this.loading=false;
        });
      },
      //得到签退
      signInInfo1(){
        let para = {
          token:this.token,
        };
        this.loading=true;
        signOutTime(para).then(response => {
          this.tableData1=response.data;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading = false;
          }, 2000);
        });;
      },
      //解绑机器人
      deleteRobot(row){
        this.$confirm('确认解绑机器人吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.loading=true;
          deleteTime(row.id).then(response => {
            this.$message({
              message: '删除成功',
              type: 'success'
            });
            this.loading=false;
            this.signInInfo();
            this.signInInfo1();
          });
        }).catch(() => {
            setTimeout(() => {
              this.editloading = false;
            }, 2000);
        });
      }
    },
    mounted() {
      this.signInInfo();
      this.signInInfo1();
    }
  }
</script>
<style>

</style>

