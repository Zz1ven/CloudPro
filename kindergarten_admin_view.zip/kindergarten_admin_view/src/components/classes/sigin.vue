<template>
  <section>
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true">
        <el-form-item style="float: right">
          <el-form-item label-width="100px" label="选择日期">
            <div class="block">
              <el-date-picker
                v-model="value1"
                type="date"
                placeholder="选择日期"
                value-format="yyyy-MM-dd">
              </el-date-picker>
            </div>
          </el-form-item>

          <el-form-item label-width="100px" label="开始时间">
            <el-select v-model="value2" placeholder="请选择">
              <el-option
                v-for="item in options"
                :key="item.start_time"
                :label="item.start_time"
                :value="item.start_time">
              </el-option>
            </el-select>
          </el-form-item>

          <el-form-item label-width="100px" label="结束时间">
            <el-select v-model="value3" placeholder="请选择">
              <el-option
                v-for="item in options"
                :key="item.end_time"
                :label="item.end_time"
                :value="item.end_time">
              </el-option>
            </el-select>
          </el-form-item>

          <el-form-item label-width="100px">
            <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
          </el-form-item>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <h1>已签到</h1>
    <h1>人数：{{tableData.inSigntotal}}</h1>

    <el-card class="box-card">
      <el-table :data="tableData.inSignStudent" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="100" label="ID">
        </el-table-column>
        <el-table-column prop="name" label="名称" width="200">
        </el-table-column>

        <el-table-column prop="img" label="头像" min-width="200">
          <template scope="scope">
            <img :src="scope.row.img" style="width: 120px;height: 120px" v-if="scope.row.img!=null">
          </template>
        </el-table-column>

        <el-table-column prop="sex" label="性别" width="100">
        </el-table-column>

        <el-table-column prop="age" label="年龄" width="100">
        </el-table-column>

        <el-table-column prop="classes_id" label="班级id" min-width="150">

        </el-table-column>


        <el-table-column prop="time" label="时间" width="150" :formatter="setTime">
        </el-table-column>

        <!-- <el-table-column label="操作" min-width="450" fixed="right">
           <template scope="scope">
             <el-button size="small" @click="edit(scope.row)">修改</el-button>
             <el-button type="danger" size="small"  @click="deleteStudent(scope.row)">删除</el-button>
             <el-button type="primary" size="small"  @click="genearch(scope.row)">与家长绑定</el-button>
             <el-button type="danger" size="small"  @click="deleteGenearch(scope.row)">与家长解绑</el-button>
           </template>
         </el-table-column>-->
      </el-table>
    </el-card>


    <h1>未签到</h1>
    <el-card class="box-card">
      <el-table :data="tableData.noSignStudent" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="100" label="ID">
        </el-table-column>
        <el-table-column prop="name" label="名称" width="200">
        </el-table-column>

        <el-table-column prop="img" label="头像" min-width="200">
          <template scope="scope">
            <img :src="scope.row.img" style="width: 120px;height: 120px" v-if="scope.row.img!=null">
          </template>
        </el-table-column>

        <el-table-column prop="sex" label="性别" width="100">
        </el-table-column>

        <el-table-column prop="age" label="年龄" width="100">
        </el-table-column>

        <el-table-column prop="classes_id" label="班级id" min-width="150">

        </el-table-column>


        <el-table-column prop="time" label="时间" width="150" :formatter="setTime">
        </el-table-column>

        <!--<el-table-column label="操作" min-width="450" fixed="right">
          <template scope="scope">
            <el-button size="small" @click="edit(scope.row)">修改</el-button>
            <el-button type="danger" size="small"  @click="deleteStudent(scope.row)">删除</el-button>
            <el-button type="primary" size="small"  @click="genearch(scope.row)">与家长绑定</el-button>
            <el-button type="danger" size="small"  @click="deleteGenearch(scope.row)">与家长解绑</el-button>
          </template>
        </el-table-column>-->
      </el-table>
    </el-card>


  </section>
</template>
<script>
  import {getSignByCid} from '../../api/classes';
  import {signAllTimePage} from '../../api/signIn';
  import util from '../../api/util';
  export default {
    data() {
      return {
        value1: '',
        value2: '',
        value3:'',
        options: [],
        loading: false,
        tableData: [],
      };
    },

    methods: {
      //提交修改
      submitForm(formName) {
          if(this.value1==''||this.value1==null){
            this.$message({
              message: '请输入日期',
              type: 'warning'
            });
            return;
          }
        let para = {
          token: localStorage.getItem('token'),
          //把时间转换成时间戳
          startTime: Date.parse(new Date(this.value1+" "+this.value2)),
          endTime: Date.parse(new Date(this.value1+" "+this.value3)),
        };
        console.log(this.value1+" "+this.value2)
        this.editloading = true;
        getSignByCid(this.$route.query.cid, para).then(response => {
          this.editloading = false;
          this.tableData = response.data;
        }).catch(() => {
          setTimeout(() => {
            this.editloading = false;
          }, 2000);
        });
      },

      //时间显示转换
      setTime(row, column){
        return util.formatDate.setTime(row.time);
      },

      getSingInTime(){
        let para = {
          token:localStorage.getItem('token'),
        };
        this.editloading =true;
        signAllTimePage(para).then(response => {
          this.editloading = false;
          this.options=response.data;
        }).catch(() => {
          setTimeout(() => {
            this.editloading = false;
          }, 2000);
        });
      },

    },
    created() {
      this.getSingInTime();
    }

  }
</script>
<style>

</style>

