<template>
  <section>
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true">
        <el-form-item style="float: right">
          <el-button type="primary" @click="goAddPath()">添加机器人</el-button>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <el-card class="box-card" >
      <el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="200" label="ID">
        </el-table-column>

        <el-table-column prop="robot_number" label="机器人编号" width="600">
        </el-table-column>


        <el-table-column prop="time" label="时间"  :formatter="setTime" width="600">
        </el-table-column>

        <el-table-column label="操作" min-width="550" >
          <template scope="scope">
            <el-button type="danger" size="small" @click="deleteRobot(scope.row)">解绑机器人</el-button>

          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          @current-change="handleCurrentChange"
          :page-size="pageSize"
          :current-page.sync="page"
          layout="prev, pager, next,jumper"
          :total="total" style="float:right;">
        </el-pagination>
      </div>
    </el-card>

  </section>
</template>
<script>
  import {getRobotByTokenAndCid} from '../../api/robot'
  import {deleteClassesRobotByTokenAndCid} from '../../api/robot'
  import util from '../../api/util'
  export default {
    data() {
      return {
        total: 0,
        page: 1,
        pageSize: 10,
        tableData: [],
        loading:false,
      }
    },
    methods: {
      //跳转到绑定机器人
      goAddPath(){
        this.$router.push({path:'/robot_add',query: {classes_id: this.$route.query.cid}});
      },

      //时间显示转换
      setTime(row, column){
          return util.formatDate.setTime(row.time);
      },

      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
        this.page = val;
        this.robotInfo();
      },
      //得到分页信息
      robotInfo(){
        let para = {
          offset:(this.page-1)*(this.pageSize),
          pageSize:this.pageSize,
          token:localStorage.getItem('token')
        };
        this.loading=true;
        getRobotByTokenAndCid(this.$route.query.cid,para).then(response => {
          this.total=response.data.total;
          this.tableData=response.data.item;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading=false;
          }, 2000);
        });
      },
      //解绑班级下的机器人
      deleteRobot(row){
        let para = {
          token:localStorage.getItem('token')
        };
        this.$confirm('确认解绑机器人吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.loading=true;
          deleteClassesRobotByTokenAndCid(this.$route.query.cid,row.robot_number,para).then(response => {
            this.$message({
              message: '解绑成功',
              type: 'success'
            });
            this.loading=false;
            this.robotInfo();
          });
        }).catch(() => {
            setTimeout(() => {
              this.loading=false;
            }, 2000);
        });
      }
    },
    mounted() {
      this.robotInfo();
    }
  }
</script>
<style>

</style>
