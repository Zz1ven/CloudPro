
<template>
  <el-form :model="ruleForm2" status-icon  ref="ruleForm2" label-width="120px" class="demo-ruleForm"
           style="margin:30px;width:80%;min-width:600px;" v-loading="loading">



    <el-form-item label="选中机器人" prop="robot_number" :rules="[
      { required: true, message: '机器人不能为空'},
    ]">
      <el-input v-model="ruleForm2.robot_number" auto-complete="off" placeholder="请输入内容" @focus="dialogVisible = true"></el-input>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </el-form-item>

    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      width="80%"
      :before-close="handleClose">
        <span>
          <app-robot  v-on:getRobot="getRobotNumber"></app-robot>
        </span>
      <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
    </span>
    </el-dialog>
  </el-form>


</template>

<script>
 import {createClassesRobotByTokenAndCid} from '../../api/robot'
  import AppRobot  from '../../components/classes/app_robot.vue'
  export default {
    data() {

      return {
        dialogVisible:false,
        loading:false,
        ruleForm2: {
          value2: '',
          robot_number:''
        },

      };
    },
    components: {
      AppRobot,
    },
    methods: {
      //从子组件传过来的值
      getRobotNumber(data){
        this.ruleForm2.robot_number=data;
        this.dialogVisible=false;
      },
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let para = {
              token:localStorage.getItem('token'),
            };
            this.loading=true;
            createClassesRobotByTokenAndCid(this.$route.query.classes_id,this.ruleForm2.robot_number,para).then(response => {
              this.loading=false;
              this.$router.push({path:'/classes_robot', query: {cid: this.$route.query.classes_id}});
            }).catch(() => {
              setTimeout(() => {
                this.loading=false;
              }, 2000);
            });
          } else {
            this.$message.error('提交失败');
            return false;
          }
        });
      },
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
      }
    }
  }
</script>

<style>
  .el-form-item__content {
    line-height: 50px;
    position: relative;
    font-size: 14px;
  }

</style>
