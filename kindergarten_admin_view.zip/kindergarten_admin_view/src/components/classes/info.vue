<template>
  <section>
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true">
        <el-form-item style="float: right">
          <el-button type="primary" @click="goAddPath()">添加班级</el-button>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->

      <!--<el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="100" label="ID">
        </el-table-column>
        <el-table-column prop="name" label="名称" width="300">
        </el-table-column>

        <el-table-column prop="robot_group_id" label="GroupId" min-width="150">
      </el-table-column>

        <el-table-column prop="jpush_group_id" label="极光群聊组ID" min-width="150">
        </el-table-column>

        <el-table-column prop="faceset" label="人脸组" min-width="350">
      </el-table-column>

        <el-table-column prop="student_count" label="学生数量" min-width="100">
        </el-table-column>

        <el-table-column prop="robot_count" label="机器人数量" min-width="100">
        </el-table-column>

        <el-table-column prop="remark" label="备注" min-width="150">
          <template scope="scope">
            <el-button size="small" type="success" @click="dialog(scope.row)">查看备注</el-button>
          </template>
        </el-table-column>


        <el-table-column prop="time" label="时间" width="150" :formatter="setTime">
        </el-table-column>

        <el-table-column label="操作" min-width="730" fixed="right">
          <template scope="scope">
            <el-button size="small" @click="edit(scope.row)">修改</el-button>
            <el-button type="danger" size="small" :disabled="scope.row.student_count!=0||scope.row.robot_count!=0" @click="delete_classes(scope.row)">删除</el-button>
            <el-button type="info" size="small" @click="getRobot(scope.row)">班级下的机器人</el-button>
            <el-button type="info" size="small" @click="getStudent(scope.row)">班级下的学生</el-button>
            <el-button type="info" size="small" @click="getSign(scope.row)">签到记录</el-button>
            <el-button type="primary" size="small" @click="getGenearch(scope.row)">家长账户</el-button>
            <!--<el-button type="primary" size="small" @click="getLive(scope.row)">班级下直播机器人</el-button>-->
          <!--</template>
        </el-table-column>
      </el-table> -->


      <el-col :span="6" v-for="(classes, index) in tableData" :key="o"  style="padding-left: 20px;padding-top: 20px">
        <el-card :body-style="{ padding: '20px' }" >
          <div class="thumbnail" style="width: 500px">

            <div class="caption" style="padding-left: 30px">
              <h1>班级ID:{{classes.id}}</h1>
              <h1>名称:{{classes.name}}</h1>
              <h1>学生数量:{{classes.student_count}}</h1>
              <h1>机器人数量:{{classes.robot_count}}</h1>
             <h1><el-button size="small" type="success" @click="dialog(classes.remark)">查看备注</el-button></h1>
            </div>
          </div>
   <div style="width: 100%;padding-left: 30px" >

          <el-button size="small" @click="edit(classes.id)">修改</el-button>
          <el-button type="danger" size="small" :disabled="classes.student_count!=0||classes.robot_count!=0" @click="delete_classes(classes.id)">删除</el-button>
          <el-button type="info" size="small" @click="getRobot(classes.id)">班级下的机器人</el-button>
          <el-button type="info" size="small" @click="getStudent(classes.id)">班级下的学生</el-button>
     <div style="padding-top: 10px">
          <el-button type="info" size="small" @click="getSign(classes.id)">签到记录</el-button>
       <el-button type="primary" size="small" @click="getNotice(classes.id)">推送班级通知</el-button>
     </div>
  </div>
        </el-card>
      </el-col>

    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      width="100%"
      :before-close="handleClose">
      <span v-html="guide"></span>
      <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
    </span>
    </el-dialog>

    <div class="block" style="padding-bottom: 500px">
      <el-pagination
        @current-change="handleCurrentChange"
        :page-size="pageSize"
        :current-page.sync="page"
        layout="prev, pager, next,jumper"
        :total="total" style="float:right;">
      </el-pagination>
    </div>
  </section>


</template>
<script>
  import {getClassesByToken} from '../../api/classes'
  import {deleteClasses} from '../../api/classes'
  import util from '../../api/util'
  export default {
    data() {
      return {
        total: 0,
        page: 1,
        pageSize: 10,
        tableData: [],
        loading:false,
        dialogVisible: false,
        guide:'',
      }
    },
    methods: {
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
      },
      dialog(row){
        this.dialogVisible=true;
        this.guide=row;
      },
      //跳转到修改页面
      edit(row){
        this.$router.push({path:'/edit_classes',query: {cid: row}});
      },
      //跳转到添加班级中/add_classes
      goAddPath(){
        this.$router.push({path:'/add_classes'});
      },
      //删除班级
      delete_classes(row){
          let parm={ token:localStorage.getItem('token'),}
        this.$confirm('确认删除该班级吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.loading=true;
          deleteClasses(row, parm).then(response => {
            this.$message({
              message: '删除成功',
              type: 'success'
            });
            this.loading=false;
            this.classesInfo();
          });
        }).catch(() => {
            setTimeout(() => {
              this.loading=false;
            }, 2000);
        });
      },
      //跳转到班级下的机器人页面
      getRobot(row){
        this.$router.push({path:'/classes_robot',query: {cid: row}});
      },
      //跳转到班级下的学生页面
      getStudent(row){
        this.$router.push({path:'/student',query: {cid: row}});
      },

      getSign(row){
        this.$router.push({path:'/sigin',query: {cid: row}});
      },
      getNotice(row){
        this.$router.push({path:'/classes_notice',query: {cid: row}});
      },
      //跳转到班级下直播
      getLive(row){
        this.$router.push({path:'/live',query: {cid: row}});
      },
      //时间显示转换
      setTime(row, column){
        return util.formatDate.setTime(row.time);
      },

      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
        this.page = val;
        this.classesInfo();
      },

      //得到分页信息
      classesInfo(){
        let para = {
          token:localStorage.getItem('token'),
          offset:(this.page-1)*(this.pageSize),
          pageSize:this.pageSize
        };
        this.loading=true;
        getClassesByToken(para).then(response => {
          this.total=response.data.total;
          this.tableData=response.data.item;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading=false;
          }, 2000);
        });
      },
    },
    created() {
      this.classesInfo();
    }
  }
</script>
<style>

</style>
