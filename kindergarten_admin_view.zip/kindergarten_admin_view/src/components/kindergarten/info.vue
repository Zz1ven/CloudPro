<template>
  <section>
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" >
        <el-form-item>
          <el-input placeholder="幼儿园管理"></el-input>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <el-card class="box-card" >
      <el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="100" label="ID">
        </el-table-column>
        <el-table-column prop="name" label="名称" width="300">
        </el-table-column>

        <el-table-column prop="cover" label="封面"  min-width="200">
          <template scope="scope">
            <img :src="scope.row.cover" style="width: 120px;height: 120px" >
          </template>
        </el-table-column>

        <el-table-column prop="address" label="地址" width="400">
        </el-table-column>

        <el-table-column prop="app_id" label="AppId" width="400">
        </el-table-column>

        <el-table-column prop="description" label="说明" min-width="150">
          <template scope="scope">
            <el-button size="small" type="success" @click="dialog(scope.row)">查看说明</el-button>
          </template>
        </el-table-column>


        <el-table-column prop="time" label="时间" width="150" :formatter="setTime">
        </el-table-column>

        <el-table-column label="操作" min-width="450" fixed="right">
          <template scope="scope">
            <el-button size="small" @click="edit(scope.row)">修改</el-button>
            <el-button type="info" size="small"  @click="goRobot(scope.row)">列出幼儿园下的机器</el-button>
            <el-button type="info" size="small"  @click="goAdmin(scope.row)">列出幼儿园下账户</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      width="100%"
      :before-close="handleClose">
      <span v-html="guide"></span>
      <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
    </span>
    </el-dialog>
  </section>
</template>
<script>
  import {getKindergartenByToken} from '../../api/kindergarten'
  import util from '../../api/util'
  export default {
    data() {
      return {
        tableData: [],
        dialogVisible: false,
        guide:'',
        loading:false
      }
    },
    methods: {
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
      },
      dialog(row){
        this.dialogVisible=true;
        this.guide=row.description;
      },
      //跳转到修改页面
      edit(row){
        this.$router.push({path:'/edit_kindergarten'});
      },
      goRobot(row){
        this.$router.push({path:'/robot', query: {kid: row.id}});
      },
      //跳转到幼儿园下的账户详情页面
      goAdmin(row){
        this.$router.push({path:'/admin', query: {app_id: row.app_id}});
      },
      //时间显示转换
      setTime(row, column){
        return util.formatDate.setTime(row.time);
      },

      //得到分页信息
      kindergartenInfo(){
        let para = {
         token:localStorage.getItem('token')};
        this.loading=true;
        getKindergartenByToken(para).then(response => {
          this.tableData.push(response.data);
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading = false;
          }, 2000);
        });;
      },
    },
    created() {
      this.kindergartenInfo();
    }
  }
</script>
<style>

</style>
