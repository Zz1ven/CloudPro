<template>
  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="80px" class="demo-ruleForm"
           style="margin:20px;width:80%;min-width:600px;"  v-loading="editloading">
    <el-form-item label="名称" prop="name" label-width="80px">
      <el-input v-model="ruleForm2.name" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="地址"  prop="address">
      <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model="ruleForm2.address" auto-complete="off" placeholder="请输入地址，不能为空"></el-input>
    </el-form-item>

    <el-form-item >
      <input type="hidden" v-model="ruleForm2.app_id"/>
    </el-form-item>

    <el-form-item label="说明">
      <el-input type="textarea" v-model="ruleForm2.description" :autosize="{ minRows: 2, maxRows: 4}"  placeholder="请输入内容，可为空"></el-input>
    </el-form-item>


    <el-form-item prop="cover">
      <input type="hidden" v-model="ruleForm2.cover" auto-complete="off"/>
    </el-form-item>

    <el-form-item label="封面">
      <el-upload
        class="avatar-uploader"
        action="http://avatarcn.oss-cn-hangzhou.aliyuncs.com"
        :data="data1"
        :file-list="fileList"
        :on-success="handleAvatarSuccess"
        :before-upload="beforeAvatarUpload">
        <img v-if="imageUrl" :src="imageUrl" class="avatar">
        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
      </el-upload>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">修改</el-button>
    </el-form-item>

  </el-form>
</template>
<script>
 import {getKindergartenByToken} from '../../api/kindergarten';
 import {editKindergartenByToken} from '../../api/kindergarten';
  export default {
    data() {
      return {
        data1: {
          key: ''
        },
        imageUrl:'',
        fileList: [{name: '', url: ""}],
        editloading:false,
        editorOption :{},    // 编辑器选项
        content:'',        //编辑器内容为空
        uploadType:'',
        addRange:[],
        fullscreenLoading : false,
        buckname: 'kindergarten/tmp/',
        ruleForm2: {
          name: '',
          description: '',
          address: '',
          app_id:''
        },
        rules2: {
          name: [
            { required: true, message: '请输入标题', trigger: 'blur' }
          ],

          address: [
            {required: true, message: '请输入地址', trigger: 'blur'}
          ],
        },
      };
    },

    methods: {
      //提交修改
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let para = {
              token:localStorage.getItem('token'),
              name:this.ruleForm2.name,
              address:this.ruleForm2.address,
              description:this.ruleForm2.description,
              app_id:this.ruleForm2.app_id,
              cover:this.ruleForm2.cover,
            };
            this.editloading=true;
            editKindergartenByToken(para).then(response => {
              this.editloading=false;
              this.$router.push('/edit_kindergarten');
              this.$message.success('修改成功');
            }).catch(() => {
              setTimeout(() => {
                this.editloading = false;
              }, 2000);
            });
          } else {
            this.$message.error('提交失败');
            return false;
          }
        });
      },

      //上传之前
      beforeAvatarUpload(file){
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';

        if(!isJPG&!isPNG){
          this.$message.error('上传头像图片只能是 JPG或者是PNG 格式!');
          return;
        }
        var suffix = file.name.substr(file.name.indexOf("."));
        var storeAs = this.buckname + this.guid() + suffix;
        this.data1.key= storeAs
      },

      handleAvatarSuccess(res, file) {
        this.imageUrl='http://avatarcn.oss-cn-hangzhou.aliyuncs.com/'+this.data1.key;
        this.ruleForm2.cover='http://avatarcn.oss-cn-hangzhou.aliyuncs.com/'+this.data1.key;
      },

      //生成UUID文件名
      guid() {
        function S4() {
          return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        }
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
      },

      getKindergartenInfos(){
        this.editloading=true;
        let para = {
          token:localStorage.getItem('token')};
        getKindergartenByToken(para).then(response => {
          this.ruleForm2.name=response.data.name;
          this.ruleForm2.description=response.data.description;
          this.ruleForm2.address=response.data.address;
          this.ruleForm2.app_id=response.data.app_id;
          this.ruleForm2.cover=response.data.cover;
          this.imageUrl=response.data.cover;
          //显示修改的封面名称
          this.fileList[0].name = response.data.cover,
            this.fileList[0].url = response.data.cover;
          this.editloading=false;
        }).catch(err => {
          setTimeout(() => {
            this.editloading = false;
          }, 2000);
        });
      },
    },
    mounted() {
      this.getKindergartenInfos();
      // 为图片ICON绑定事件  getModule 为编辑器的内部属性

    },
    created(){
      this.$root.Bus.$on('outLogin', value => {
          console.log(value)
        this.editloading=false;
      })
    }

  }
</script>
<style >
  .el-form-item__content {
    line-height: 50px;
    position: relative;
    font-size: 14px;

  }

  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #20a0ff;
  }

  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

  .avatar {
    width: 178px;
    height: 178px;
    display: block;

  }

</style>
