<template>
  <section>
    <!--工具条-->
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true">
        <el-form-item style="float: right">
          <el-button type="primary" @click="goAddPath()">添加机器人</el-button>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <h1>开放机器人</h1>
    <el-card class="box-card" >
      <el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="robot.id" width="50" label="ID">
        </el-table-column>
        <el-table-column property="robot.robot_code" label="机器人硬件编码" width="150">

        </el-table-column>
        <el-table-column prop="robot.robot_number" label="机器人编号" width="200">
        </el-table-column>

        <el-table-column prop="robot.activate" label="激活状态"   width="100">
          <template scope="scope">
            <el-tag  type="success" v-if="scope.row.robot.activate==true">激活</el-tag>
            <el-tag type="danger" v-if="scope.row.robot.activate==false">没激活</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="online" label="在线状态" width="100">
          <template scope="scope" >
            <el-tag  type="success" v-if="scope.row.online!=null&&scope.row.online.is_online==true">在线</el-tag>
            <el-tag type="danger"v-else>不在线</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="online" label="上一次在线时间" min-width="200" :formatter="setTime">
        </el-table-column>

        <el-table-column prop="power" label="电量状态" min-width="200">
          <template scope="scope" >
            <el-tag  type="success" v-if="scope.row.power!=null">{{scope.row.power.power}}%</el-tag>
            <el-tag type="danger"v-else>无</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="power" label="上一次电量时间" min-width="200" :formatter="setUpdateTime">
        </el-table-column>


        <el-table-column label="操作" min-width="250" fixed="right">
          <template scope="scope">

            <el-button type="danger" size="small" @click="deleteRobot(scope.row)">解绑机器人</el-button>

          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          @current-change="handleCurrentChange"
          :page-size="pageSize"
          :current-page.sync="page"
          layout="prev, pager, next,jumper"
          :total="total" style="float:right;">
        </el-pagination>
      </div>
    </el-card>


    <!--列表-->
    <h1>未开放机器人</h1>
    <el-card class="box-card" >
      <el-table :data="tableData1" style="width: 100%;" v-loading="loading">
        <el-table-column prop="robot.id" width="50" label="ID">
        </el-table-column>
        <el-table-column property="robot.robot_code" label="机器人硬件编码" width="150">

        </el-table-column>
        <el-table-column prop="robot.robot_number" label="机器人编号" width="200">
        </el-table-column>

        <el-table-column prop="robot.activate" label="激活状态"   width="100">
          <template scope="scope">
            <el-tag  type="success" v-if="scope.row.robot.activate==true">激活</el-tag>
            <el-tag type="danger" v-if="scope.row.robot.activate==false">没激活</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="online" label="在线状态" width="100">
          <template scope="scope" >
            <el-tag  type="success" v-if="scope.row.online!=null&&scope.row.online.is_online==true">在线</el-tag>
            <el-tag type="danger"v-else>不在线</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="online" label="上一次在线时间" min-width="200" :formatter="setTime">
        </el-table-column>

        <el-table-column prop="power" label="电量状态" min-width="200">
          <template scope="scope" >
            <el-tag  type="success" v-if="scope.row.power!=null">{{scope.row.power.power}}%</el-tag>
            <el-tag type="danger"v-else>无</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="power" label="上一次电量时间" min-width="200" :formatter="setUpdateTime">
        </el-table-column>


        <el-table-column label="操作" min-width="250" fixed="right">
          <template scope="scope">

            <el-button type="danger" size="small" @click="deleteRobot(scope.row)">解绑机器人</el-button>

          </template>
        </el-table-column>
      </el-table>
      <div class="block">
        <el-pagination
          @current-change="handleCurrentChange"
          :page-size="pageSize1"
          :current-page.sync="page1"
          layout="prev, pager, next,jumper"
          :total="total1" style="float:right;">
        </el-pagination>
      </div>
    </el-card>

  </section>
</template>
<script>
  import {getOpenRobotByToken} from '../../api/robot'
  import {getNoOpenRobot} from '../../api/robot'
  import {deleteAppRobotByToken} from '../../api/robot'
  import util from '../../api/util'
  export default {
    data() {
      return {
        total: 0,
        total1:0,
        page: 1,
        page1:1,
        pageSize: 10,
        pageSize1:10,
        tableData: [],
        tableData1:[],
        loading:false,
        token:localStorage.getItem('token'),
      }
    },
    methods: {

      //跳转到绑定机器人
      goAddPath(){
        this.$router.push({path:'/add_robot',query: {kindergarten_id: this.$route.query.kid}});
      },

      //跳转到添加班级中/add_classes
      goAddPath(){
        this.$router.push({path:'/add_robot'});
      },
      //时间显示转换
      setTime(row, column){
        if (row.online!=null){
          return util.formatDate.setTime(row.online.time);
        }else {
          return '无';
        }
      },
      //时间显示更新时间转换
      setUpdateTime(row, column){
        if (row.power!=null){
          return util.formatDate.setTime(row.power.time);
        }else {
          return '无';
        }
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
        this.page = val;
        this.robotInfo();
      },
      //得到分页信息
      robotInfo(){
        let para = {
            token:this.token,
            offset:(this.page-1)*(this.pageSize),
            pageSize:this.pageSize
        };
        this.loading=true;
        getOpenRobotByToken(para).then(response => {
          this.total=response.data.total;
          this.tableData=response.data.item;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading = false;
          }, 2000);
        });
      },
      //得到未开放的机器人
      robotInfo1(){
        let para = {
          token:this.token,
          offset:(this.page-1)*(this.pageSize),
          pageSize:this.pageSize
        };
        this.loading=true;
        getNoOpenRobot(para).then(response => {
          this.total1=response.data.total;
          this.tableData1=response.data.item;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading = false;
          }, 2000);
        });
      },
      //解绑机器人
      deleteRobot(row){
        let para = {
          token:this.token,
          robot_number:row.robot.robot_number
        };
        this.$confirm('确认解绑机器人吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.loading=true;
          deleteAppRobotByToken(para).then(response => {
            this.$message({
              message: '解绑成功',
              type: 'success'
            });
            this.loading=false;
            this.robotInfo();
            this.robotInfo1();
          });
        }).catch(() => {
            setTimeout(() => {
              this.editloading = false;
            }, 2000);
        });
      }
    },
    mounted() {
      this.robotInfo();
      this.robotInfo1();
    }
  }
</script>
<style>

</style>

