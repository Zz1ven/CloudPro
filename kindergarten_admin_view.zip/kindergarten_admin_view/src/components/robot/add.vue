<template>

  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="80px" class="demo-ruleForm"
           style="margin:20px;width:80%;min-width:600px;" v-loading="addloading">

    <el-form-item label="机器人编号" prop="robot_number" label-width="100px">
      <el-input v-model="ruleForm2.robot_number" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="机器人名称"  label-width="100px">
      <el-input v-model="ruleForm2.name"   placeholder="请输入机器人名称，可为空"></el-input>
    </el-form-item>

    <el-form-item label="机器人备注"  label-width="100px">
      <el-input v-model="ruleForm2.remark"   placeholder="请输入机器人备注，可为空"></el-input>
    </el-form-item>

    <el-form-item label="是否开放" label-width="100px">
      <el-radio v-model="ruleForm2.is_open" :label="true" >是</el-radio>
      <el-radio v-model="ruleForm2.is_open" :label="false">否</el-radio>
    </el-form-item>
    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </el-form-item>
  </el-form>
</template>
<script>
  import {addAppRobotByToken} from '../../api/robot'
  export default {
    data() {
      return {
        addloading:false,
        ruleForm2: {
          name: '',
          remark: '',
          is_open: true,
          robot_number:'',
          token:localStorage.getItem('token'),
        },
        rules2: {
          robot_number: [
            {required: true, message: '请输入机器人编号', trigger: 'blur'}
          ],
        },
      };
    },

    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let para = {
              name: this.ruleForm2.name,
              remark: this.ruleForm2.remark,
              is_open: this.ruleForm2.is_open,
              robot_number: this.ruleForm2.robot_number,
              token:this.ruleForm2.token,
            };
            this.addloading=true;
            addAppRobotByToken(para).then(response => {
              this.addloading=false;
              this.$router.push({path: '/robot'});
            }).catch(err => {
              setTimeout(() => {
                this.addloading=false;
              }, 2000);
            });
          } else {
            this.$message.error('提交失败');
            return false;
          }
        });
      },
    },

  }
</script>
<style>
  .el-form-item__content {
    line-height: 50px;
    position: relative;
    font-size: 14px;
  }

</style>
