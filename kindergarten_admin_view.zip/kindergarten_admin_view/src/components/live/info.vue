<template>
  <section>
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" >
        <el-form-item style="float: right">
          <el-button type="primary" @click="goAddPath()">添加学生</el-button>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <el-card class="box-card" >
      <el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="lives" width="500" label="机器人开放时间">
          <template scope="scope">
            <el-tag type="danger" v-if="scope.row.lives==null">全天开放</el-tag>
            <el-tag type="success" v-else v-for="live in scope.row.lives">开始时间：{{live.start_time|time}}--结束时间{{live.end_time |time}}</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="liveOpen" label="机器人正在直播时间" width="500">
          <template scope="scope">
            <el-tag type="danger" v-if="scope.row.liveOpen==null">无</el-tag>
            <el-tag type="success" v-else-if="scope.row.liveOpen.start_time!=null&&scope.row.liveOpen.end_time!=null">开始时间：{{scope.row.liveOpen.start_time|time}}--结束时间{{scope.row.liveOpen.end_time |time}}</el-tag>
            <el-tag type="danger" v-else>无</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="open" label="机器人是否开放"  min-width="200">
          <template scope="scope">
            <el-tag  type="success" v-if="scope.row.open==true">开放</el-tag>
            <el-tag type="danger"  v-if="scope.row.open==false">不开放</el-tag>
          </template>
        </el-table-column>

        <el-table-column prop="robotInfoLive.robot_code" label="机器人编码" width="200">
        </el-table-column>

        <el-table-column prop="robotInfoLive.robot_number" label="机器人编号" width="100">
        </el-table-column>

        <el-table-column prop="robotInfoLive" label="是否在线" min-width="150">
          <template scope="scope" >
            <el-tag  type="success" v-if="scope.row.robotInfoLive.is_online!=null&&scope.row.robotInfoLive.is_online==true">在线</el-tag>
            <el-tag type="danger" v-else>不在线</el-tag>
          </template>

        </el-table-column>

      </el-table>

    </el-card>
  </section>
</template>
<script>
  import {getLiveRobotByToken} from '../../api/live'
  import util from '../../api/util'
  export default {
    data() {
      return {
        tableData: [],
        loading:false,
        classes_id:this.$route.query.cid,
      }
    },
    methods: {

      //时间显示转换
      setTime(row, column){
        return util.formatDate.setTime(row.time);
      },

      //得到分页信息
      liveInfo(){
        let para = {
          classes_id:this.classes_id,
          token:localStorage.getItem('token')
        };
        this.loading=true;
        getLiveRobotByToken(para).then(response => {
          this.total=response.data.total;
          this.tableData=response.data.item;
          this.loading=false;
        });
      },

    },
    created() {
      this.liveInfo();
    },
    filters: {
      time: function (row) {
        return util.formatDate.setTime(row);
      },
    }
  }
</script>
<style>

</style>
