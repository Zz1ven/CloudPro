<template>
  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="80px" class="demo-ruleForm"
           style="margin:20px;width:80%;min-width:600px;" v-loading="loading">

    <el-form-item
      label="手机号码"
      prop="phone"
      :rules="[
    { required: true, message: '手机号不能为空'},
    { type: 'number', message: '手机号必须为数字值'}
    ]"
    >
      <el-input type="age" v-model.number="ruleForm2.phone" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="关系">
      <el-select v-model="ruleForm2.relation" placeholder="请选择">
        <el-option
          v-for="item in ruleForm2.options"
          :key="item.id"
          :label="item.name"
          :value="item.id">
        </el-option>
      </el-select>
    </el-form-item>


    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </el-form-item>
  </el-form>
</template>

<script >
  import {genearchStudentByPhone} from '../../api/student'
  export default {
    data() {
      return {
        loading:false,
        ruleForm2: {
        phone:'',
        relation:'',
          options:[{id:1,name:'父亲'},{id:2,name:'母亲'},{id:3,name:'爷爷'},{id:4,name:'奶奶'}]
        },

      };
    },

    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let para = {
              phone: this.ruleForm2.phone,
              relationship_id: this.ruleForm2.relation,
              token: localStorage.getItem('token'),
              classes_id:this.$route.query.cid,
              student_id:this.$route.query.sid
            };
            this.addloading=true;
            genearchStudentByPhone(para).then(response => {
              this.addloading=false;
              this.$router.push({path:'/student',query: {cid:this.$route.query.cid}});
            }).catch(() => {
              setTimeout(() => {
                this.addloading = false;
              }, 2000);
            });
          } else {
            this.$message.error('提交失败，缺少数据！');
            return false;
          }
        });
      },

      //上传之前
      beforeAvatarUpload(file){
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';

        if(!isJPG&!isPNG){
          this.$message.error('上传头像图片只能是 JPG或者是PNG 格式!');
          return;
        }
        var suffix = file.name.substr(file.name.indexOf("."));
        var storeAs = this.buckname + this.guid() + suffix;
        this.data1.key= storeAs

      },

      handleAvatarSuccess(res, file) {
        this.ruleForm2.img='http://avatarcn.oss-cn-hangzhou.aliyuncs.com/'+this.data1.key;
      },
      handlePreview(file) {
        console.log(file);
      },


      //生成UUID文件名
      guid() {
        function S4() {
          return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        }
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
      },

    },


  }
</script>
<style>
  .el-form-item__content {
    line-height: 60px;
    position: relative;
    font-size: 14px;
  }

  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #20a0ff;
  }

  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

  .avatar {
    width: 178px;
    height: 178px;
    display: block;

  }
</style>

