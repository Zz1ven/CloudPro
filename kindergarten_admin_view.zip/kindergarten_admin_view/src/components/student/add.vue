<template>
  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="80px" class="demo-ruleForm"
           style="margin:20px;width:80%;min-width:600px;" v-loading="addloading">
    <el-form-item label="名字" prop="name" label-width="80px">
      <el-input v-model="ruleForm2.name" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item prop="sex" style="margin-top: 20px">
      <input type="hidden" v-model="ruleForm2.sex" auto-complete="off"/>
    </el-form-item>

    <el-form-item label="性别">
      <el-radio v-model="ruleForm2.sex" label="男">男</el-radio>
      <el-radio v-model="ruleForm2.sex" label="女">女</el-radio>
    </el-form-item>

    <el-form-item
    label="年龄"
    prop="age"
    :rules="[
    { required: true, message: '年龄不能为空'},
    { type: 'number', message: '年龄必须为数字值'}
    ]"
    >
    <el-input type="age" v-model.number="ruleForm2.age" auto-complete="off"></el-input>
    </el-form-item>
    <el-form-item label="头像(正面照)" style="margin-top: 20px">
      <el-upload
        class="avatar-uploader"
        action="http://avatarcn.oss-cn-hangzhou.aliyuncs.com"
        :data="data1"
        :on-success="handleAvatarSuccess"
        :before-upload="beforeAvatarUpload">
        <img v-if="ruleForm2.img" :src="ruleForm2.img" class="avatar">
        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
      </el-upload>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </el-form-item>
  </el-form>
</template>

<script >

  import util from '../../api/util'
  import {addStudentByClassID} from '../../api/student'
  export default {
    data() {
      return {
        data1: {
          key: ''
        },
        addloading:false,
        buckname: 'kindergarten/tmp/',
        ruleForm2: {
          name: '',
          age:'',
          img:'',
          sex:''
        },
        rules2: {
          name: [
            { required: true, message: '请输入名字', trigger: 'blur' }
          ],
          sex: [
            {required: true, message: '输选择性别', trigger: 'blur'}
          ],
        },
      };
    },

    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
              if (this.ruleForm2.img==null||this.ruleForm2.img==''){
                let para = {
                  name: this.ruleForm2.name,
                  sex: this.ruleForm2.sex,
                  age: this.ruleForm2.age,
                };
                this.addloading=true;
                addStudentByClassID(this.$route.query.classes_id,para).then(response => {
                  this.addloading=false;
                  this.$router.push({path:'/student',query: {cid:this.$route.query.classes_id}});
                }).catch(() => {
                  setTimeout(() => {
                    this.addloading = false;
                  }, 2000);
                });
              }else if (this.ruleForm2.img!=null||this.ruleForm2.img!=''){
              let para1 = {
                name: this.ruleForm2.name,
                sex: this.ruleForm2.sex,
                age: this.ruleForm2.age,
                img: this.ruleForm2.img
              };
              this.addloading=true;
              addStudentByClassID(this.$route.query.classes_id,para1).then(response => {
                this.addloading=false;
                this.$router.push({path:'/student',query: {cid:this.$route.query.classes_id}});
              }).catch(() => {
                setTimeout(() => {
                  this.addloading = false;
                }, 2000);
              });
            }

          } else {
            this.$message.error('提交失败，缺少数据！');
            return false;
          }
        });
      },

      //上传之前
      beforeAvatarUpload(file){
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';

        if(!isJPG&!isPNG){
          this.$message.error('上传头像图片只能是 JPG或者是PNG 格式!');
          return;
        }
        var suffix = file.name.substr(file.name.indexOf("."));
        var storeAs = this.buckname + this.guid() + suffix;
        this.data1.key= storeAs

      },

      handleAvatarSuccess(res, file) {
        this.ruleForm2.img='http://avatarcn.oss-cn-hangzhou.aliyuncs.com/'+this.data1.key;
      },
      handlePreview(file) {
        console.log(file);
      },


      //生成UUID文件名
      guid() {
        function S4() {
          return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        }
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
      },

    },


  }
</script>
<style>
  .el-form-item__content {
    line-height: 60px;
    position: relative;
    font-size: 14px;
  }

  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #20a0ff;
  }

  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

  .avatar {
    width: 178px;
    height: 178px;
    display: block;

  }
</style>
