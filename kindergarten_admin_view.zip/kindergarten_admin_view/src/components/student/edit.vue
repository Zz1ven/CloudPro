<template>
  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="80px" class="demo-ruleForm"
           style="margin:20px;width:80%;min-width:600px;" v-loading="loading">
    <el-form-item label="名字" prop="name" label-width="100px">
      <el-input v-model="ruleForm2.name" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item prop="sex" style="margin-top: 20px" label-width="100px">
      <input type="hidden" v-model="ruleForm2.sex" auto-complete="off"/>
    </el-form-item>

    <el-form-item label="性别"  label-width="100px">
      <el-radio v-model="ruleForm2.sex" label="男">男</el-radio>
      <el-radio v-model="ruleForm2.sex" label="女">女</el-radio>
    </el-form-item>

    <el-form-item
      label="年龄"
      prop="age"
      :rules="[
    { required: true, message: '年龄不能为空'},
    { type: 'number', message: '年龄必须为数字值'}
    ]"
      label-width="100px">
      <el-input type="age" v-model.number="ruleForm2.age" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="头像（正面照）" style="margin-top: 20px"  label-width="100px">
      <el-upload
        class="avatar-uploader"
        action="http://avatarcn.oss-cn-hangzhou.aliyuncs.com"
        :data="data1"
        :file-list="fileList"
        :on-success="handleAvatarSuccess"
        :before-upload="beforeAvatarUpload">
        <img v-if="imageUrl" :src="imageUrl" class="avatar">
        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
      </el-upload>
    </el-form-item>

    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </el-form-item>
  </el-form>
</template>

<script >
  import {getStudentById} from '../../api/student'
  import {editStudentById} from '../../api/student'
  export default {
    data() {
      return {
        data1: {
          key: ''
        },
        imageUrl:'',
        fileList: [{name: '', url: ""}],
        loading:false,
        buckname: 'kindergarten/tmp/',
        ruleForm2: {
          name: '',
          age:'',
          img:'',
          sex:''
        },
        rules2: {
          name: [
            { required: true, message: '请输入名字', trigger: 'blur' }
          ],
          sex: [
            {required: true, message: '输选择性别', trigger: 'blur'}
          ],
        },
      };
    },

    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let para = {
              name: this.ruleForm2.name,
              sex: this.ruleForm2.sex,
              age: this.ruleForm2.age,
              img:this.ruleForm2.img
            };
            this.addloading=true;
            editStudentById(this.$route.query.cid,this.$route.query.sid,para).then(response => {
              this.addloading=false;
              this.$router.push({path:'/student',query: {cid:this.$route.query.cid}});
            }).catch(() => {
              setTimeout(() => {
                this.addloading = false;
              }, 2000);
            });
          } else {
            this.$message.error('提交失败，缺少数据！');
            return false;
          }
        });
      },

      //上传之前
      beforeAvatarUpload(file){
        const isJPG = file.type === 'image/jpeg';
        const isPNG = file.type === 'image/png';

        if(!isJPG&!isPNG){
          this.$message.error('上传头像图片只能是 JPG或者是PNG 格式!');
          return;
        }
        var suffix = file.name.substr(file.name.indexOf("."));
        var storeAs = this.buckname + this.guid() + suffix;
        this.data1.key= storeAs

      },

      handleAvatarSuccess(res, file) {
        this.ruleForm2.img='http://avatarcn.oss-cn-hangzhou.aliyuncs.com/'+this.data1.key;
        this.imageUrl='http://avatarcn.oss-cn-hangzhou.aliyuncs.com/'+this.data1.key;
      },
      handlePreview(file) {
        console.log(file);
      },


      //生成UUID文件名
      guid() {
        function S4() {
          return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
        }
        return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
      },

      getStudentInfo(){
        this.loading=true;
        getStudentById(this.$route.query.sid).then(response => {
          this.ruleForm2.name=response.data.name;
          this.ruleForm2.sex=response.data.sex;
          this.ruleForm2.age=response.data.age;
          this.ruleForm2.img=response.data.img;
          this.imageUrl=response.data.img;
          //显示修改的封面名称
          this.fileList[0].name = response.data.img,
            this.fileList[0].url = response.data.img;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading = false;
          }, 2000);
        });
      },

    },
    created(){
        this.getStudentInfo();
    }


  }
</script>
<style>
  .el-form-item__content {
    line-height: 60px;
    position: relative;
    font-size: 14px;
  }

  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #20a0ff;
  }

  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

  .avatar {
    width: 178px;
    height: 178px;
    display: block;

  }
</style>
