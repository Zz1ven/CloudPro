<template>
  <section>
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" >
        <el-form-item>
          <el-input placeholder="班级管理"></el-input>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <el-card class="box-card" >
      <el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="100" label="ID">
        </el-table-column>
        <el-table-column prop="phone" label="家长手机号" width="200">
        </el-table-column>

        <el-table-column prop="student.id" label="学生ID" min-width="150">
        </el-table-column>

        <el-table-column prop="student.name" label="学生名称" min-width="150">
        </el-table-column>

        <el-table-column prop="student.age" label="学生年龄" min-width="150">
        </el-table-column>

        <el-table-column prop="student.sex" label="学生性别" min-width="100">
        </el-table-column>

        <el-table-column prop="student.img" label="头像"  min-width="200">
          <template scope="scope" >
            <img :src="scope.row.student.img" style="width: 120px;height: 120px" v-if="scope.row.student.img!=null">
          </template>
        </el-table-column>

        <el-table-column prop="student.face_token" label="face_token" min-width="260">

        </el-table-column>

        <el-table-column prop="applyRelationShip.name" label="与孩子之间的关系" min-width="260">

        </el-table-column>

        <el-table-column prop="time" label="时间" width="150" :formatter="setTime">
        </el-table-column>

        <el-table-column label="操作" min-width="200" fixed="right">
          <template scope="scope">
            <el-button type="danger" size="small"  @click="deleteGenearch(scope.row)">解绑</el-button>
          </template>
        </el-table-column>
      </el-table>

    </el-card>
  </section>
</template>
<script>
  import {getStudentGenearch} from '../../api/student'
  import {deleteGenearchStudent} from '../../api/student'
  import util from '../../api/util'
  export default {
    data() {
      return {
        tableData: [],
        loading:false,
      }
    },
    methods: {
      //家长解绑学生
      deleteGenearch(row){
        this.$confirm('确认解绑该小孩吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.loading=true;
          deleteGenearchStudent(row.id).then(response => {
            this.$message({
              message: '解绑成功',
              type: 'success'
            });
            this.loading=false;
            this.genearchInfo();
          });
        }).catch(() => {
          setTimeout(() => {
            this.loading=false;
          }, 2000);
        });
      },
      //时间显示转换
      setTime(row, column){
        return util.formatDate.setTime(row.time);
      },

      //得到分页信息
      genearchInfo(){
        let para = {
          token:localStorage.getItem('token'),
        };
        this.loading=true;
        getStudentGenearch(para,this.$route.query.sid).then(response => {
          this.tableData=response.data;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading=false;
          }, 2000);
        });
      },
    },
    created() {
      this.genearchInfo();
    }
  }
</script>
<style>

</style>
