<template>
  <section>
    <!--工具条-->
    <el-col :span="24" class="toolbar" style="padding-bottom: 0px;">
      <el-form :inline="true" >
        <el-form-item style="float: right">
          <el-button type="primary" @click="goAddPath()">添加学生</el-button>
          <el-button type="success" @click="getGenearch()">班级下家长账户</el-button>
        </el-form-item>
      </el-form>
    </el-col>

    <!--列表-->
    <el-card class="box-card" >
      <el-table :data="tableData" style="width: 100%;" v-loading="loading">
        <el-table-column prop="id" width="100" label="ID">
        </el-table-column>
        <el-table-column prop="name" label="名称" width="200">
        </el-table-column>

        <el-table-column prop="img" label="头像"  min-width="150">
          <template scope="scope" >
            <img :src="scope.row.img" style="width: 120px;height: 120px" v-if="scope.row.img!=null">
          </template>
        </el-table-column>

        <el-table-column prop="sex" label="性别" width="150">
        </el-table-column>

        <el-table-column prop="age" label="年龄" width="150">
        </el-table-column>

        <el-table-column prop="classes_id" label="班级id" min-width="100">

        </el-table-column>


        <el-table-column prop="time" label="时间" width="250" :formatter="setTime">
        </el-table-column>

        <el-table-column label="操作" min-width="260" fixed="right">
          <template scope="scope">
            <el-button size="small" @click="edit(scope.row)">修改</el-button>
            <el-button type="danger" size="small"  @click="deleteStudent(scope.row)">删除</el-button>
            <el-button type="primary" size="small"  @click="genearch(scope.row)">与家长绑定</el-button>
            <el-button type="success" size="small"  @click="getStudentGenearch(scope.row)">学生下的家长账户</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="block">
        <el-pagination
          @current-change="handleCurrentChange"
          :page-size="pageSize"
          :current-page.sync="page"
          layout="prev, pager, next,jumper"
          :total="total" style="float:right;">
        </el-pagination>
      </div>
    </el-card>
  </section>
</template>
<script>
  import {getStudentByClassesId} from '../../api/student'
  import {deleteStudentById} from '../../api/student'
  import util from '../../api/util'
  export default {
    data() {
      return {
        total: 0,
        page: 1,
        pageSize: 10,
        tableData: [],
        loading:false,
        classes_id:this.$route.query.cid,
      }
    },
    methods: {
      //跳转到班级下家长账户页面
      getGenearch(){
        this.$router.push({path:'/classes_genearch',query: {cid: this.$route.query.cid}});
      },
      //跳转到学生下的家长账户
      getStudentGenearch(row){
        this.$router.push({path:'/student_genearch',query: {sid: row.id}});
      },
      //跳转到修改页面
      edit(row){
        this.$router.push({path:'/edit_student',query: {sid: row.id,cid:row.classes_id}});
      },
      goAddPath(){
        this.$router.push({path:'/add_student', query: {classes_id: this.classes_id}});
      },
      //时间显示转换
      setTime(row, column){
        return util.formatDate.setTime(row.time);
      },
      //通过家长绑定小孩
      genearch(row){
        this.$router.push({path:'/genearch',query: {sid: row.id,cid:row.classes_id}});
     },
      handleCurrentChange(val) {
        this.page = val;
        this.studentInfo();
      },

      //得到分页信息
     studentInfo(){
        let para = {
          offset:(this.page-1)*(this.pageSize),
          pageSize:this.pageSize
        };
        this.loading=true;
        getStudentByClassesId(this.$route.query.cid,para).then(response => {
            this.total=response.data.total;
          this.tableData=response.data.item;
          this.loading=false;
        }).catch(() => {
          setTimeout(() => {
            this.loading = false;
          }, 2000);
        });
      },

      //删除指定的学生
      deleteStudent(row){
        this.$confirm('确认删除该小孩吗?', '提示', {
          type: 'warning'
        }).then(() => {
          this.loading=true;
          deleteStudentById(row.id).then(response => {
            this.$message({
              message: '删除成功',
              type: 'success'
            });
            this.loading=false;
            this.studentInfo();
          });
        }).catch(() => {
            setTimeout(() => {
              this.loading = false;
            }, 2000);
        });
      }
    },
    created() {
      this.studentInfo();
    }
  }
</script>
<style>

</style>
