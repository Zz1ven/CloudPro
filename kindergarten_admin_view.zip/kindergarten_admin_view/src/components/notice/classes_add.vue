<template>
  <el-form :model="ruleForm2" status-icon :rules="rules2" ref="ruleForm2" label-width="80px" class="demo-ruleForm"
           style="margin:20px;width:80%;min-width:600px;" v-loading="loading">
    <el-form-item label="标题" prop="title" label-width="80px">
      <el-input v-model="ruleForm2.title" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="内容" prop="msg_content">
      <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model="ruleForm2.msg_content" placeholder="请输入内容，不为空"></el-input>
    </el-form-item>


    <el-form-item>
      <el-button type="primary" @click="submitForm('ruleForm2')">提交</el-button>
    </el-form-item>
  </el-form>
</template>

<script>
  import {jpushClasses} from '../../api/notice'
  export default {
    data() {
      return {
        loading:false,
        ruleForm2: {
          title: '',
          msg_content: '',
        },
        rules2: {
          title: [
            {required: true, message: '请输入标题', trigger: 'blur'}
          ],
          msg_content: [
            {required: true, message: '请输入内容', trigger: 'blur'}
          ]
        },
      };
    },
    methods: {
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
              let para = {
                token:localStorage.getItem('token'),
                classes_id:this.$route.query.cid,
                title: this.ruleForm2.title,
                msg_content: this.ruleForm2.msg_content,
              };
              this.loading=true;
              jpushClasses(para).then(response => {
                this.loading=false;
                this.ruleForm2.title='',
                  this.ruleForm2.msg_content='',
                this.$message.success('发送成功');
              }).catch(() => {
                setTimeout(() => {
                  this.loading = false;
                }, 2000);
              });

          } else {
            this.$message.error('提交失败');
            return false;
          }
        });
      },
    },

  }
</script>

<style>
  .el-form-item__content {
    line-height: 60px;
    position: relative;
    font-size: 14px;
  }

</style>
