/**
 * Created by Administrator on 2017-12-8.
 */
import fetch from './fetch';

//通过token列出所有的班级
export function getClassesByToken(params) {
  return fetch({
    url: '/cloud/v1/classes/page',
    method: 'get',
    params
  });
}

//获得指定的班级
export function getClassesById(classes_id) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id,
    method: 'get',
  });
}

//修改指定的班级
export function editClassesById(classes_id,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id,
    method: 'put',
    params
  });
}

//添加班级
export function addClasses(params) {
  return fetch({
    url: '/cloud/v1/classes',
    method: 'post',
    params
  });
}

//根据班级列出签到记录
export function getSignByCid(classes_id,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id+'/signin/page',
    method: 'get',
    params
  });
}

//删除指定的班级
export function deleteClasses(classes_id,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id,
    method: 'delete',
    params
  });
}

//通过家长账户列出家长账户
export function getGenearchByCId(classes_id,params) {
  return fetch({
    url: '/cloud/v1/kindergarten/classes/'+classes_id+'/genearch',
    method: 'get',
    params
  });
}

