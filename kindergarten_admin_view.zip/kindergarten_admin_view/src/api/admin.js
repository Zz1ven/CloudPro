/**
 * Created by Administrator on 2017-12-5.
 */
import fetch from './fetch';

//通过用户名和密码登录
export function login(params) {
  return fetch({
    url: '/cloud/v1/user/login',
    method: 'post',
    params
  });
}

//退出登录

export function outLogin(params) {
  return fetch({
    url: '/cloud/v1/user/logout',
    method: 'post',
    params
  });
}

