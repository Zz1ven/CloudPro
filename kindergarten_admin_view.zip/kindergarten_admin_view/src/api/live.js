/**
 * Created by Administrator on 2017-12-13.
 */
import fetch from './fetch';

//通过token列出直播机器人
export function getLiveRobotByToken(params) {
  return fetch({
    url: '/cloud/v1/live/classes/page',
    method: 'get',
    params
  });
}
