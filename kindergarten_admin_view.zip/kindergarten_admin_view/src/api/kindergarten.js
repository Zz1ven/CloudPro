/**
 * Created by Administrator on 2017-12-5.
 */
import fetch from './fetch';

//通过token获取幼儿园信息
export function getKindergartenByToken(params) {
  return fetch({
    url: '/cloud/v1/kindergarten',
    method: 'get',
    params
  });
}

//通过token修改幼儿园
export function editKindergartenByToken(params) {
  return fetch({
    url: '/cloud/v1/kindergarten',
    method: 'put',
    params
  });
}
