/**
 * Created by Administrator on 2017-12-26.
 */
import fetch from './fetch';

//列出所有的签到时间
export function signInTime(params) {
  return fetch({
    url: '/cloud/v1/signin/system/signIn/page',
    method: 'get',
    params
  });
}
//列出所有的签退时间
export function signOutTime(params) {
  return fetch({
    url: '/cloud/v1/signin/system/signOut/page',
    method: 'get',
    params
  });
}
//列出所有的签退及签到时间
export function signAllTimePage(params) {
  return fetch({
    url: '/cloud/v1/signin/system/sign/page',
    method: 'get',
    params
  });
}
//删除
export function deleteTime(id) {
  return fetch({
    url: '/cloud/v1/signin/system/'+id,
    method: 'delete',
  });
}
//添加
export function addTime( params) {
  return fetch({
    url: '/cloud/v1/signin/system',
    method: 'post',
    params
  });
}
//获取指定的
export function getTimeById(id) {
  return fetch({
    url: '/cloud/v1/signin/system/'+id,
    method: 'get',
  });
}

//修改指定的
export function editTimeById(id,params) {
  return fetch({
    url: '/cloud/v1/signin/system/'+id,
    method: 'put',
    params
  });
}


