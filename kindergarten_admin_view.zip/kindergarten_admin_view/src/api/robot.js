/**
 * Created by Administrator on 2017-12-8.
 */
import fetch from './fetch';

//通过token和classes_id列出机器人
export function getRobotByTokenAndCid(classes_id,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id+'/robot',
    method: 'get',
    params
  });
}

//解绑班级下的机器人
export function deleteClassesRobotByTokenAndCid(classes_id,robot_number,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id+'/robot/'+robot_number,
    method: 'delete',
    params
  });
}

//班级绑定机器人
export function createClassesRobotByTokenAndCid(classes_id,robot_number,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id+'/robot/'+robot_number,
    method: 'post',
    params
  });
}

//根据token查看应用下的机器人
export function getAppRobotByToken(params) {
  return fetch({
    url: '/cloud/v1/user/robot/bind',
    method: 'get',
    params
  });
}

//绑定应用机器人
export function addAppRobotByToken(params) {
  return fetch({
    url: '/cloud/v1/user/robot/bind',
    method: 'post',
    params
  });
}

//解绑应用机器人
export function deleteAppRobotByToken(params) {
  return fetch({
    url: '/cloud/v1/user/robot/bind',
    method: 'delete',
    params
  });
}

//列出所有开放的机器人
export function getOpenRobotByToken(params) {
  return fetch({
    url: '/cloud/v1/user/robot/bind/open',
    method: 'get',
    params
  });
}


//列出幼儿园下未和班级绑定的机器人
export function getGroupNoBindRobot(params) {
  return fetch({
    url: '/cloud/v1/user/classes/no_bind',
    method: 'get',
    params
  });
}

//列出未开放的机器人
export function getNoOpenRobot(params) {
  return fetch({
    url: '/cloud/v1/user/robot_close',
    method: 'get',
    params
  });
}
