/**
 * Created by Administrator on 2017-12-8.
 */

import fetch from './fetch';

//根据班级获得班级下的学生
export function getStudentByClassesId(classes_id,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id+'/student/page',
    method: 'get',
    params
  });
}

//删除学生
export function deleteStudentById(id) {
  return fetch({
    url: '/cloud/v1/classes/student/'+id,
    method: 'delete',
  });
}

//添加学生
export function addStudentByClassID(classes_id,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id+'/student',
    method: 'post',
    params
  });
}

//获得指定的学生
export function getStudentById(id) {
  return fetch({
    url: '/cloud/v1/classes/student/'+id,
    method: 'get',
  });
}

//修改指定的学生
export function editStudentById(classes_id,id,params) {
  return fetch({
    url: '/cloud/v1/classes/'+classes_id+'/student/'+id,
    method: 'put',
    params
  });
}

//通过手机号绑定家长账户
export function genearchStudentByPhone(params) {
  return fetch({
    url: '/cloud/v1/app/classes/genearch',
    method: 'post',
    params
  });
}

//解绑学生账户
export function deleteGenearchStudent(id) {
  return fetch({
    url: '/cloud/v1/app/classes/genearch/'+id,
    method: 'delete',
  });
}

//学生下的家长账户
export function getStudentGenearch(params,student_id) {
  return fetch({
    url: '/cloud/v1/kindergarten/student/'+student_id+'/genearch',
    method: 'get',
    params
  });
}
