/**
 * Created by Administrator on 2017-12-25.
 */
import fetch from './fetch';

//实时班级推送
export function jpushKindergarten(params) {
  return fetch({
    url: '/cloud/v1/jpush/kindergarten',
    method: 'post',
    params
  });
}

//实时班级推送
export function jpushClasses(params) {
  return fetch({
    url: '/cloud/v1/jpush/classes',
    method: 'post',
    params
  });
}
