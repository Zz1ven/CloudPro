import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home.vue'
import Login from '@/components/Login.vue'
import EditKindergarten from '@/components/kindergarten/edit.vue'
import Classes from '@/components/classes/info'
import EditClasses from '@/components/classes/edit'
import AddClasses from '@/components/classes/add'
import ClassesRobot from '@/components/classes/robot_info'
import AppRobot from '@/components/robot/info'
import AddAppRobot from '@/components/robot/add'
import Student from '@/components/student/info'
import AddStudent from '@/components/student/add'
import EditStudent from '@/components/student/edit'
import Sigin from '@/components/classes/sigin'
import Genearch from '@/components/student/genearch'
import RobotAdd from '@/components/classes/app_robot'
import OpenRobot from '@/components/robot/open'
import ClassesGenearch from '@/components/classes/genearch'
import Live from '@/components/live/info'
import Notice from '@/components/notice/add'
import ClassesNotice from '@/components/notice/classes_add'
import SiginInfos from '@/components/sigin/info'
import AddSiginInfos from '@/components/sigin/add'
import EditSiginInfos from '@/components/sigin/edit'
import StudentGenearch from '@/components/student/student_genearch'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/login',
      component: Login,
      name: '',
      hidden: true
    },
    {
      path: '/',
      hidden: true,
      redirect: { path: '/edit_kindergarten' }
    },
    {
      path: '/',
      component: Home,
      name: '幼儿园管理',
      iconCls: 'iconfont icon-youeryuanguanli',//图标样式class
      leaf: true,
      children: [
      //  { path: '/kindergarten', component: Kindergarten, name: '幼儿园信息' },
        { path: '/edit_kindergarten', component: EditKindergarten,name: '幼儿园信息'},
      ]
    },

    {
      path: '/',
      component: Home,
      name: '班级管理',
      //iconCls: 'el-icon-tickets',//图标样式
      iconCls: 'iconfont icon-banjiguanli',
      leaf: true,
      children: [
        { path: '/classes', component: Classes, name: '班级信息' },
        { path: '/edit_classes', component:  EditClasses},
        { path: '/add_classes', component: AddClasses},
        { path: '/classes_robot', component: ClassesRobot},
        { path: '/student', component: Student},
        { path: '/add_student', component: AddStudent},
        { path: '/edit_student', component: EditStudent},
        { path: '/sigin', component:Sigin},
        { path: '/genearch', component:Genearch},
        { path: '/robot_add', component:RobotAdd},
        { path: '/classes_genearch', component:ClassesGenearch},
        { path: '/live', component: Live},
        { path: '/classes_notice', component: ClassesNotice},
        { path: '/student_genearch', component: StudentGenearch},
      ]
    },

    {
      path: '/',
      component: Home,
      name: '机器人管理',
      leaf: true,
      iconCls: 'iconfont icon-faq-smart',//图标样式class
      children: [
        { path: '/robot', component: AppRobot, name: '机器信息' },
        { path: '/open_robot', component:OpenRobot, name: '开放机器信息' },
        { path: '/add_robot', component: AddAppRobot},
      ]
    },

    {
      path: '/',
      component: Home,
      name: '通知管理',
      leaf: true,
      iconCls: 'iconfont icon-fasongtongzhi',//图标样式class
      children: [
        { path: '/notice', component: Notice, name: '幼儿园通知' },
      ]
    },

    {
      path: '/',
      component: Home,
      name: '签到时间管理',
      leaf: true,
      iconCls: 'iconfont icon-qiandao',//图标样式class
      children: [
        { path: '/sign', component:SiginInfos, name: '签到时间管理' },
        { path: '/add_sign', component:AddSiginInfos},
        { path: '/edit_sign', component:EditSiginInfos}
      ]
    },

    // {
    //   path: '/',
    //   component: Home,
    //   name: '直播管理',
    //   iconCls: 'el-icon-view',//图标样式class
    //   children: [
    //     { path: '/live', component: Live, name: '列出直播机器人信息' },
    //     { path: '/add_live', component: AddAppRobot, name: '添加直播' },
    //   ]
    // },
  ]
})
