package com.avatarcn.AppTourists.model;

/**
 * Created by z1ven on 2018/3/2 11:48
 */
public class SpecialityMenu {
    private int speciality_id;
    private int amount;

    public int getSpeciality_id() {
        return speciality_id;
    }

    public void setSpeciality_id(int speciality_id) {
        this.speciality_id = speciality_id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
