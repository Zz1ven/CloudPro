package com.avatarcn.AppTourists.model;

/**
 * Created by z1ven on 2018/1/30 15:57
 */
public class FoodMenu {
    private int food_id;
    private int amount;

    public int getFood_id() {
        return food_id;
    }

    public void setFood_id(int food_id) {
        this.food_id = food_id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
