package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.SpecialityOrderMenu;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

/**
 * Created by z1ven on 2018/3/1 15:37
 */
@Mapper
public interface SpecialityOrderMenuMapper {

    @Insert("INSERT INTO tb_order_speciality_menu(fk_tb_order_speciality_id, fk_tb_speciality_id, fk_tb_good_status_id, amount) VALUES(#{fk_tb_order_speciality_id}, #{fk_tb_speciality_id}, #{fk_tb_good_status_id}, #{amount})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(SpecialityOrderMenu specialityOrderMenu);

    //@Delete("DELETE FROM tb_order_speciality_menu WHERE id = #{id}")
    //int deleteById(Integer id);

    @Delete("DELETE FROM tb_order_speciality_menu WHERE fk_tb_order_speciality_id = #{fk_tb_order_speciality_id}")
    int deleteBySpecialityOrderId(Integer fk_tb_order_speciality_id);

    //@Delete("DELETE FROM tb_order_speciality_menu WHERE fk_tb_speciality_id = #{fk_tb_speciality_id}")
    //int deleteBySpecialityId(Integer fk_tb_speciality_id);

    //@Select("SELECT * FROM tb_order_speciality_menu WHERE id = #{id}")
    //SpecialityOrderMenu selectById(Integer id);

    @Select("SELECT * FROM tb_order_speciality_menu WHERE fk_tb_order_speciality_id = #{fk_tb_order_speciality_id}")
    @Results({
            @Result(property = "fk_tb_speciality_id", column = "fk_tb_speciality_id"),
            @Result(property = "fk_tb_good_status_id", column = "fk_tb_good_status_id"),
            @Result(property = "speciality", column = "fk_tb_speciality_id", one = @One(select = "com.avatarcn.AppTourists.mapper.SpecialityMapper.selectByPrimaryKey", fetchType = FetchType.LAZY)),
            @Result(property = "goodStatus", column = "fk_tb_good_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.GoodStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    List<SpecialityOrderMenu> selectBySpecialityOrderId(Integer fk_tb_order_speciality_id);

    /*@Select("SELECT * FROM tb_order_speciality_menu WHERE fk_tb_refund_good_id = #{fk_tb_refund_good_id}")
    @Results({
            @Result(property = "fk_tb_speciality_id", column = "fk_tb_speciality_id"),
            @Result(property = "fk_tb_good_status_id", column = "fk_tb_good_status_id"),
            @Result(property = "speciality", column = "fk_tb_speciality_id", one = @One(select = "com.avatarcn.AppTourists.mapper.SpecialityMapper.selectByPrimaryKey", fetchType = FetchType.LAZY)),
            @Result(property = "goodStatus", column = "fk_tb_good_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.GoodStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    List<SpecialityOrderMenu> selectByRefundGoodId(Integer fk_tb_refund_good_id);*/

    @Select("SELECT * FROM tb_order_speciality_menu WHERE fk_tb_order_speciality_id = #{fk_tb_order_speciality_id} AND fk_tb_speciality_id = #{fk_tb_speciality_id}")
    @Results({
            @Result(property = "fk_tb_speciality_id", column = "fk_tb_speciality_id"),
            @Result(property = "speciality", column = "fk_tb_speciality_id", one = @One(select = "com.avatarcn.AppTourists.mapper.SpecialityMapper.selectByPrimaryKey", fetchType = FetchType.LAZY))
    })
    SpecialityOrderMenu selectByOrderIdAndSpecialityId(@Param("fk_tb_order_speciality_id") Integer fk_tb_order_speciality_id, @Param("fk_tb_speciality_id") Integer fk_tb_speciality_id);

    @Update("UPDATE tb_order_speciality_menu SET fk_tb_order_speciality_id = #{fk_tb_order_speciality_id}, fk_tb_speciality_id = #{fk_tb_speciality_id}, fk_tb_good_status_id = #{fk_tb_good_status_id}, amount = #{amount} WHERE id = #{id}")
    int update(SpecialityOrderMenu specialityOrderMenu);
}
