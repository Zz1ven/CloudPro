package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.json.response.attractions.AttractionsResponse;
import com.avatarcn.AppTourists.model.Attractions;
import com.avatarcn.AppTourists.service.AttractionsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by z1ven on 2018/2/2 09:42
 */
@Api(value = "/v1/attractions", description = "分身景点模块")
@RequestMapping(value = "/v1/attractions")
@RestController
public class AttractionsController {

    @Autowired
    private AttractionsService attractionsService;

    @ApiOperation("添加景点及机器人")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Attractions> addAttractions(@ApiParam(value = "景点名称", required = true) @RequestParam(value = "name") String name,
                                                @ApiParam(value = "景点图片", required = true) @RequestParam(value = "image") String image,
                                                @ApiParam(value = "app_id", required = true) @RequestParam(value = "app_id") String app_id,
                                                @ApiParam(value = "机器人编号", required = true) @RequestParam(value = "robot_number") String robot_number,
                                                @ApiParam(value = "备注") @RequestParam(value = "remark", required = false, defaultValue = "") String remark) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, attractionsService.addAttractions(name, image, app_id, robot_number, remark));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("删除指定的景点")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonBean<Integer> deleteAttractions(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, attractionsService.deleteAttractions(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定的景点")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<AttractionsResponse> getAttractions(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, attractionsService.selectById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取所有的景点")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<AttractionsResponse>> getPageAttractions(@ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                                          @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, attractionsService.selectPage(offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("修改指定的景点")
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonBean<Attractions> updateAttractions(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                                   @ApiParam(value = "景点名称", required = true) @RequestParam(value = "name") String name,
                                                   @ApiParam(value = "景点图片", required = true) @RequestParam(value = "image") String image,
                                                   @ApiParam(value = "app_id", required = true) @RequestParam(value = "app_id") String app_id,
                                                   @ApiParam(value = "机器人编号", required = true) @RequestParam(value = "robot_number") String robot_number,
                                                   @ApiParam(value = "备注") @RequestParam(value = "remark", required = false, defaultValue = "") String remark) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, attractionsService.updateAttractions(id, name, image, app_id, robot_number, remark));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }
}
