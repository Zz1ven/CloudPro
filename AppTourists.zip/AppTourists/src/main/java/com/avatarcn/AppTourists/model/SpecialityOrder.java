package com.avatarcn.AppTourists.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/1 15:25
 */
@JsonIgnoreProperties(value = {"handler"})
public class SpecialityOrder {
    private int id;
    private int fk_tb_user_id;
    private int fk_tb_order_status_id;
    private int fk_tb_user_address_id;
    private String number;
    private float total_money;
    private float real_money;
    private String pay_method;
    private Date finish_time;
    private boolean visible;
    private Date pay_time;
    private Date time;

    private List<SpecialityOrderMenu> specialityOrderMenus;
    private OrderStatus orderStatus;
    private UserAddress userAddress;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFk_tb_user_id() {
        return fk_tb_user_id;
    }

    public void setFk_tb_user_id(int fk_tb_user_id) {
        this.fk_tb_user_id = fk_tb_user_id;
    }

    public int getFk_tb_order_status_id() {
        return fk_tb_order_status_id;
    }

    public void setFk_tb_order_status_id(int fk_tb_order_status_id) {
        this.fk_tb_order_status_id = fk_tb_order_status_id;
    }

    public int getFk_tb_user_address_id() {
        return fk_tb_user_address_id;
    }

    public void setFk_tb_user_address_id(int fk_tb_user_address_id) {
        this.fk_tb_user_address_id = fk_tb_user_address_id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public float getTotal_money() {
        return total_money;
    }

    public void setTotal_money(float total_money) {
        this.total_money = total_money;
    }

    public float getReal_money() {
        return real_money;
    }

    public void setReal_money(float real_money) {
        this.real_money = real_money;
    }

    public String getPay_method() {
        return pay_method;
    }

    public void setPay_method(String pay_method) {
        this.pay_method = pay_method;
    }

    public Date getFinish_time() {
        return finish_time;
    }

    public void setFinish_time(Date finish_time) {
        this.finish_time = finish_time;
    }

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public Date getPay_time() {
        return pay_time;
    }

    public void setPay_time(Date pay_time) {
        this.pay_time = pay_time;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public List<SpecialityOrderMenu> getSpecialityOrderMenus() {
        return specialityOrderMenus;
    }

    public void setSpecialityOrderMenus(List<SpecialityOrderMenu> specialityOrderMenus) {
        this.specialityOrderMenus = specialityOrderMenus;
    }

    public OrderStatus getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
    }

    public UserAddress getUserAddress() {
        return userAddress;
    }

    public void setUserAddress(UserAddress userAddress) {
        this.userAddress = userAddress;
    }
}
