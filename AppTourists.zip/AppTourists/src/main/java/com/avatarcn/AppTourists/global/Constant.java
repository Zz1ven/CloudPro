package com.avatarcn.AppTourists.global;

/**
 * Created by z1ven on 2018/1/17 16:22
 */
public class Constant {
    public static final String TOURISTS_TMP_DIR = "tourists/tmp";
    public static final String TOURISTS_NEWS_DIR = "tourists/news";
    public static final String TOURISTS_ACTIVE_DIR = "tourists/active";
    public static final String TOURISTS_ROOM_DIR = "tourists/room";
    public static final String TOURISTS_FEEDBACK_DIR = "tourists/feedback";
    public static final String TOURISTS_SPECIALITY_DIR = "tourists/speciality";
    public static final String TOURISTS_RECOMMENDATION_DIR = "tourists/recommendation";
    public static final String TOURISTS_ATTRACTIONS_DIR = "tourists/attractions";
    public static final String TOURISTS_FOODTYPE_DIR = "tourists/food_type";

    //订单类型
    public static final String ACTIVE_ORDER_TYPE = "001";
    public static final String FOOD_ORDER_TYPE = "002";
    public static final String GOOD_ORDER_TYPE = "003";
    public static final String REFUND_ACTIVE_ORDER_TYPE = "011";
    public static final String REFUND_FOOD_ORDER_TYPE = "012";
    public static final String REFUND_GOOD_ORDER_TYPE = "013";

    //订单支付方式
    public static final String ALIPAY = "alipay";
    public static final String WXPAY = "wxpay";

    //特产商城订单状态变化:
    //提交[待付款]->付款[待发货]->发货[待收货]->收货[待评价]->评价[已完成]

    //活动订单状态变化:
    //提交[待付款]->付款[未使用]->使用[已使用]

    //餐饮订单状态变化:
    //提交[待付款]->付款[未使用]->使用[已使用]
    //------------------------->过期[已过期]

    //退款流程:
    //[待发货/待收货]->退款[退款中]->支付宝/微信退款[已退款]
    //--------------->审核失败

    //订单状态
    public static final int ORDER_WAIT_PAY = 1;//待付款
    public static final int ORDER_WAIT_DELIVER = 2;//待发货
    public static final int ORDER_WAIT_RECEIVE = 3;//待收货
    public static final int ORDER_WAIT_EVALUATE = 4;//待评价
    public static final int ORDER_COMPLETED = 5;//已完成
    public static final int ORDER_UNUSED = 6;//待使用
    public static final int ORDER_AFTER_SALE = 7;//售后中
    public static final int ORDER_REFUND_SUCCESS = 8;//退款成功
    public static final int ORDER_CANCEL = 9;//已取消

    //优惠券使用状态
    public static final int COUPON_UNUSED = 1;//未使用
    public static final int COUPON_USED = 2;//已使用

    //优惠券类型
    public static final int COUPON_TYPE_FOOD = 1;//餐饮券
    public static final int COUPON_TYPE_ACTIVE = 2;//活动券
    public static final int COUPON_TYPE_GOODS = 3;//商品券

    //售后商品状态
    public static final int GOOD_STATUS_NOPAY = 1;//未付款
    public static final int GOOD_STATUS_PAID = 2;//已付款
    public static final int GOOD_STATUS_REFUNDING = 3;//售后中
    public static final int GOOD_STATUS_REFUNDED = 4;//已退款

    //售后类型
    public static final int REFUND_TYPE_REFUND = 1;//仅退款
    public static final int REFUND_TYPE_RETURN = 2;//退款退货

    //售后状态
    public static final int REFUND_STATUS_APPLYING = 1;//申请中
    public static final int REFUND_STATUS_PROCESSING = 2;//处理中
    public static final int REFUND_STATUS_RETURN = 3;//待返货
    public static final int REFUND_STATUS_REFUND = 4;//退款中
    public static final int REFUND_STATUS_SUCCESS = 5;//已完成
    public static final int REFUND_STATUS_CANCEL = 6;//已取消
    public static final int REFUND_STATUS_FAILURE = 7;//申请失败

    //售后申请时间限制
    public static final int REFUND_RETURN_TIME = 7;//退款退货限制7天以内
}
