package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.Attractions;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * Created by z1ven on 2018/1/31 16:58
 */
@Mapper
public interface AttractionsMapper {

    @Insert("INSERT INTO tb_attractions(name, image, robot_id, remark) VALUES(#{name}, #{image}, #{robot_id}, #{remark})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Attractions attractions);

    @Delete("DELETE FROM tb_attractions WHERE id = #{id}")
    int deleteById(Integer id);

    @Select("SELECT * FROM tb_attractions WHERE id = #{id}")
    Attractions selectById(Integer id);

    @Select("SELECT * FROM tb_attractions LIMIT #{offset}, #{pageSize}")
    List<Attractions> selectPage(@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_attractions WHERE robot_id = #{robot_id}")
    Attractions selectByRobotId(Integer robot_id);

    @Select("SELECT COUNT(*) FROM tb_attractions")
    int count();

    @Update("UPDATE tb_attractions SET name = #{name}, image = #{image}, robot_id = #{robot_id}, remark = #{remark} WHERE id = #{id}")
    int update(Attractions attractions);
}
