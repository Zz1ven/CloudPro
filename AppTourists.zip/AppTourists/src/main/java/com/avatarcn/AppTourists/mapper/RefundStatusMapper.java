package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.RefundStatus;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * Created by z1ven on 2018/3/6 14:29
 */
@Mapper
public interface RefundStatusMapper {

    @Insert("INSERT INTO tb_refund_status(name) VALUES(#{name})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(RefundStatus refundStatus);

    @Delete("DELETE FROM tb_refund_status WHERE id = #{id}")
    int delete(Integer id);

    @Update("UPDATE tb_refund_status SET name = #{name} WHERE id = #{id}")
    int update(RefundStatus refundStatus);

    @Select("SELECT * FROM tb_refund_status WHERE id = #{id}")
    RefundStatus selectById(Integer id);

    @Select("SELECT * FROM tb_refund_status")
    List<RefundStatus> selectAll();
}
