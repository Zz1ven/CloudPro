package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.feign.RobotNetService;
import com.avatarcn.AppTourists.feign.RobotService;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.AppIdResponse;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.json.response.RobotInfoResponse;
import com.avatarcn.AppTourists.json.response.attractions.AttractionsResponse;
import com.avatarcn.AppTourists.mapper.AttractionsMapper;
import com.avatarcn.AppTourists.model.Attractions;
import com.avatarcn.AppTourists.model.robot.Robot;
import com.avatarcn.AppTourists.model.robotnet.AppRobot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by z1ven on 2018/1/31 17:03
 */
@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 60000, rollbackFor = Exception.class)
public class AttractionsService {

    @Autowired
    private AttractionsMapper attractionsMapper;

    @Autowired
    private RobotNetService robotNetService;

    @Autowired
    private RobotService robotService;

    @Autowired
    private OssService ossService;

    public Attractions addAttractions(String name, String image, String app_id, String robot_number, String remark) throws ErrorCodeException {
        Attractions attractions = new Attractions();
        attractions.setName(name);
        attractions.setRemark(remark);
        JsonBean<RobotInfoResponse> robotInfoResponseJsonBean = robotService.getRobotInfoByRobotNumber(robot_number);
        if (!robotInfoResponseJsonBean.isSuccess()) {
            throw new ErrorCodeException(new ErrorCode(robotInfoResponseJsonBean.getError_code(), robotInfoResponseJsonBean.getMsg()));
        }
        //绑定机器人和APP
        JsonBean<AppRobot> appRobotJsonBean = robotNetService.bindAppRobot(app_id, robot_number, true, name, remark);
        if (!appRobotJsonBean.isSuccess()) {
            JsonBean<AppIdResponse> appIdResponseJsonBean = robotNetService.get_appid(robot_number);
            if (!appIdResponseJsonBean.isSuccess()) {
                throw new ErrorCodeException(new ErrorCode(appIdResponseJsonBean.getError_code(), appIdResponseJsonBean.getMsg()));
            }
            if (!appIdResponseJsonBean.getData().getApp_id().equals(app_id)) {//绑定的不同的app_id
                throw new ErrorCodeException(new ErrorCode(appRobotJsonBean.getError_code(), appRobotJsonBean.getMsg()));
            }
        }
        //机器人未和景点绑定
        Attractions attr = attractionsMapper.selectByRobotId(robotInfoResponseJsonBean.getData().getRobot().getId());
        if (attr != null) {
            throw new ErrorCodeException(TouristsErrorCode.ATTRACTIONS_REPEAT);
        }
        if (image != null && !image.isEmpty()) {
            String url = ossService.copyFileTo(image, Constant.TOURISTS_TMP_DIR, Constant.TOURISTS_ATTRACTIONS_DIR);
            attractions.setImage(url);
        }
        attractions.setRobot_id(robotInfoResponseJsonBean.getData().getRobot().getId());
        attractionsMapper.insert(attractions);
        return attractions;
    }

    public Integer deleteAttractions(Integer id) throws ErrorCodeException {
        Attractions attractions = attractionsMapper.selectById(id);
        if (attractions == null) {
            throw new ErrorCodeException(TouristsErrorCode.ATTRACTIONS_NULL);
        }
        if (attractionsMapper.deleteById(id) != 1) {
            throw new ErrorCodeException(ErrorCodeException.DELETE_NO);
        }
        ossService.delete(attractions.getImage());
        return 1;
    }

    public AttractionsResponse selectById(Integer id) throws ErrorCodeException {
        Attractions attractions = attractionsMapper.selectById(id);
        if (attractions == null) {
            throw new ErrorCodeException(TouristsErrorCode.ATTRACTIONS_NULL);
        }
        JsonBean<Robot> robotJsonBean = robotService.getRobotById(attractions.getRobot_id());
        if (!robotJsonBean.isSuccess()) {
            throw new ErrorCodeException(new ErrorCode(robotJsonBean.getError_code(), robotJsonBean.getMsg()));
        }
        JsonBean<RobotInfoResponse> robotInfoResponseJsonBean = robotService.getRobotInfoByRobotNumber(robotJsonBean.getData().getRobot_number());
        if (!robotInfoResponseJsonBean.isSuccess()) {
            throw new ErrorCodeException(new ErrorCode(robotInfoResponseJsonBean.getError_code(), robotInfoResponseJsonBean.getMsg()));
        }
        AttractionsResponse attractionsResponse = new AttractionsResponse();
        attractionsResponse.setId(attractions.getId());
        attractionsResponse.setName(attractions.getName());
        attractionsResponse.setImage(attractions.getImage());
        attractionsResponse.setRemark(attractions.getRemark());
        attractionsResponse.setRobot_id(attractions.getRobot_id());
        attractionsResponse.setRobot_code(robotJsonBean.getData().getRobot_code());
        attractionsResponse.setRobot_number(robotJsonBean.getData().getRobot_number());
        attractionsResponse.setPower(robotInfoResponseJsonBean.getData().getPower() == null ? 0 : robotInfoResponseJsonBean.getData().getPower().getPower());
        attractionsResponse.setOnline(robotInfoResponseJsonBean.getData().getOnline() == null ? false : robotInfoResponseJsonBean.getData().getOnline().getIs_online());
        return attractionsResponse;
    }

    public PageResponse<AttractionsResponse> selectPage(Integer offset, Integer pageSize) throws ErrorCodeException {
        List<Attractions> attractionsList = attractionsMapper.selectPage(offset, pageSize);
        List<AttractionsResponse> attractionsResponseList = new ArrayList<>();
        for (Attractions attractions : attractionsList) {
            JsonBean<Robot> robotJsonBean = robotService.getRobotById(attractions.getRobot_id());
            if (!robotJsonBean.isSuccess()) {
                throw new ErrorCodeException(new ErrorCode(robotJsonBean.getError_code(), robotJsonBean.getMsg()));
            }
            JsonBean<RobotInfoResponse> robotInfoResponseJsonBean = robotService.getRobotInfoByRobotNumber(robotJsonBean.getData().getRobot_number());
            if (!robotInfoResponseJsonBean.isSuccess()) {
                throw new ErrorCodeException(new ErrorCode(robotInfoResponseJsonBean.getError_code(), robotInfoResponseJsonBean.getMsg()));
            }
            AttractionsResponse attractionsResponse = new AttractionsResponse();
            attractionsResponse.setId(attractions.getId());
            attractionsResponse.setName(attractions.getName());
            attractionsResponse.setImage(attractions.getImage());
            attractionsResponse.setRemark(attractions.getRemark());
            attractionsResponse.setRobot_id(attractions.getRobot_id());
            attractionsResponse.setRobot_code(robotJsonBean.getData().getRobot_code());
            attractionsResponse.setRobot_number(robotJsonBean.getData().getRobot_number());
            attractionsResponse.setPower(robotInfoResponseJsonBean.getData().getPower() == null ? 0 : robotInfoResponseJsonBean.getData().getPower().getPower());
            attractionsResponse.setOnline(robotInfoResponseJsonBean.getData().getOnline() == null ? false : robotInfoResponseJsonBean.getData().getOnline().getIs_online());
            attractionsResponseList.add(attractionsResponse);
        }
        PageResponse<AttractionsResponse> attractionsResponsePageResponse = new PageResponse<>();
        attractionsResponsePageResponse.setItem(attractionsResponseList);
        attractionsResponsePageResponse.setOffset(offset);
        attractionsResponsePageResponse.setPageSize(pageSize);
        attractionsResponsePageResponse.setTotal(attractionsMapper.count());
        return attractionsResponsePageResponse;
    }

    public Attractions updateAttractions(Integer id, String name, String image, String app_id, String robot_number, String remark) throws ErrorCodeException {
        Attractions attractions = attractionsMapper.selectById(id);
        if (attractions == null) {
            throw new ErrorCodeException(TouristsErrorCode.ATTRACTIONS_NULL);
        }
        attractions.setName(name);
        if (remark != null && !remark.isEmpty()) {
            attractions.setRemark(remark);
        }
        JsonBean<RobotInfoResponse> robotInfoResponseJsonBean = robotService.getRobotInfoByRobotNumber(robot_number);
        if (!robotInfoResponseJsonBean.isSuccess()) {
            throw new ErrorCodeException(new ErrorCode(robotInfoResponseJsonBean.getError_code(), robotInfoResponseJsonBean.getMsg()));
        }
        if (robotInfoResponseJsonBean.getData().getRobot().getId().intValue() != attractions.getRobot_id()) {//修改了绑定机器人
            //绑定机器人和APP
            JsonBean<AppRobot> appRobotJsonBean = robotNetService.bindAppRobot(app_id, robot_number, true, name, remark);
            if (!appRobotJsonBean.isSuccess()) {
                JsonBean<AppIdResponse> appIdResponseJsonBean = robotNetService.get_appid(robot_number);
                if (!appIdResponseJsonBean.isSuccess())
                    throw new ErrorCodeException(new ErrorCode(appIdResponseJsonBean.getError_code(), appIdResponseJsonBean.getMsg()));
                if (!appIdResponseJsonBean.getData().getApp_id().equals(app_id))
                    throw new ErrorCodeException(new ErrorCode(appRobotJsonBean.getError_code(), appRobotJsonBean.getMsg()));
            }
            //机器人未和景点绑定
            Attractions attr = attractionsMapper.selectByRobotId(robotInfoResponseJsonBean.getData().getRobot().getId());
            if (attr != null) {
                throw new ErrorCodeException(TouristsErrorCode.ATTRACTIONS_REPEAT);
            }
            attractions.setRobot_id(robotInfoResponseJsonBean.getData().getRobot().getId());
        }
        if (image != null && !image.isEmpty()) {
            if (attractions.getImage() == null || !image.equals(attractions.getImage())) {
                String url = ossService.copyFileTo(image, Constant.TOURISTS_TMP_DIR, Constant.TOURISTS_ATTRACTIONS_DIR);
                attractions.setImage(url);
            }
        }
        attractionsMapper.update(attractions);
        return attractions;
    }

}
