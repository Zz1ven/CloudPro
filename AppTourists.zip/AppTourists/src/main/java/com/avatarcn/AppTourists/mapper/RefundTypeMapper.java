package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.RefundType;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * Created by z1ven on 2018/3/6 11:25
 */
@Mapper
public interface RefundTypeMapper {

    @Insert("INSERT INTO tb_refund_type(name) VALUES(#{name})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(RefundType refundType);

    @Delete("DELETE FROM tb_refund_type WHERE id = #{id}")
    int delete(Integer id);

    @Select("SELECT * FROM tb_refund_type WHERE id = #{id}")
    RefundType selectById(Integer id);

    @Select("SELECT * FROM tb_refund_type")
    List<RefundType> selectAll();

    @Update("UPDATE tb_refund_type SET name = #{name} WHERE id = #{id}")
    int update(RefundType refundType);
}
