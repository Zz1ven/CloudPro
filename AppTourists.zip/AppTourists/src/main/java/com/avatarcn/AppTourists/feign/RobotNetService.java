package com.avatarcn.AppTourists.feign;

import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.AppIdResponse;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.json.response.RobotInfoResponse;
import com.avatarcn.AppTourists.model.robotnet.*;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by MDF on 2017-11-6.
 */

@FeignClient("SERVICE-ROBOTNET-API")
public interface RobotNetService {
    @RequestMapping(value = "/v1/manager/apps/{app_id}",method = RequestMethod.GET)
    JsonBean<App> getApp(@PathVariable("app_id") String app_id);

    @RequestMapping(value = "/v1/app/robot",method = RequestMethod.POST)
    JsonBean<AppRobot> bindAppRobot(@RequestParam("app_id") String app_id,
                                    @RequestParam("robot_number") String robot_number,
                                    @RequestParam("is_open") Boolean is_open,
                                    @RequestParam("name") String name,
                                    @RequestParam("remark") String remark);

    @RequestMapping(value = "/v1/app/robot/{robot_number}",method = RequestMethod.DELETE)
    JsonBean<AppRobot> unbindAppRobot(@PathVariable("robot_number") String robot_number, @RequestParam("app_id") String app_id);

    //创建group
    @RequestMapping(value = "/v1/app/group",method = RequestMethod.POST)
    JsonBean<AppGroup>  greateAppGroup(@RequestParam("app_id") String app_id, @RequestParam("name") String name, @RequestParam(value = "remark", required = false) String remark);

    //删除group
    @RequestMapping(value = "/v1/app/group/{group_id}",method = RequestMethod.DELETE)
    JsonBean  deleteAppGroup(@PathVariable("group_id") Integer group_id, @RequestParam("app_id") String app_id);

    //创建app
    @RequestMapping(value = "/v1/manager/apps",method = RequestMethod.POST)
    JsonBean<App> greateApp(@RequestParam("remark") String remark);

    //删除app
    @RequestMapping(value = "/v1/manager/apps/{app_id}",method = RequestMethod.DELETE)
    JsonBean<App> deleteApp(@PathVariable("app_id") String app_id);

    //通过robot_number获取Group
    @RequestMapping(value = "/v1/app/robot/group",method = RequestMethod.GET)
    JsonBean<GroupRobot> getGropByRobotNumber(@RequestParam("robot_number") String robot_number);


    //创建用户
    @RequestMapping(value = "/v1/app/user",method = RequestMethod.POST)
    JsonBean<AppUser>  app_user(@RequestParam("user") String user, @RequestParam("app_id") String app_id);

    //列出幼儿园下所有的机器人
    @RequestMapping(value = "/v1/app/robot",method = RequestMethod.GET)
    JsonBean<PageResponse<RobotInfoResponse>> getAllRobots(@RequestParam("app_id") String app_id, @RequestParam("offset") Integer offset, @RequestParam("pageSize") Integer pageSize);

    //列出共享下的机器人
    @RequestMapping(value = "/v1/app/robot_open",method = RequestMethod.GET)
    JsonBean<PageResponse<RobotInfoResponse>> robot_open(@RequestParam("app_id") String app_id, @RequestParam("offset") Integer offset, @RequestParam("pageSize") Integer pageSize);

    //列出班级下的所有的机器人
    @RequestMapping(value = "/v1/app/group/{group_id}/robot",method = RequestMethod.GET)
    JsonBean<PageResponse<GroupRobot>> getClassesRobots(@PathVariable("group_id") Integer group_id, @RequestParam("app_id") String app_id, @RequestParam("offset") Integer offset, @RequestParam("pageSize") Integer pageSize);

    //用户与群组绑定
    @RequestMapping(value = "/v1/app/group/{group_id}/user",method = RequestMethod.POST)
    JsonBean<GroupUser>  userBindGroup(@PathVariable("group_id") Integer group_id, @RequestParam("app_id") String app_id, @RequestParam("user") String user);

    //通过robot_number获取appID
    @RequestMapping(value = "/v1/app/number/appid",method = RequestMethod.GET)
    JsonBean<AppIdResponse>  get_appid(@RequestParam("robot_number") String robot_number);

    //修改app机器人
    @RequestMapping(value = "/v1/app/robot/{robot_number}",method = RequestMethod.PUT)
    JsonBean<AppRobot> robot_edit(@RequestParam("app_id") String app_id,
                                  @PathVariable("robot_number") String robot_number,
                                  @RequestParam("is_open") Boolean is_open,
                                  @RequestParam("name") String name,
                                  @RequestParam("remark") String remark);


    //列出未开放的机器人
    @RequestMapping(value = "/v1/app/robot_close",method = RequestMethod.GET)
    JsonBean<PageResponse<RobotInfoResponse>> robot_close(@RequestParam("app_id") String app_id, @RequestParam("offset") Integer offset, @RequestParam("pageSize") Integer pageSize);

    //列出班级下未绑定的机器人
    @RequestMapping(value = "/v1/app/robot_groupNoBind",method = RequestMethod.GET)
    JsonBean<PageResponse<RobotInfoResponse>> robot_groupNoBind(@RequestParam("app_id") String app_id, @RequestParam("offset") Integer offset, @RequestParam("pageSize") Integer pageSize);
}

