package com.avatarcn.AppTourists.controller;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.domain.AlipayTradeQueryModel;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.request.AlipayTradeAppPayRequest;
import com.alipay.api.request.AlipayTradeQueryRequest;
import com.alipay.api.response.AlipayTradeAppPayResponse;
import com.alipay.api.response.AlipayTradeQueryResponse;
import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.model.Active;
import com.avatarcn.AppTourists.model.ActiveOrder;
import com.avatarcn.AppTourists.model.OrderInfo;
import com.avatarcn.AppTourists.service.ActiveOrderService;
import com.avatarcn.AppTourists.service.ActiveService;
import com.avatarcn.AppTourists.service.AlipayService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Created by z1ven on 2018/2/26 08:51
 */
@Api(value = "/v1/alipay", description = "支付宝支付")
@RequestMapping(value = "/v1/alipay")
@RestController
public class AlipayController {

    private Logger logger = LoggerFactory.getLogger(AlipayController.class);

    @Value("${alipay.appid}")
    private String appid;

    @Value("${alipay.key.alipay}")
    private String key_alipay;

    @Value("${alipay.seller.id}")
    private String seller_id;

    @Autowired
    private AlipayClient alipayClient;

    @Autowired
    private AlipayService alipayService;

    @ApiOperation("获取请求订单签名字符串")
    @RequestMapping(value = "/pay", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<String> pay(@ApiParam(value = "订单号", required = true) @RequestParam(value = "number") String number) {
        try {
            AlipayTradeAppPayModel model = alipayService.getModelByNumber(number);
            //实例化具体API对应的request类,类名称和接口名称对应,当前调用接口名称：alipay.trade.app.pay
            AlipayTradeAppPayRequest request = new AlipayTradeAppPayRequest();
            //SDK已经封装掉了公共参数，这里只需要传入业务参数。以下方法为sdk的model入参方式(model和biz_content同时存在的情况下取biz_content)。
            request.setBizModel(model);
            request.setNotifyUrl("http://118.31.165.67:8600/app/v1/alipay/pay/notify");//网关回调接口
            try {
                //这里和普通的接口调用不同，使用的是sdkExecute
                AlipayTradeAppPayResponse response = alipayClient.sdkExecute(request);
                return new JsonBean<>(ErrorCode.SUCCESS, response.getBody());
            } catch (AlipayApiException e) {
                e.printStackTrace();
                return new JsonBean<>(new ErrorCode(1, "支付异常:" + e.getErrCode() + ":" + e.getErrMsg()));
            }
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("回调地址")
    @RequestMapping(value = "/pay/notify", method = RequestMethod.POST)
    @ResponseBody
    public String payNotify(@RequestBody Map<String, String> params) {
        //异步通知
        //切记alipaypublickey是支付宝的公钥，请去open.alipay.com对应应用下查看。
        //boolean AlipaySignature.rsaCheckV1(Map<String, String> params, String publicKey, String charset, String sign_type)
        try {
            boolean flag = AlipaySignature.rsaCheckV1(params, key_alipay, "utf-8","RSA2");
            if (flag) {
                String out_trade_no1 = params.get("out_trade_no");
                String total_amount1 = params.get("total_amount");
                String seller_id1 = params.get("seller_id");
                String app_id1 = params.get("app_id");
                String trade_status1 = params.get("trade_status");
                //验签成功,校验数据
                if (alipayService.checkTradeData(out_trade_no1, total_amount1, seller_id, seller_id1, appid, app_id1)) {
                    //校验通过
                    //修改订单状态
                    if (trade_status1.equals("TRADE_SUCCESS") || trade_status1.equals("TRADE_FINISHED")) {
                        try {
                            if (alipayService.paySuccess(out_trade_no1)) {
                                return "success";
                            }
                        } catch (ErrorCodeException e) {
                            return "failure";
                        }
                    } else {
                        return "failure";
                    }
                }
                return "failure";
            } else {
                logger.warn("支付失败,验签异常");
                return "failure";
            }
        } catch (AlipayApiException e) {
            logger.error(e.getErrCode() + e.getErrMsg());
            return "failure";
        }
    }

    @ApiOperation("查询订单支付状态")
    @RequestMapping(value = "/pay/status", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<String> payStatus(@ApiParam(value = "支付宝系统的交易流水号", required = true) @RequestParam(value = "trade_no") String trade_no,
                                      @ApiParam(value = "商户网站唯一订单号", required = true) @RequestParam(value = "out_trade_no") String out_trade_no) {
        AlipayTradeQueryRequest request = new AlipayTradeQueryRequest();//创建API对应的request类
        AlipayTradeQueryModel model = new AlipayTradeQueryModel();
        model.setTradeNo(trade_no);
        model.setOutTradeNo(out_trade_no);
        request.setBizModel(model);
        AlipayTradeQueryResponse response;
        try {
            response = alipayClient.execute(request);
            return new JsonBean<>(ErrorCode.SUCCESS, response.getBody());
        } catch (AlipayApiException e) {
            //e.printStackTrace();
            return new JsonBean<>(new ErrorCode(1, e.getErrCode() + e.getErrMsg()));
        }
    }
}
