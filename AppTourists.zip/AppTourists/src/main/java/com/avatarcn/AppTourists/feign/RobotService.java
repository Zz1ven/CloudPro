package com.avatarcn.AppTourists.feign;

import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.RobotInfoResponse;
import com.avatarcn.AppTourists.model.robot.Robot;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by z1ven on 2018/1/31 17:29
 */
@FeignClient("SERVICE-ROBOT-API")
public interface RobotService {

    @RequestMapping(value = "/v1/robot/robot_info_number", method = RequestMethod.GET)
    JsonBean<RobotInfoResponse> getRobotInfoByRobotNumber(@RequestParam(value = "robot_number") String robot_number);

    @RequestMapping(value = "/v1/robot_manager/robots/{id}", method = RequestMethod.GET)
    JsonBean<Robot> getRobotById(@PathVariable(value = "id") Integer id);
}
