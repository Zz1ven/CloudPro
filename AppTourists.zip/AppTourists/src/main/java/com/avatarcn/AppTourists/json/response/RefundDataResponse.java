package com.avatarcn.AppTourists.json.response;

import com.avatarcn.AppTourists.model.RefundType;
import com.avatarcn.AppTourists.model.Speciality;

import java.util.List;

/**
 * Created by z1ven on 2018/3/7 09:09
 */
public class RefundDataResponse {
    private float refund;
    private RefundType refundType;
    private List<Speciality> specialityList;

    public float getRefund() {
        return refund;
    }

    public void setRefund(float refund) {
        this.refund = refund;
    }

    public RefundType getRefundType() {
        return refundType;
    }

    public void setRefundType(RefundType refundType) {
        this.refundType = refundType;
    }

    public List<Speciality> getSpecialityList() {
        return specialityList;
    }

    public void setSpecialityList(List<Speciality> specialityList) {
        this.specialityList = specialityList;
    }
}