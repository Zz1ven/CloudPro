package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.feign.UserServiceFeign;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.model.UserAddress;
import com.avatarcn.AppTourists.model.user.User;
import com.avatarcn.AppTourists.service.UserAddressService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by z1ven on 2018/3/2 09:51
 */
@Api(value = "/v1/user/address", description = "用户地址模块")
@RequestMapping(value = "/v1/user/address")
@RestController
public class UserAddressController {

    @Autowired
    private UserAddressService userAddressService;

    @Autowired
    private UserServiceFeign userServiceFeign;

    @ApiOperation("用户添加一个收货地址信息")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<UserAddress> addUserAddress(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                @ApiParam(value = "收货人姓名", required = true) @RequestParam(value = "name") String name,
                                                @ApiParam(value = "收货人联系方式", required = true) @RequestParam(value = "phone") String phone,
                                                @ApiParam(value = "邮政编码") @RequestParam(value = "postalcode", required = false) String postalcode,
                                                @ApiParam(value = "地址", required = true) @RequestParam(value = "address") String address,
                                                @ApiParam(value = "是否设为默认地址", required = true) @RequestParam(value = "default_tag") Boolean default_tag) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, userAddressService.insert(userJsonBean.getData().getId(), name, phone, postalcode, address, default_tag));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("用户删除指定的地址")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonBean<Integer> deleteUserAddress(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, userAddressService.deleteById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定的地址信息")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<UserAddress> getUserAddressById(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, userAddressService.selectById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取指定用户的地址信息")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<UserAddress>> getPageByUserId(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                               @ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                               @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, userAddressService.selectPage(userJsonBean.getData().getId(), offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("用户修改指定的地址信息")
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonBean<UserAddress> updateUserAddress(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                                   @ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                   @ApiParam(value = "收货人姓名", required = true) @RequestParam(value = "name") String name,
                                                   @ApiParam(value = "收货人联系方式", required = true) @RequestParam(value = "phone") String phone,
                                                   @ApiParam(value = "邮政编码") @RequestParam(value = "postalcode", required = false) String postalcode,
                                                   @ApiParam(value = "地址", required = true) @RequestParam(value = "address") String address) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, userAddressService.update(id, userJsonBean.getData().getId(), name, phone, postalcode, address));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取用户的默认地址")
    @RequestMapping(value = "/default", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<UserAddress> getDefaultAddress(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, userAddressService.getDefaultAddress(userJsonBean.getData().getId()));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("用户修改指定地址为默认地址")
    @RequestMapping(value = "/default/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonBean<Integer> updateDefaultAddress(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                                  @ApiParam(value = "token", required = true) @RequestParam(value = "token") String token) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, userAddressService.updateDefaultTag(id, userJsonBean.getData().getId()));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }
}
