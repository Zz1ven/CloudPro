package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.feign.UserServiceFeign;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.news.NewsUpResponse;
import com.avatarcn.AppTourists.mapper.AccountMapper;
import com.avatarcn.AppTourists.mapper.NewsMapper;
import com.avatarcn.AppTourists.mapper.NewsUpMapper;
import com.avatarcn.AppTourists.model.News;
import com.avatarcn.AppTourists.model.NewsUp;
import com.avatarcn.AppTourists.model.user.Account;
import com.avatarcn.AppTourists.model.user.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * Created by z1ven on 2018/1/17 17:07
 */
@Service
public class NewsUpService {

    @Autowired
    private NewsUpMapper newsUpMapper;

    @Autowired
    private NewsMapper newsMapper;

    @Autowired
    private UserServiceFeign userServiceFeign;

    @Autowired
    private AccountMapper accountMapper;

    public NewsUpResponse addNewsUp(Integer userId, Integer newsId) throws ErrorCodeException {
        JsonBean<UserInfo> userInfoJsonBean = userServiceFeign.info_get(userId);
        if (!userInfoJsonBean.isSuccess()) {
            throw new ErrorCodeException(new ErrorCode(userInfoJsonBean.getError_code(), userInfoJsonBean.getMsg()));
        }
        News news = newsMapper.selectById(newsId);
        if (news == null) {
            throw new ErrorCodeException(ErrorCodeException.DATA_NO_ERROR);
        }
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        UserInfo userInfo = userInfoJsonBean.getData();
        NewsUp newsUp = newsUpMapper.selectByNewsIdAndUserId(newsId, userId);
        NewsUpResponse newsUpResponse = new NewsUpResponse();
        if (newsUp == null) {
            newsUp = new NewsUp();
            newsUp.setFk_tb_user_id(account.getId());
            newsUp.setFk_tb_news_id(newsId);
            newsUp.setTime(new Date());
            newsUpMapper.insert(newsUp);
        }
        newsUpResponse.setId(newsUp.getId());
        newsUpResponse.setNews_id(newsUp.getFk_tb_news_id());
        newsUpResponse.setUser_id(newsUp.getFk_tb_user_id());
        newsUpResponse.setNickname(userInfo.getNickname());
        newsUpResponse.setUserUrl(userInfo.getImg());
        return newsUpResponse;
    }

    public int deleteNewsUp(Integer userId, Integer newsId) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        if (newsUpMapper.deleteByNewsIdAndUserId(newsId, account.getId()) != 1) {
            throw new ErrorCodeException(ErrorCodeException.DATA_NO_ERROR);
        }
        return 1;
    }

    /**
     * 用户是否点赞该新闻
     * @return
     */
    public boolean userIsUp(Integer userId, Integer newsId) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        NewsUp newsUp = newsUpMapper.selectByNewsIdAndUserId(newsId, account.getId());
        if (newsUp != null) {
            return true;
        }
        return false;
    }
}
