package com.avatarcn.AppTourists;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@EnableFeignClients
@EnableDiscoveryClient
@SpringBootApplication
public class AppTouristsApplication {
	private static Logger logger = Logger.getLogger(AppTouristsApplication.class);

	public static void main(String[] args) throws Exception {
		SpringApplication.run(AppTouristsApplication.class, args);
		logger.info("============= SpringBoot Start Success =============");
	}

}
