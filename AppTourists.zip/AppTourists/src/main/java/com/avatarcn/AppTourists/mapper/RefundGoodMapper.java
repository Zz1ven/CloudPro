package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.RefundGood;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

/**
 * Created by z1ven on 2018/3/6 15:24
 */
@Mapper
public interface RefundGoodMapper {

    @Insert("INSERT INTO tb_refund_good(fk_tb_refund_status_id, fk_tb_refund_type_id, fk_tb_user_id, money, reason, order_number, out_request_no, path, express_company, express_no, visible, time) VALUES(#{fk_tb_refund_status_id}, #{fk_tb_refund_type_id}, #{fk_tb_user_id}, #{money}, #{reason}, #{order_number}, #{out_request_no}, #{path}, #{express_company}, #{express_no}, #{visible}, #{time})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(RefundGood refundGood);

    @Delete("DELETE FROM tb_refund_good WHERE id = #{id}")
    int delete(Integer id);

    @Update("UPDATE tb_refund_good SET fk_tb_refund_status_id = #{fk_tb_refund_status_id}, fk_tb_refund_type_id = #{fk_tb_refund_type_id}, fk_tb_user_id = #{fk_tb_user_id}, money = #{money}, reason = #{reason}, order_number = #{order_number}, out_request_no = #{out_request_no}, path = #{path}, express_company = #{express_company}, express_no = #{express_no}, visible = #{visible}, time = #{time} WHERE id = #{id}")
    int update(RefundGood refundGood);

    @Update("UPDATE tb_refund_good SET visible = #{visible} WHERE id = #{id}")
    int updateVisible(@Param("id") Integer id , @Param("visible") boolean visible);

    @Update("UPDATE tb_refund_good SET fk_tb_refund_status_id = #{fk_tb_refund_status_id} WHERE id = #{id}")
    int updateStatus(@Param("id") Integer id, @Param("fk_tb_refund_status_id") Integer fk_tb_refund_status_id);

    @Update("UPDATE tb_refund_good SET express_company = #{express_company}, express_no = #{express_no} WHERE id = #{id}")
    int updateExpress(@Param("id") Integer id, @Param("express_company") String express_company, @Param("express_no") String express_no);

    @Select("SELECT * FROM tb_refund_good WHERE id = #{id}")
    RefundGood selectById(Integer id);

    @Select("SELECT * FROM tb_refund_good WHERE id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fk_tb_refund_status_id", column = "fk_tb_refund_status_id"),
            @Result(property = "fk_tb_refund_type_id", column = "fk_tb_refund_type_id"),
            @Result(property = "refundStatus", column = "fk_tb_refund_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundStatusMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundType", column = "fk_tb_refund_type_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundTypeMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundGoodMenuList", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.RefundGoodMenuMapper.selectByRefundGoodId", fetchType = FetchType.LAZY))
    })
    RefundGood selectDetailById(Integer id);

    @Select("SELECT * FROM tb_refund_good WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1 ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fk_tb_refund_status_id", column = "fk_tb_refund_status_id"),
            @Result(property = "fk_tb_refund_type_id", column = "fk_tb_refund_type_id"),
            @Result(property = "refundStatus", column = "fk_tb_refund_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundStatusMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundType", column = "fk_tb_refund_type_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundTypeMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundGoodMenuList", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.RefundGoodMenuMapper.selectByRefundGoodId", fetchType = FetchType.LAZY))
    })
    List<RefundGood> selectPageByUserId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_refund_good ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fk_tb_refund_status_id", column = "fk_tb_refund_status_id"),
            @Result(property = "fk_tb_refund_type_id", column = "fk_tb_refund_type_id"),
            @Result(property = "refundStatus", column = "fk_tb_refund_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundStatusMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundType", column = "fk_tb_refund_type_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundTypeMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundGoodMenuList", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.RefundGoodMenuMapper.selectByRefundGoodId", fetchType = FetchType.LAZY))
    })
    List<RefundGood> selectPage(@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT COUNT(*) FROM tb_refund_good WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1")
    int countByUserId(Integer fk_tb_user_id);

    @Select("SELECT COUNT(*) FROM tb_refund_good")
    int count();
}
