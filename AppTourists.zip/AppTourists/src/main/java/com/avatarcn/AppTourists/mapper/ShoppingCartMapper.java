package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.ShoppingCart;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

/**
 * Created by z1ven on 2018/3/1 09:23
 */
@Mapper
public interface ShoppingCartMapper {

    @Insert("INSERT INTO tb_shopping_cart(fk_tb_user_id, fk_tb_speciality_id, amount, time) VALUES(#{fk_tb_user_id}, #{fk_tb_speciality_id}, #{amount}, #{time})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(ShoppingCart shoppingCart);

    @Delete("DELETE FROM tb_shopping_cart WHERE id = #{id}")
    int deleteById(Integer id);

    @Delete("DELETE FROM tb_shopping_cart WHERE fk_tb_speciality_id = #{fk_tb_speciality_id}")
    int deleteBySpecialityId(Integer fk_tb_speciality_id);

    @Select("SELECT * FROM tb_shopping_cart WHERE id = #{id}")
    @Results({
            @Result(property = "fk_tb_speciality_id", column = "fk_tb_speciality_id"),
            @Result(property = "speciality", column = "fk_tb_speciality_id", one = @One(select = "com.avatarcn.AppTourists.mapper.SpecialityMapper.selectByPrimaryKey", fetchType = FetchType.LAZY))
    })
    ShoppingCart selectById(Integer id);

    @Select("SELECT * FROM tb_shopping_cart WHERE fk_tb_user_id = #{fk_tb_user_id} ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "fk_tb_speciality_id", column = "fk_tb_speciality_id"),
            @Result(property = "speciality", column = "fk_tb_speciality_id", one = @One(select = "com.avatarcn.AppTourists.mapper.SpecialityMapper.selectByPrimaryKey", fetchType = FetchType.LAZY))
    })
    List<ShoppingCart> selectByUserId(@Param(value = "fk_tb_user_id") Integer fk_tb_user_id, @Param(value = "offset") Integer offset, @Param(value = "pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_shopping_cart WHERE fk_tb_user_id = #{fk_tb_user_id} AND fk_tb_speciality_id = #{fk_tb_speciality_id}")
    ShoppingCart selectByUserIdAndSpecialityId(@Param(value = "fk_tb_user_id") Integer fk_tb_user_id, @Param("fk_tb_speciality_id") Integer fk_tb_speciality_id);

    @Select("SELECT COUNT(*) FROM tb_shopping_cart WHERE fk_tb_user_id = #{fk_tb_user_id}")
    int countByUserId(Integer fk_tb_user_id);

    @Update("UPDATE tb_shopping_cart SET fk_tb_user_id = #{fk_tb_user_id}, fk_tb_speciality_id = #{fk_tb_speciality_id}, amount = #{amount}, time = #{time} WHERE id = #{id}")
    int update(ShoppingCart shoppingCart);
}
