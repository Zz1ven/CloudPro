package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.response.WxpayResponse;
import com.avatarcn.AppTourists.mapper.ActiveMapper;
import com.avatarcn.AppTourists.mapper.ActiveOrderMapper;
import com.avatarcn.AppTourists.mapper.OrderFoodMapper;
import com.avatarcn.AppTourists.mapper.SpecialityOrderMapper;
import com.avatarcn.AppTourists.model.Active;
import com.avatarcn.AppTourists.model.ActiveOrder;
import com.avatarcn.AppTourists.model.OrderFood;
import com.avatarcn.AppTourists.model.SpecialityOrder;
import com.avatarcn.AppTourists.utils.ConfigUtil;
import com.avatarcn.AppTourists.utils.MD5Util;
import com.avatarcn.AppTourists.utils.PayCommonUtil;
import com.avatarcn.AppTourists.utils.XMLUtil;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

/**
 * Created by MDF on 2018-2-27.
 */
@Service
public class WxpayService {
    @Autowired
    private ActiveOrderMapper activeOrderMapper;

    @Autowired
    private ActiveMapper activeMapper;

    @Autowired
    private OrderFoodMapper orderFoodMapper;

    @Autowired
    private SpecialityOrderMapper specialityOrderMapper;

    @Autowired
    private ActiveOrderService activeOrderService;

    @Autowired
    private OrderFoodService orderFoodService;

    @Autowired
    private SpecialityOrderService specialityOrderService;

    private static Logger logger = LoggerFactory.getLogger(AlipayService.class);

    /**
     * 通过订单号获取订单信息
     * @return
     */
    public WxpayResponse getObejectByNumber(String number)throws ErrorCodeException {
        WxpayResponse wxpayResponse=new WxpayResponse();
        ActiveOrder activeOrder = activeOrderMapper.selectByNumber(number);
        if (activeOrder != null) {//活动订单
            if (activeOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_PAY) {
                throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
            }
            Active active = activeMapper.selectById(activeOrder.getFk_tb_active_id());
            wxpayResponse.setBody("武陟山庄-" + (active != null ? active.getName() : ""));
            wxpayResponse.setOut_trade_no(activeOrder.getNumber());
            wxpayResponse.setTotal_fee(Math.round(activeOrder.getReal_money()*100));
            return wxpayResponse;
        }
        OrderFood orderFood = orderFoodMapper.selectByNumber(number);
        if (orderFood != null) {//餐饮订单
            if (orderFood.getFk_tb_order_status_id() != Constant.ORDER_WAIT_PAY) {
                throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
            }
            wxpayResponse.setBody("武陟山庄-餐饮订单");
            wxpayResponse.setOut_trade_no(orderFood.getNumber());
            wxpayResponse.setTotal_fee(Math.round(orderFood.getReal_money()*100));
            return wxpayResponse;
        }
        //商城订单
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(number);
        if (specialityOrder != null) {//特产商城订单
            if (specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_PAY) {
                throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
            }
            wxpayResponse.setBody("武陟山庄-特产商品订单");
            wxpayResponse.setOut_trade_no(specialityOrder.getNumber());
            wxpayResponse.setTotal_fee(Math.round(specialityOrder.getReal_money() * 100));
        }
        return wxpayResponse;
    }

    //校验签名
    public boolean checkSign(Map<String, String> smap){
        StringBuilder sb = new StringBuilder();
        Set es = smap.entrySet();
        for (Object e : es) {
            Map.Entry entry = (Map.Entry) e;
            String k = (String) entry.getKey();
            Object v = entry.getValue();
            if (!"sign".equals(k) && null != v && !"".equals(v) && !"key".equals(k)) {
                sb.append(k).append("=").append(v).append("&");
            }
        }
        sb.append("key=" + ConfigUtil.API_KEY);
        /** 验证的签名 */
        String sign = MD5Util.MD5Encode(sb.toString(), "utf-8").toUpperCase();
        /** 微信端返回的合法签名 */
        String validSign = (smap.get("sign")).toUpperCase();
        return validSign.equals(sign);
    }

    /**
     * 异步通知校验
     * 1.校验订单号
     * 2.校验支付金额
     * 3.校验商户ID
     * 4.校验商户AppId
     * @return
     */
    public boolean checkTradeData(String tradeNo, String totalAmount) {
        //活动订单
        ActiveOrder activeOrder = activeOrderMapper.selectByNumber(tradeNo);
        if (activeOrder != null
                && totalAmount.equals(String.valueOf(Math.round(activeOrder.getReal_money() * 100)))) {
            return true;
        }
        //餐饮订单
        OrderFood orderFood = orderFoodMapper.selectByNumber(tradeNo);
        if (orderFood != null
                && totalAmount.equals(String.valueOf(Math.round(orderFood.getReal_money() * 100)))) {
            return true;
        }
        //商城订单
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(tradeNo);
        if (specialityOrder != null
                && totalAmount.equals(String.valueOf(Math.round(specialityOrder.getReal_money() * 100)))) {
            return true;
        }
        return false;
    }

    /**
     * 订单支付完成处理
     * @return
     */
    public boolean paySuccess(String number) throws ErrorCodeException {
        //根据订单号查找订单
        //活动订单
        ActiveOrder activeOrder = activeOrderMapper.selectByNumber(number);
        if (activeOrder != null) {
            activeOrderService.payActiveOrder(activeOrder.getId());
            activeOrderMapper.updatePayMethod(number, Constant.WXPAY);
            return true;
        }
        //餐饮订单
        OrderFood orderFood = orderFoodMapper.selectByNumber(number);
        if (orderFood != null) {
            orderFoodService.payFoodOrder(orderFood.getId());
            orderFoodMapper.updatePayMethod(number, Constant.WXPAY);
            return true;
        }
        //商城订单
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(number);
        if (specialityOrder != null) {
            specialityOrderService.paySpecialityOrder(specialityOrder.getId());
            specialityOrderMapper.updatePayMethod(number, Constant.WXPAY);
            //商品销量
            return true;
        }
        return false;
    }

    /**
     * WXpay退款请求
     * @return
     */
    public String refundRequest(String out_trade_no, float total_fee, float refund_fee, String out_request_no) {
        SortedMap<Object, Object> map = new TreeMap<>();
        map.put("appid", ConfigUtil.APPID);
        map.put("mch_id", ConfigUtil.MCH_ID);
        map.put("nonce_str", PayCommonUtil.CreateNoncestr());
        map.put("out_trade_no", out_trade_no);
        map.put("out_refund_no", out_request_no);
        map.put("total_fee", String.valueOf(Math.round(total_fee * 100)));
        map.put("refund_fee", String.valueOf(Math.round(refund_fee * 100)));
        map.put("refund_account", "REFUND_SOURCE_RECHARGE_FUNDS");
        map.put("sign", PayCommonUtil.createSign("UTF-8", map));
        String requestXML = PayCommonUtil.getRequestXml(map);
        String result = PayCommonUtil.sslHttpsRequest(ConfigUtil.REFUND_URL, "POST", requestXML);
        try {
            if (result != null) {
                Map<String, String> resultMap = XMLUtil.doXMLParse(result);
                if (resultMap == null || resultMap.isEmpty()) {
                    return "退款请求接口调用失败";
                } else if (!"SUCCESS".equals(resultMap.get("return_code"))) {
                    return resultMap.get("return_code") + ":" + resultMap.get("return_msg");
                } else if ("SUCCESS".equals(resultMap.get("return_code")) && "SUCCESS".equals(resultMap.get("result_code"))) {
                    return "SUCCESS";
                } else {
                    return resultMap.get("err_code") + ":" + resultMap.get("err_code_des");
                }
            }
            return "退款请求接口调用失败";
        } catch (JDOMException e) {
            logger.warn(e.getMessage());
            return e.getMessage();
        } catch (IOException e) {
            logger.warn(e.getMessage());
            return e.getMessage();
        }
    }

    /**
     * 查询退款是否成功
     * @return
     */
    public boolean queryRefundStatus(String out_trade_no, String out_refund_no) {
        SortedMap<Object, Object> map = new TreeMap<>();
        map.put("appid", ConfigUtil.APPID);
        map.put("mch_id", ConfigUtil.MCH_ID);
        map.put("nonce_str", PayCommonUtil.CreateNoncestr());
        map.put("out_trade_no", out_trade_no);
        map.put("out_refund_no", out_refund_no);
        map.put("sign", PayCommonUtil.createSign("UTF-8", map));
        String requestXML = PayCommonUtil.getRequestXml(map);
        String result = PayCommonUtil.httpsRequest(ConfigUtil.REFUND_QUERY_URL, "POST", requestXML);
        try {
            Map<String, String> resultMap = XMLUtil.doXMLParse(result);
            if (resultMap != null && !resultMap.isEmpty() && "SUCCESS".equals(resultMap.get("return_code")) && "SUCCESS".equals(resultMap.get("result_code"))) {
                if ("SUCCESS".equals(resultMap.get("refund_status_0"))) {//退款成功
                    return true;
                }
            }
        } catch (JDOMException e) {
            logger.warn(e.getMessage());
        } catch (IOException e) {
            logger.warn(e.getMessage());
        }
        return false;
    }
}
