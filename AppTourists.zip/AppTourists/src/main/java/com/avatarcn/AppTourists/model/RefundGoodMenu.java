package com.avatarcn.AppTourists.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by z1ven on 2018/3/8 11:22
 */
@JsonIgnoreProperties(value = {"handler"})
public class RefundGoodMenu {
    private Integer id;
    private Integer fk_tb_refund_good_id;
    private Integer fk_tb_speciality_id;
    private Integer amount;

    private Speciality speciality;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFk_tb_refund_good_id() {
        return fk_tb_refund_good_id;
    }

    public void setFk_tb_refund_good_id(Integer fk_tb_refund_good_id) {
        this.fk_tb_refund_good_id = fk_tb_refund_good_id;
    }

    public Integer getFk_tb_speciality_id() {
        return fk_tb_speciality_id;
    }

    public void setFk_tb_speciality_id(Integer fk_tb_speciality_id) {
        this.fk_tb_speciality_id = fk_tb_speciality_id;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Speciality getSpeciality() {
        return speciality;
    }

    public void setSpeciality(Speciality speciality) {
        this.speciality = speciality;
    }
}
