package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.RefundGoodMenu;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

/**
 * Created by z1ven on 2018/3/8 11:24
 */
@Mapper
public interface RefundGoodMenuMapper {

    @Insert("INSERT INTO tb_refund_good_menu(fk_tb_refund_good_id, fk_tb_speciality_id, amount) VALUES(#{fk_tb_refund_good_id}, #{fk_tb_speciality_id}, #{amount})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(RefundGoodMenu refundGoodMenu);

    @Delete("DELETE FROM tb_refund_good_menu WHERE fk_tb_refund_good_id = #{fk_tb_refund_good_id}")
    int deleteByRefundGoodId(Integer fk_tb_refund_good_id);

    @Select("SELECT * FROM tb_refund_good_menu WHERE fk_tb_refund_good_id = #{fk_tb_refund_good_id}")
    @Results({
            @Result(property = "fk_tb_speciality_id", column = "fk_tb_speciality_id"),
            @Result(property = "speciality", column = "fk_tb_speciality_id", one = @One(select = "com.avatarcn.AppTourists.mapper.SpecialityMapper.selectByPrimaryKey", fetchType = FetchType.LAZY))
    })
    List<RefundGoodMenu> selectByRefundGoodId(Integer fk_tb_refund_good_id);
}
