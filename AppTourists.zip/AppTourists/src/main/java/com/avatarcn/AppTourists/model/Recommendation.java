package com.avatarcn.AppTourists.model;

/**
 * Created by z1ven on 2018/1/31 16:08
 */
public class Recommendation {

    private int id;
    private String image;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
