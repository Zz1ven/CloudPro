package com.avatarcn.AppTourists.feign;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Created by MDF on 2018-2-6.
 */
@FeignClient(name = "WeiXin",url = "https://api.weixin.qq.com")
public interface WeiXinApiService {
    //得到access_token
    @RequestMapping(value = "/cgi-bin/token",method = RequestMethod.GET)
    String getAccessToken(@RequestParam("appid") String appid, @RequestParam("secret") String secret,@RequestParam("grant_type") String grant_type);

    //获得jsapi_ticket
    @RequestMapping(value = "/cgi-bin/ticket/getticket",method = RequestMethod.GET)
    String getJsApiTicket(@RequestParam("access_token") String access_token, @RequestParam("type") String type);
}
