package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.mapper.AccountMapper;
import com.avatarcn.AppTourists.mapper.ShoppingCartMapper;
import com.avatarcn.AppTourists.mapper.SpecialityMapper;
import com.avatarcn.AppTourists.model.ShoppingCart;
import com.avatarcn.AppTourists.model.Speciality;
import com.avatarcn.AppTourists.model.user.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/1 10:29
 */
@Service
public class ShoppingCartService {

    @Autowired
    private ShoppingCartMapper shoppingCartMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private SpecialityMapper specialityMapper;

    public ShoppingCart insert(int userId, int specialityId, int amount) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        Speciality speciality = specialityMapper.selectByPrimaryKey(specialityId);
        if (speciality == null) {
            throw new ErrorCodeException(TouristsErrorCode.SPECIALITY_NULL);
        }
        ShoppingCart shoppingCart = shoppingCartMapper.selectByUserIdAndSpecialityId(account.getId(), specialityId);
        if (shoppingCart != null) {
            shoppingCart.setAmount(shoppingCart.getAmount() + amount);
            shoppingCartMapper.update(shoppingCart);
        } else {
            shoppingCart = new ShoppingCart();
            shoppingCart.setFk_tb_user_id(account.getId());
            shoppingCart.setFk_tb_speciality_id(specialityId);
            shoppingCart.setAmount(amount);
            shoppingCart.setTime(new Date());
            shoppingCartMapper.insert(shoppingCart);
        }
        shoppingCart.setSpeciality(speciality);
        return shoppingCart;
    }

    public ShoppingCart selectById(int id) throws ErrorCodeException {
        ShoppingCart shoppingCart = shoppingCartMapper.selectById(id);
        if (shoppingCart == null) {
            throw new ErrorCodeException(ErrorCodeException.DATA_NO_ERROR);
        }
        return shoppingCart;
    }

    public PageResponse<ShoppingCart> selectByUserId(int userId, int offset, int pageSize) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        List<ShoppingCart> shoppingCartList = shoppingCartMapper.selectByUserId(account.getId(), offset, pageSize);
        PageResponse<ShoppingCart> shoppingCartPageResponse = new PageResponse<>();
        shoppingCartPageResponse.setItem(shoppingCartList);
        shoppingCartPageResponse.setOffset(offset);
        shoppingCartPageResponse.setPageSize(pageSize);
        shoppingCartPageResponse.setTotal(shoppingCartMapper.countByUserId(account.getId()));
        return shoppingCartPageResponse;
    }

    public int getShoppingCartAmount(int userId) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        return shoppingCartMapper.countByUserId(account.getId());
    }

    public int updateShoppingCart(int id, int amount) throws ErrorCodeException {
        ShoppingCart shoppingCart = shoppingCartMapper.selectById(id);
        if (shoppingCart == null) {
            throw new ErrorCodeException(ErrorCodeException.DATA_NO_ERROR);
        }
        if (amount > 0) {
            shoppingCart.setAmount(amount);
            shoppingCartMapper.update(shoppingCart);
        } else if (amount == 0) {
            shoppingCartMapper.deleteById(id);
        }
        return amount;
    }

    public int deleteShoppingCart(int id) throws ErrorCodeException {
        if (shoppingCartMapper.deleteById(id) != 1) {
            throw new ErrorCodeException(ErrorCodeException.DELETE_NO);
        }
        return 1;
    }
}
