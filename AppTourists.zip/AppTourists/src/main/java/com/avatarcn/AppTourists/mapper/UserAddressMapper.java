package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.UserAddress;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * Created by z1ven on 2018/3/1 16:58
 */
@Mapper
public interface UserAddressMapper {

    @Insert("INSERT INTO tb_user_address(fk_tb_user_id, name, phone, postalcode, address, default_tag, visible, time) VALUES(#{fk_tb_user_id}, #{name}, #{phone}, #{postalcode}, #{address}, #{default_tag}, #{visible}, #{time})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UserAddress userAddress);

    @Delete("DELETE FROM tb_user_address WHERE id = #{id}")
    int deleteById(Integer id);

    @Select("SELECT * FROM tb_user_address WHERE id = #{id}")
    UserAddress selectById(Integer id);

    @Select("SELECT * FROM tb_user_address WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1 ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    List<UserAddress> selectByUserId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_user_address WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1 AND default_tag = 1")
    UserAddress selectDefaultAddress(Integer fk_tb_user_id);

    @Select("SELECT COUNT(*) FROM tb_user_address WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1")
    int countByUserId(Integer fk_tb_user_id);

    @Update("UPDATE tb_user_address SET visible = #{visible} WHERE id = #{id}")
    int updateVisible(@Param(value = "id") Integer id, @Param(value = "visible") boolean visible);

    @Update("UPDATE tb_user_address SET default_tag = #{default_tag} WHERE fk_tb_user_id = #{fk_tb_user_id}")
    int updateDefaultTag(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("default_tag") boolean default_tag);

    @Update("UPDATE tb_user_address SET fk_tb_user_id = #{fk_tb_user_id}, name = #{name}, phone = #{phone}, postalcode = #{postalcode}, address = #{address}, default_tag = #{default_tag}, visible = #{visible}, time = #{time} WHERE id = #{id}")
    int update(UserAddress userAddress);
}
