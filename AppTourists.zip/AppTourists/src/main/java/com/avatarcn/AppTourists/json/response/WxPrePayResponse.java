package com.avatarcn.AppTourists.json.response;

/**
 * Created by MDF on 2018-2-27.
 */
public class WxPrePayResponse {

}
