package com.avatarcn.AppTourists.json.response.weixin;

/**
 * Created by MDF on 2018-2-6.
 */
public class JsConfigResponse {
    private String noceStr;
    private String signature;
    private Long timestamp;

    public String getNoceStr() {
        return noceStr;
    }

    public void setNoceStr(String noceStr) {
        this.noceStr = noceStr;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
