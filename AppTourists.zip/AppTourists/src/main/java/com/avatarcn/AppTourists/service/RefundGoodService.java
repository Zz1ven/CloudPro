package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.json.response.RefundDataResponse;
import com.avatarcn.AppTourists.mapper.*;
import com.avatarcn.AppTourists.model.*;
import com.avatarcn.AppTourists.model.user.Account;
import com.avatarcn.AppTourists.utils.MakeOrderUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/6 15:43
 */
@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 60000, rollbackFor = Exception.class)
public class RefundGoodService {

    @Autowired
    private RefundGoodMapper refundGoodMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private RefundStatusMapper refundStatusMapper;

    @Autowired
    private RefundTypeMapper refundTypeMapper;

    @Autowired
    private SpecialityOrderMapper specialityOrderMapper;

    @Autowired
    private RefundGoodMenuMapper refundGoodMenuMapper;

    @Autowired
    private SpecialityOrderMenuMapper specialityOrderMenuMapper;

    @Autowired
    private AlipayService alipayService;

    @Autowired
    private WxpayService wxpayService;

    /**
     * * 提交售后申请
     * @param userId 用户系统的用户id
     * @param statusId 售后状态id
     * @param number 特产商城订单号
     * @param specialityMenus 售后商品列表
     * @param typeId 售后类型id
     * @param money 退款金额
     * @param reason 退款说明
     * @return 申请表单
     */
    public RefundGood insert(int userId, int statusId, String number, List<SpecialityMenu> specialityMenus, int typeId, float money, String reason) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        RefundStatus refundStatus = refundStatusMapper.selectById(statusId);
        if (refundStatus == null) {//售后状态
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_NULL);
        }
        RefundType refundType = refundTypeMapper.selectById(typeId);
        if (refundType == null) {//售后类型
            throw new ErrorCodeException(TouristsErrorCode.REFUND_TYPE_NULL);
        }
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(number);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        if (specialityOrder.getFk_tb_user_id() != account.getId()) {//同一个用户
            throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
        }
        if (typeId == Constant.REFUND_TYPE_REFUND) {//仅退款
            if (specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_DELIVER && specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_RECEIVE) {
                //订单状态必须为待发货或待收货
                throw new ErrorCodeException(TouristsErrorCode.REFUND_ORDER_STATUS_INVALID);
            }
        } else if (typeId == Constant.REFUND_TYPE_RETURN) {//退款退货
            if (specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_RECEIVE
                    && specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_EVALUATE
                    && specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_COMPLETED) {
                //订单状态必须为待收货或待评价或已完成
                throw new ErrorCodeException(TouristsErrorCode.REFUND_ORDER_STATUS_INVALID);
            }
            if (specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_WAIT_EVALUATE
                    || specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_COMPLETED) {
                //订单状态为待评价或已完成时,判断订单是否售后超时
                Date now = new Date();
                Date finish = specialityOrder.getFinish_time();
                long day = (now.getTime() - finish.getTime()) / (24 * 60 * 60 * 1000);
                if (day > Constant.REFUND_RETURN_TIME) {
                    throw new ErrorCodeException(TouristsErrorCode.REFUND_OVERDUE);
                }
            }
        }
        if (specialityOrder.getPay_method() == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_PAY_METHOD_ERROR);
        }
        float total = 0f;
        float refund;
        for (SpecialityMenu specialityMenu : specialityMenus) {
            SpecialityOrderMenu som = specialityOrderMenuMapper.selectByOrderIdAndSpecialityId(specialityOrder.getId(), specialityMenu.getSpeciality_id());
            if (som == null || som.getAmount() != specialityMenu.getAmount()) {//确定商品是该订单的且数量一致
                throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
            }
            //修改订单商品售后状态->售后中
            som.setFk_tb_good_status_id(Constant.GOOD_STATUS_REFUNDING);
            specialityOrderMenuMapper.update(som);
            Speciality speciality = som.getSpeciality();
            if (speciality == null) {
                throw new ErrorCodeException(TouristsErrorCode.SPECIALITY_NULL);
            }
            total = total + speciality.getPrice() * specialityMenu.getAmount();
        }
        //实际退款金额
        refund = total / specialityOrder.getTotal_money() * specialityOrder.getReal_money();
        BigDecimal bigDecimal = new BigDecimal(refund);
        refund = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
        if (money != refund) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_DATA_INVALID);
        }
        //创建售后申请表单
        RefundGood refundGood = new RefundGood();
        refundGood.setFk_tb_refund_status_id(statusId);
        refundGood.setFk_tb_refund_type_id(typeId);
        refundGood.setFk_tb_user_id(account.getId());
        refundGood.setMoney(money);
        refundGood.setReason(reason);
        refundGood.setOrder_number(number);
        refundGood.setOut_request_no(MakeOrderUtil.makeOrderNum(Constant.REFUND_GOOD_ORDER_TYPE));
        refundGood.setPath(specialityOrder.getPay_method());
        refundGood.setVisible(true);
        refundGood.setTime(new Date());
        refundGoodMapper.insert(refundGood);
        //生成售后商品清单
        for (SpecialityMenu specialityMenu : specialityMenus) {
            RefundGoodMenu refundGoodMenu = new RefundGoodMenu();
            refundGoodMenu.setFk_tb_refund_good_id(refundGood.getId());
            refundGoodMenu.setFk_tb_speciality_id(specialityMenu.getSpeciality_id());
            refundGoodMenu.setAmount(specialityMenu.getAmount());
            refundGoodMenuMapper.insert(refundGoodMenu);
        }
        refundGood.setRefundStatus(refundStatus);
        refundGood.setRefundType(refundType);
        refundGood.setRefundGoodMenuList(refundGoodMenuMapper.selectByRefundGoodId(refundGood.getId()));
        return refundGood;
    }

    /**
     * 生成售后申请数据
     * @param number 订单号
     * @param specialityMenus 申请商品列表
     * @param typeId 申请类型
     * @return 退款数据
     * @throws ErrorCodeException
     */
    public RefundDataResponse getRefundData(String number, List<SpecialityMenu> specialityMenus, int typeId) throws ErrorCodeException {
        RefundType refundType = refundTypeMapper.selectById(typeId);
        if (refundType == null) {//售后类型
            throw new ErrorCodeException(TouristsErrorCode.REFUND_TYPE_NULL);
        }
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(number);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        float total = 0f;
        float refund;
        RefundDataResponse refundDataResponse = new RefundDataResponse();
        List<Speciality> specialityList = new ArrayList<>();
        for (SpecialityMenu specialityMenu : specialityMenus) {
            SpecialityOrderMenu menu = specialityOrderMenuMapper.selectByOrderIdAndSpecialityId(specialityOrder.getId(), specialityMenu.getSpeciality_id());
            if (menu == null || menu.getAmount() != specialityMenu.getAmount()) {//确定商品是该订单的且数量一致
                throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
            }
            //所选商品正在售后中或已进行过售后
            if (menu.getFk_tb_good_status_id() == Constant.GOOD_STATUS_REFUNDING ||
                    menu.getFk_tb_good_status_id() == Constant.GOOD_STATUS_REFUNDED) {
                throw new ErrorCodeException(TouristsErrorCode.REFUND_REPEAT_INVALID);
            }
            Speciality speciality = menu.getSpeciality();
            if (speciality == null) {
                throw new ErrorCodeException(TouristsErrorCode.SPECIALITY_NULL);
            }
            specialityList.add(speciality);
            total = total + speciality.getPrice() * specialityMenu.getAmount();
        }
        //实际退款金额
        refund = total / specialityOrder.getTotal_money() * specialityOrder.getReal_money();
        BigDecimal bigDecimal = new BigDecimal(refund);
        refund = bigDecimal.setScale(2, BigDecimal.ROUND_HALF_UP).floatValue();
        refundDataResponse.setRefund(refund);
        refundDataResponse.setRefundType(refundType);
        refundDataResponse.setSpecialityList(specialityList);
        return refundDataResponse;
    }

    /**
     * 是否接受处理指定的售后申请
     * @param id
     * @return
     */
    public int handleRefundGood(int id, boolean handle) throws ErrorCodeException {
        RefundGood refundGood = refundGoodMapper.selectById(id);
        if (refundGood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        if (refundGood.getFk_tb_refund_status_id() != Constant.REFUND_STATUS_APPLYING) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_INVALID);
        }
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(refundGood.getOrder_number());
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        int result;
        if (handle) {//接受申请->处理中
            result = refundGoodMapper.updateStatus(id, Constant.REFUND_STATUS_PROCESSING);
            if (specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_WAIT_DELIVER ||
                    specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_WAIT_RECEIVE) {//用户未收到货
                result = refundGoodMapper.updateStatus(id, Constant.REFUND_STATUS_RETURN);
            }
        } else {//不接受申请->申请失败
            //修改订单商品售后状态->正常
            List<RefundGoodMenu> menus = refundGoodMenuMapper.selectByRefundGoodId(id);
            for (RefundGoodMenu menu : menus) {
                SpecialityOrderMenu specialityOrderMenu = specialityOrderMenuMapper.selectByOrderIdAndSpecialityId(specialityOrder.getId(), menu.getFk_tb_speciality_id());
                specialityOrderMenu.setFk_tb_good_status_id(Constant.GOOD_STATUS_PAID);
                specialityOrderMenuMapper.update(specialityOrderMenu);
            }
            result = refundGoodMapper.updateStatus(id, Constant.REFUND_STATUS_FAILURE);
        }
        return result;
    }

    /**
     * (售后状态为处理中时)用户提交退货快递信息
     * @param userId
     * @param id 售后单主键
     * @param express_company 快递公司
     * @param express_no 快递单号
     * @return
     */
    public int commitReturnExpress(int userId, int id, String express_company, String express_no) throws ErrorCodeException {
        //提交快递信息,修改状态为待返货
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        RefundGood refundGood = refundGoodMapper.selectById(id);
        if (refundGood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        if (account.getId() != refundGood.getFk_tb_user_id()) {
            throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
        }
        if (refundGood.getFk_tb_refund_status_id() != Constant.REFUND_STATUS_PROCESSING) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_INVALID);
        }
        refundGoodMapper.updateExpress(id, express_company, express_no);
        return refundGoodMapper.updateStatus(id, Constant.REFUND_STATUS_RETURN);
    }

    /**
     * 后台确定已收到退货商品
     * @return
     */
    public String backReceiveGood(int id) throws ErrorCodeException {
        //确认收到商品,修改状态->退款中
        RefundGood refundGood = refundGoodMapper.selectById(id);
        if (refundGood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(refundGood.getOrder_number());
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        if (refundGood.getFk_tb_refund_status_id() != Constant.REFUND_STATUS_RETURN) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_INVALID);
        }
        //仅退款/退款退货
        refundGoodMapper.updateStatus(id, Constant.REFUND_STATUS_REFUND);
        String result = null;
        if (Constant.ALIPAY.equals(refundGood.getPath())) {
            //支付宝退款
            result = alipayService.refundRequest(refundGood.getOrder_number(), refundGood.getMoney(), refundGood.getOut_request_no());
        } else if (Constant.WXPAY.equals(refundGood.getPath())) {
            //微信退款
            result = wxpayService.refundRequest(refundGood.getOrder_number(), specialityOrder.getReal_money(), refundGood.getMoney(), refundGood.getOut_request_no());
        }
        if (!"SUCCESS".equals(result)) {
            throw new ErrorCodeException(new ErrorCode(1, result));
        }
        return result;
    }

    /**
     * 结束退款售后流程(查看退款中状态的售后时调用)
     * @return
     */
    private boolean finishRefundGood(RefundGood refundGood, Integer specialityOrderId) {
        if (refundGood.getFk_tb_refund_status_id() != Constant.REFUND_STATUS_REFUND) {
            return false;
        }
        boolean successful = false;
        if (Constant.ALIPAY.equals(refundGood.getPath())) {
            successful = alipayService.queryRefundStatus(refundGood.getOrder_number(), refundGood.getOut_request_no());
        } else if (Constant.WXPAY.equals(refundGood.getPath())) {
            successful = wxpayService.queryRefundStatus(refundGood.getOrder_number(), refundGood.getOut_request_no());
        }
        //修改订单商品售后状态->已退款
        if (successful) {
            List<RefundGoodMenu> menus = refundGoodMenuMapper.selectByRefundGoodId(refundGood.getId());
            for (RefundGoodMenu menu : menus) {
                SpecialityOrderMenu specialityOrderMenu = specialityOrderMenuMapper.selectByOrderIdAndSpecialityId(specialityOrderId, menu.getFk_tb_speciality_id());
                specialityOrderMenu.setFk_tb_good_status_id(Constant.GOOD_STATUS_REFUNDED);
                specialityOrderMenuMapper.update(specialityOrderMenu);
            }
            refundGoodMapper.updateStatus(refundGood.getId(), Constant.REFUND_STATUS_SUCCESS);
            return true;
        }
        return false;
    }

    /**
     * 删除售后请求
     * @param id
     * @return
     * @throws ErrorCodeException
     */
    public int deleteRefundGood(int id) throws ErrorCodeException {
        RefundGood refundGood = refundGoodMapper.selectById(id);
        if (refundGood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        //售后申请流程正在受理中
        if (refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_APPLYING ||
                refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_PROCESSING ||
                refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_RETURN ||
                refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_UNFINISHED);
        }
        //取消或申请失败状态的删除
        if (refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_CANCEL ||
                refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_FAILURE) {
            //删除关联售后商品清单
            refundGoodMenuMapper.deleteByRefundGoodId(id);
            if (refundGoodMapper.delete(id) != 1) {
                throw new ErrorCodeException(ErrorCodeException.DELETE_NO);
            }
            return 1;
        }
        //售后完成时删除
        if (refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_SUCCESS) {
            if (refundGoodMapper.updateVisible(id, false) != 1) {
                throw new ErrorCodeException(ErrorCodeException.DELETE_NO);
            }
            return 1;
        }
        return 1;
    }

    /**
     * 取消售后请求
     * @return
     */
    public int cancelRefundGood(int id) throws ErrorCodeException {
        RefundGood refundGood = refundGoodMapper.selectById(id);
        if (refundGood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(refundGood.getOrder_number());
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        //状态为完成或取消或失败时不能取消
        if (refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_SUCCESS ||
                refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_CANCEL ||
                refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_FAILURE) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_INVALID);
        }
        //修改订单商品售后状态->正常
        List<RefundGoodMenu> menus = refundGoodMenuMapper.selectByRefundGoodId(id);
        for (RefundGoodMenu menu : menus) {
            SpecialityOrderMenu specialityOrderMenu = specialityOrderMenuMapper.selectByOrderIdAndSpecialityId(specialityOrder.getId(), menu.getFk_tb_speciality_id());
            specialityOrderMenu.setFk_tb_good_status_id(Constant.GOOD_STATUS_PAID);
            specialityOrderMenuMapper.update(specialityOrderMenu);
        }
        return refundGoodMapper.updateStatus(id, Constant.REFUND_STATUS_CANCEL);
    }

    public RefundGood selectById(int id) throws ErrorCodeException {
        RefundGood refundGood = refundGoodMapper.selectDetailById(id);
        if (refundGood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        //当售后申请正在退款中时，调用接口查看退款状态
        if (refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {
            SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(refundGood.getOrder_number());
            if (specialityOrder == null) {
                throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
            }
            boolean refund = finishRefundGood(refundGood, specialityOrder.getId());
            if (refund) {//退款成功
                refundGood.setFk_tb_refund_status_id(Constant.REFUND_STATUS_SUCCESS);
                refundGood.setRefundStatus(refundStatusMapper.selectById(Constant.REFUND_STATUS_SUCCESS));
            }
        }
        return refundGood;
    }

    public PageResponse<RefundGood> selectPageByUserId(int userId, int offset, int pageSize) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        List<RefundGood> refundGoodList = refundGoodMapper.selectPageByUserId(account.getId(), offset, pageSize);
        PageResponse<RefundGood> refundGoodPageResponse = new PageResponse<>();
        for (RefundGood refundGood : refundGoodList) {
            //当售后申请正在退款中时，调用接口查看退款状态
            if (refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {
                SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(refundGood.getOrder_number());
                if (specialityOrder == null) {
                    throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
                }
                boolean refund = finishRefundGood(refundGood, specialityOrder.getId());
                if (refund) {//退款成功
                    refundGood.setFk_tb_refund_status_id(Constant.REFUND_STATUS_SUCCESS);
                    refundGood.setRefundStatus(refundStatusMapper.selectById(Constant.REFUND_STATUS_SUCCESS));
                }
            }
        }
        refundGoodPageResponse.setItem(refundGoodList);
        refundGoodPageResponse.setOffset(offset);
        refundGoodPageResponse.setPageSize(pageSize);
        refundGoodPageResponse.setTotal(refundGoodMapper.countByUserId(account.getId()));
        return refundGoodPageResponse;
    }

    public PageResponse<RefundGood> selectPage(int offset, int pageSize) throws ErrorCodeException {
        List<RefundGood> refundGoodList = refundGoodMapper.selectPage(offset, pageSize);
        PageResponse<RefundGood> refundGoodPageResponse = new PageResponse<>();
        for (RefundGood refundGood : refundGoodList) {
            //当售后申请正在退款中时，调用接口查看退款状态
            if (refundGood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {
                SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(refundGood.getOrder_number());
                if (specialityOrder == null) {
                    throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
                }
                boolean refund = finishRefundGood(refundGood, specialityOrder.getId());
                if (refund) {//退款成功
                    refundGood.setFk_tb_refund_status_id(Constant.REFUND_STATUS_SUCCESS);
                    refundGood.setRefundStatus(refundStatusMapper.selectById(Constant.REFUND_STATUS_SUCCESS));
                }
            }
        }
        refundGoodPageResponse.setItem(refundGoodList);
        refundGoodPageResponse.setOffset(offset);
        refundGoodPageResponse.setPageSize(pageSize);
        refundGoodPageResponse.setTotal(refundGoodMapper.count());
        return refundGoodPageResponse;
    }
}
