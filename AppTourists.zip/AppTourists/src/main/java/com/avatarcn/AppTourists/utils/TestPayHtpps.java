package com.avatarcn.AppTourists.utils;


import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.Formatter;

/**
 * Created by MDF on 2018-2-26.
 */
public class TestPayHtpps {
    public static void main(String[] args) throws Exception {

           String stringA="appid=wx66bb9540657a73f2&attach=支付测试body=APP支付测试&mch_id=1499172392&nonce_str=1add1a30ac87aa2db72f57a2375d8fec&notify_url=http://wxpay.wxutil.com/pub_v2/pay/notify.v2.php&out_trade_no=20180806125346&spbill_create_ip=192.168.3.143&total_fee=1&trade_type=APP";
          System.out.println(stringA);
           String stringSignTemp=stringA+"&key=de582a273a552cfec11245f8505a4ad7";
            MessageDigest crypt = MessageDigest.getInstance("MD5");
                crypt.reset();
                crypt.update(stringSignTemp.getBytes("UTF-8"));
               String sign = byteToHex(crypt.digest()).toUpperCase();
              System.out.println(sign);
            //直接字符串拼接
            StringBuffer sb = new StringBuffer();
            sb.append("<xml>\n" +
                    "   <appid>wx66bb9540657a73f2</appid>\n" +
                    "   <attach>支付测试</attach>\n" +
                    "   <body>APP支付测试</body>\n" +
                    "   <mch_id>1499172392</mch_id>\n" +
                    "   <nonce_str>1add1a30ac87aa2db72f57a2375d8fec</nonce_str>\n" +
                    "   <notify_url>http://wxpay.wxutil.com/pub_v2/pay/notify.v2.php</notify_url>\n" +
                    "   <out_trade_no>20180806125346</out_trade_no>\n" +
                    "   <spbill_create_ip>192.168.3.143</spbill_create_ip>\n" +
                    "   <total_fee>1</total_fee>\n" +
                    "   <trade_type>APP</trade_type>\n" +
                    "   <sign>"+sign+"</sign>\n" +
                    "</xml>" );//xml数据存储
        HttpClient httpclient=new DefaultHttpClient();
        String data = sb.toString();
        HttpPost request = new HttpPost("https://api.mch.weixin.qq.com/pay/unifiedorder");
        request.setEntity(new StringEntity(data , Charset.forName("UTF-8")));
        request.addHeader("content-type", "application/x-www-form-urlencoded");
        HttpResponse response;

        try {
            response = httpclient.execute(request);
            //根据返回码判断请求是否成功
            System.out.println("==================="+response.getStatusLine().getStatusCode());
            if(response.getStatusLine().getStatusCode()==200){
                String tokenJson = EntityUtils.toString(response.getEntity(),"UTF-8");
             System.out.print(tokenJson);

            }else {
               // System.out.println(EntityUtils.toString(response.getEntity()));

            }
        } catch (ClientProtocolException e) {
            e.printStackTrace();

        } catch (IOException e) {
            e.printStackTrace();

        }

    }

    private static String byteToHex(byte[] hash) {
        Formatter formatter = new Formatter();
        byte[] var5 = hash;
        int var4 = hash.length;

        for(int var3 = 0; var3 < var4; ++var3) {
            byte b = var5[var3];
            formatter.format("%02x", new Object[]{Byte.valueOf(b)});
        }

        String result = formatter.toString();
        formatter.close();
        return result;
    }

}
