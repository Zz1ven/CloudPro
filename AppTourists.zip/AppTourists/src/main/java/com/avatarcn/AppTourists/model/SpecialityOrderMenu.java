package com.avatarcn.AppTourists.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by z1ven on 2018/3/1 15:26
 */
@JsonIgnoreProperties(value = {"handler"})
public class SpecialityOrderMenu {
    private Integer id;
    private Integer fk_tb_order_speciality_id;
    private Integer fk_tb_speciality_id;
    private Integer fk_tb_good_status_id;
    private Integer amount;

    private Speciality speciality;
    private GoodStatus goodStatus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFk_tb_order_speciality_id() {
        return fk_tb_order_speciality_id;
    }

    public void setFk_tb_order_speciality_id(Integer fk_tb_order_speciality_id) {
        this.fk_tb_order_speciality_id = fk_tb_order_speciality_id;
    }

    public Integer getFk_tb_speciality_id() {
        return fk_tb_speciality_id;
    }

    public void setFk_tb_speciality_id(Integer fk_tb_speciality_id) {
        this.fk_tb_speciality_id = fk_tb_speciality_id;
    }

    public Integer getFk_tb_good_status_id() {
        return fk_tb_good_status_id;
    }

    public void setFk_tb_good_status_id(Integer fk_tb_good_status_id) {
        this.fk_tb_good_status_id = fk_tb_good_status_id;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Speciality getSpeciality() {
        return speciality;
    }

    public void setSpeciality(Speciality speciality) {
        this.speciality = speciality;
    }

    public GoodStatus getGoodStatus() {
        return goodStatus;
    }

    public void setGoodStatus(GoodStatus goodStatus) {
        this.goodStatus = goodStatus;
    }
}
