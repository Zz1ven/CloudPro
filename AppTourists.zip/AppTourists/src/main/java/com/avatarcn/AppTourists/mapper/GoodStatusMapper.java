package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.GoodStatus;
import org.apache.ibatis.annotations.*;

/**
 * Created by z1ven on 2018/3/7 17:25
 */
@Mapper
public interface GoodStatusMapper {

    @Insert("INSERT INTO tb_good_status(name) VALUES(#{name})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(GoodStatus goodStatus);

    @Delete("DELETE FROM tb_good_status WHERE id = #{id}")
    int delete(Integer id);

    @Update("UPDATE tb_good_status SET name = #{name} WHERE id = #{id}")
    int update(GoodStatus goodStatus);

    @Select("SELECT * FROM tb_good_status WHERE id = #{id}")
    GoodStatus selectById(Integer id);
}
