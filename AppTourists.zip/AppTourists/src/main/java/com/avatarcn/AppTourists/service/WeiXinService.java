package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.feign.WeiXinApiService;
import com.avatarcn.AppTourists.json.response.Test;
import com.avatarcn.AppTourists.json.response.weixin.AccessToken;
import com.avatarcn.AppTourists.json.response.weixin.JsConfigResponse;
import com.avatarcn.AppTourists.json.response.weixin.TicketResonse;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.Formatter;
import java.util.Map;
import java.util.UUID;

/**
 * Created by MDF on 2018-2-6.
 */
@Service
public class WeiXinService {
    @Value("${weixin.app_id}")
    private String AppId;
    @Value("${weixin.app_key}")
    private String AppKey;
    @Autowired
    private WeiXinApiService weiXinApiService;

    public JsConfigResponse getJsSignature(){
        //先得到acess_token
        String access_token= weiXinApiService.getAccessToken(AppId, AppKey, "client_credential");
        Gson gson = new Gson();
        AccessToken res = gson.fromJson(access_token, AccessToken.class);
        //得到jsapi_ticket
        String jsapi_ticket=weiXinApiService.getJsApiTicket(res.getAccess_token(),"jsapi");
        TicketResonse ticketResonse=gson.fromJson(jsapi_ticket,TicketResonse.class);
        JsConfigResponse jsConfigResponse=new JsConfigResponse();
        jsConfigResponse.setNoceStr(UUID.randomUUID().toString());
        jsConfigResponse.setTimestamp(new Date().getTime()/1000);
        //对所有待签名参数按照字段名的ASCII 码从小到大排序（字典序）后，使用URL键值对的格式（即key1=value1&key2=value2…）拼接成字符串string1：
        String ticket="jsapi_ticket="+ticketResonse.getTicket()+"&noncestr="+jsConfigResponse.getNoceStr()+"&timestamp="+jsConfigResponse.getTimestamp()+"&url=http://wuzhi.avatarcn.com";
       // 对string1进行sha1签名，得到signature：
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            digest.reset();
            try {
                digest.update(ticket.getBytes("UTF-8"));
                //加密后
                jsConfigResponse.setSignature(byteToHex( digest.digest()));
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return jsConfigResponse ;
    }

   public  Map<String, String> getNewJsSignature(String url){
       //先得到acess_token
       String access_token= weiXinApiService.getAccessToken(AppId, AppKey, "client_credential");
       Gson gson = new Gson();
       AccessToken res = gson.fromJson(access_token, AccessToken.class);
       //得到jsapi_ticket
       String jsapi_ticket=weiXinApiService.getJsApiTicket(res.getAccess_token(),"jsapi");
       TicketResonse ticketResonse=gson.fromJson(jsapi_ticket,TicketResonse.class);
       Map<String, String> signs = Test.sign(ticketResonse.getTicket(), url);
       return signs;
   }


    private static String byteToHex(final byte[] hash) {
        Formatter formatter = new Formatter();
        for (byte b : hash)
        {
            formatter.format("%02x", b);
        }
        String result = formatter.toString();
        formatter.close();
        return result;
    }

    private static String create_timestamp() {
        return Long.toString(System.currentTimeMillis() / 1000);
    }




}
