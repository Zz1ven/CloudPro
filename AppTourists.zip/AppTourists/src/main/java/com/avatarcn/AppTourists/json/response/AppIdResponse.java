package com.avatarcn.AppTourists.json.response;

/**
 * Created by MDF on 2017-10-27.
 */
public class AppIdResponse {
    private String app_id;

    public String getApp_id() {
        return app_id;
    }

    public void setApp_id(String app_id) {
        this.app_id = app_id;
    }
}
