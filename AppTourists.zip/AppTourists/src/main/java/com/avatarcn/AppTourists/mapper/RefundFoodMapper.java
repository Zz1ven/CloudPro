package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.RefundFood;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

/**
 * Created by z1ven on 2018/3/13 11:14
 */
@Mapper
public interface RefundFoodMapper {

    @Insert("INSERT INTO tb_refund_food(fk_tb_refund_status_id, fk_tb_refund_type_id, fk_tb_user_id, fk_tb_order_food_id, money, reason, order_number, out_request_no, path, visible, create_time, refund_time) VALUES(#{fk_tb_refund_status_id}, #{fk_tb_refund_type_id}, #{fk_tb_user_id}, #{fk_tb_order_food_id}, #{money}, #{reason}, #{order_number}, #{out_request_no}, #{path}, #{visible}, #{create_time}, #{refund_time})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(RefundFood refundFood);

    @Delete("DELETE FROM tb_refund_food WHERE id = #{id}")
    int delete(Integer id);

    @Update("UPDATE tb_refund_food SET fk_tb_refund_status_id = #{fk_tb_refund_status_id}, fk_tb_refund_type_id = #{fk_tb_refund_type_id}, fk_tb_user_id = #{fk_tb_user_id}, fk_tb_order_food_id = #{fk_tb_order_food_id}, money = #{money}, reason = #{reason}, order_number = #{order_number}, out_request_no = #{out_request_no}, path = #{path}, visible = #{visible}, create_time = #{create_time}, refund_time = #{refund_time} WHERE id = #{id}")
    int update(RefundFood refundFood);

    @Update("UPDATE tb_refund_food SET visible = #{visible} WHERE id = #{id}")
    int updateVisible(@Param("id") Integer id, @Param("visible") Boolean visible);

    @Update("UPDATE tb_refund_food SET fk_tb_refund_status_id = #{fk_tb_refund_status_id} WHERE id = #{id}")
    int updateStatus(@Param("id") Integer id, @Param("fk_tb_refund_status_id") Integer fk_tb_refund_status_id);

    @Select("SELECT * FROM tb_refund_food WHERE id = #{id}")
    RefundFood selectById(Integer id);

    @Select("SELECT * FROM tb_refund_food WHERE id = #{id}")
    @Results({
            @Result(property = "fk_tb_refund_status_id", column = "fk_tb_refund_status_id"),
            @Result(property = "fk_tb_refund_type_id", column = "fk_tb_refund_type_id"),
            @Result(property = "fk_tb_order_food_id", column = "fk_tb_order_food_id"),
            @Result(property = "refundStatus", column = "fk_tb_refund_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundStatusMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundType", column = "fk_tb_refund_type_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundTypeMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "orderFoodMenus", column = "fk_tb_order_food_id", many = @Many(select = "com.avatarcn.AppTourists.mapper.OrderFoodMenuMapper.selectAll.", fetchType = FetchType.LAZY))
    })
    RefundFood selectDetailById(Integer id);

    @Select("SELECT * FROM tb_refund_food WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1 ORDER BY create_time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "fk_tb_refund_status_id", column = "fk_tb_refund_status_id"),
            @Result(property = "fk_tb_refund_type_id", column = "fk_tb_refund_type_id"),
            @Result(property = "fk_tb_order_food_id", column = "fk_tb_order_food_id"),
            @Result(property = "refundStatus", column = "fk_tb_refund_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundStatusMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundType", column = "fk_tb_refund_type_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundTypeMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "orderFoodMenus", column = "fk_tb_order_food_id", many = @Many(select = "com.avatarcn.AppTourists.mapper.OrderFoodMenuMapper.selectAll.", fetchType = FetchType.LAZY))
    })
    List<RefundFood> selectPageByUserId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_refund_food ORDER BY create_time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "fk_tb_refund_status_id", column = "fk_tb_refund_status_id"),
            @Result(property = "fk_tb_refund_type_id", column = "fk_tb_refund_type_id"),
            @Result(property = "fk_tb_order_food_id", column = "fk_tb_order_food_id"),
            @Result(property = "refundStatus", column = "fk_tb_refund_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundStatusMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "refundType", column = "fk_tb_refund_type_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RefundTypeMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "orderFoodMenus", column = "fk_tb_order_food_id", many = @Many(select = "com.avatarcn.AppTourists.mapper.OrderFoodMenuMapper.selectAll.", fetchType = FetchType.LAZY))
    })
    List<RefundFood> selectPage(@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT COUNT(*) FROM tb_refund_food WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1")
    int countByUserId(Integer fk_tb_user_id);

    @Select("SELECT COUNT(*) FROM tb_refund_food")
    int count();
}
