package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.Speciality;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;


@Mapper
public interface SpecialityMapper{

	@Insert("INSERT INTO tb_speciality(fk_tb_speciality_type_id, name,price,url,sale,remark,insale,time) VALUES(#{fk_tb_speciality_type_id},#{name},#{price},#{url},#{sale},#{remark},#{insale},#{time})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	int insert(Speciality speciality);

	@Update("UPDATE tb_speciality SET fk_tb_speciality_type_id=#{fk_tb_speciality_type_id},name=#{name},price=#{price},url=#{url},sale=#{sale},remark=#{remark},insale=#{insale},time=#{time} WHERE id=#{id}")
	int update(Speciality speciality);

	@Update("UPDATE tb_speciality SET insale = #{insale} WHERE id = #{id}")
	int updateSaleStatus(@Param("id") Integer id, @Param("insale") boolean insale);

	@Select("SELECT * FROM tb_speciality WHERE id=#{id}")
	@Results({
			@Result(property = "fk_tb_speciality_type_id", column = "fk_tb_speciality_type_id"),
			@Result(property = "specialityType", column = "fk_tb_speciality_type_id", one = @One(select = "com.avatarcn.AppTourists.mapper.SpecialityTypeMapper.selectById", fetchType = FetchType.LAZY))
	})
	Speciality selectByPrimaryKey(@Param(value = "id") Integer id);

	//分页列出所有的商品
	@Select("SELECT * FROM tb_speciality WHERE insale = #{insale} ORDER BY time limit #{offset}, #{pageSize}")
	List<Speciality> selectPage(@Param(value = "insale") Boolean insale, @Param(value = "offset") Integer offset, @Param(value = "pageSize") Integer pageSize);

	//根据类型分页列出所有的商品
	@Select("SELECT * FROM tb_speciality WHERE fk_tb_speciality_type_id = #{fk_tb_speciality_type_id} AND insale = #{insale} ORDER BY time LIMIT #{offset}, #{pageSize}")
	List<Speciality> selectPageByTypeId(@Param(value = "fk_tb_speciality_type_id") Integer fk_tb_speciality_type_id, @Param(value = "insale") Boolean insale, @Param(value = "offset") Integer offset, @Param(value = "pageSize") Integer pageSize);

	@Select("SELECT * FROM tb_speciality WHERE fk_tb_speciality_type_id = #{fk_tb_speciality_type_id}")
	List<Speciality> selectByTypeId(Integer fk_tb_speciality_type_id);

	@Select("SELECT COUNT(*) FROM tb_speciality WHERE insale = #{insale}")
	int count(@Param(value = "insale") Boolean insale);

	@Select("SELECT COUNT(*) FROM tb_speciality WHERE fk_tb_speciality_type_id = #{fk_tb_speciality_type_id} AND insale = #{insale}")
	int countByTypeId(@Param(value = "fk_tb_speciality_type_id") Integer fk_tb_speciality_type_id, @Param(value = "insale") Boolean insale);

	//@Delete("DELETE FROM tb_speciality WHERE id=#{id}")
	//int deleteByPrimaryKey(@Param(value = "id") Integer id);

	//@Delete("DELETE FROM tb_speciality WHERE fk_tb_speciality_type_id = #{fk_tb_speciality_type_id}")
	//int deleteByTypeId(Integer fk_tb_speciality_type_id);
}
