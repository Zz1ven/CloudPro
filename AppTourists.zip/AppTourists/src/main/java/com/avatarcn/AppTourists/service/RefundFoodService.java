package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.mapper.*;
import com.avatarcn.AppTourists.model.OrderFood;
import com.avatarcn.AppTourists.model.RefundFood;
import com.avatarcn.AppTourists.model.RefundStatus;
import com.avatarcn.AppTourists.model.RefundType;
import com.avatarcn.AppTourists.model.user.Account;
import com.avatarcn.AppTourists.utils.MakeOrderUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/13 11:48
 */
@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 60000, rollbackFor = Exception.class)
public class RefundFoodService {

    @Autowired
    private RefundFoodMapper refundFoodMapper;

    @Autowired
    private RefundStatusMapper refundStatusMapper;

    @Autowired
    private RefundTypeMapper refundTypeMapper;

    @Autowired
    private OrderFoodMapper orderFoodMapper;

    @Autowired
    private OrderFoodMenuMapper orderFoodMenuMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private AlipayService alipayService;

    @Autowired
    private WxpayService wxpayService;

    public RefundFood insert(int userId, String reason, String order_number) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        RefundStatus refundStatus = refundStatusMapper.selectById(Constant.REFUND_STATUS_APPLYING);
        if (refundStatus == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_NULL);
        }
        RefundType refundType = refundTypeMapper.selectById(Constant.REFUND_TYPE_REFUND);
        if (refundType == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_TYPE_NULL);
        }
        OrderFood orderFood = orderFoodMapper.selectByNumber(order_number);
        if (orderFood == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        if (orderFood.getFk_tb_order_status_id() != Constant.ORDER_UNUSED ||
                orderFood.getOverdue()) {//订单不可使用或过期
            throw new ErrorCodeException(TouristsErrorCode.REFUND_ORDER_STATUS_INVALID);
        }
        RefundFood refundFood = new RefundFood();
        refundFood.setFk_tb_refund_status_id(Constant.REFUND_STATUS_APPLYING);
        refundFood.setFk_tb_refund_type_id(Constant.REFUND_TYPE_REFUND);
        refundFood.setFk_tb_user_id(account.getId());
        refundFood.setFk_tb_order_food_id(orderFood.getId());
        refundFood.setMoney(orderFood.getReal_money());
        refundFood.setReason(reason);
        refundFood.setOrder_number(order_number);
        refundFood.setOut_request_no(MakeOrderUtil.makeOrderNum(Constant.REFUND_FOOD_ORDER_TYPE));
        refundFood.setPath(orderFood.getPay_method());
        refundFood.setVisible(true);
        refundFood.setCreate_time(new Date());
        refundFoodMapper.insert(refundFood);
        //修改订单状态->售后中
        orderFood.setFk_tb_order_status_id(Constant.ORDER_AFTER_SALE);
        orderFoodMapper.update(orderFood);
        refundFood.setRefundStatus(refundStatus);
        refundFood.setRefundType(refundType);
        refundFood.setOrderFoodMenus(orderFoodMenuMapper.selectAll(orderFood.getId()));
        return refundFood;
    }

    /**
     * 取消指定的售后
     * @param id
     * @return
     */
    public int cancelRefundFood(int id) throws ErrorCodeException {
        RefundFood refundFood = refundFoodMapper.selectById(id);
        if (refundFood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        //售后只能在申请时可以被取消
        if (refundFood.getFk_tb_refund_status_id() != Constant.REFUND_STATUS_APPLYING) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_INVALID);
        }
        //修改订单状态->待使用
        OrderFood orderFood = orderFoodMapper.selectByPrimaryKey(refundFood.getFk_tb_order_food_id());
        orderFood.setFk_tb_order_status_id(Constant.ORDER_UNUSED);
        orderFoodMapper.update(orderFood);
        return refundFoodMapper.updateStatus(id, Constant.REFUND_STATUS_CANCEL);
    }

    /**
     * (后台)处理售后申请是否通过
     * @return
     */
    public String handleRefundFood(int id, boolean handle) throws ErrorCodeException {
        RefundFood refundFood = refundFoodMapper.selectById(id);
        if (refundFood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        if (refundFood.getFk_tb_refund_status_id() != Constant.REFUND_STATUS_APPLYING) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_INVALID);
        }
        if (handle) {
            //进入退款流程
            String result = null;
            refundFoodMapper.updateStatus(id, Constant.REFUND_STATUS_REFUND);
            if (Constant.ALIPAY.equals(refundFood.getPath())) {
                //支付宝退款
                result = alipayService.refundRequest(refundFood.getOrder_number(), refundFood.getMoney(), refundFood.getOut_request_no());
            } else if (Constant.WXPAY.equals(refundFood.getPath())) {
                //微信退款
                result = wxpayService.refundRequest(refundFood.getOrder_number(), refundFood.getMoney(), refundFood.getMoney(), refundFood.getOut_request_no());
            }
            if (!"SUCCESS".equals(result)) {
                throw new ErrorCodeException(new ErrorCode(1, result));
            }
            return result;
        } else {//申请失败
            //修改订单状态->待使用
            OrderFood orderFood = orderFoodMapper.selectByPrimaryKey(refundFood.getFk_tb_order_food_id());
            orderFood.setFk_tb_order_status_id(Constant.ORDER_UNUSED);
            orderFoodMapper.update(orderFood);
            return String.valueOf(refundFoodMapper.updateStatus(id, Constant.REFUND_STATUS_FAILURE));
        }
    }

    /**
     * 查看退款状态
     * @return
     */
    public boolean queryRefundStatus(RefundFood refundFood) {
        boolean successful = false;
        if (Constant.ALIPAY.equals(refundFood.getPath())) {
            successful = alipayService.queryRefundStatus(refundFood.getOrder_number(), refundFood.getOut_request_no());
        } else if (Constant.WXPAY.equals(refundFood.getPath())) {
            successful = wxpayService.queryRefundStatus(refundFood.getOrder_number(), refundFood.getOut_request_no());
        }
        return successful;
    }

    public int deleteById(int id) throws ErrorCodeException {
        RefundFood refundFood = refundFoodMapper.selectById(id);
        if (refundFood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        if (refundFood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_APPLYING ||
                refundFood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {
            //售后状态为申请中或退款中时
            throw new ErrorCodeException(TouristsErrorCode.REFUND_STATUS_INVALID);
        }
        int result;
        if (refundFood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_CANCEL ||
                refundFood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_FAILURE) {
            //取消或失败
            result = refundFoodMapper.delete(id);
        } else {
            //已完成
            result = refundFoodMapper.updateVisible(id, false);
        }
        if (result != 1) {
            throw new ErrorCodeException(ErrorCodeException.DELETE_NO);
        }
        return result;
    }

    public RefundFood selectById(int id) throws ErrorCodeException {
        RefundFood refundFood = refundFoodMapper.selectDetailById(id);
        if (refundFood == null) {
            throw new ErrorCodeException(TouristsErrorCode.REFUND_NULL);
        }
        if (refundFood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {//退款中
            //查看退款状态
            if (queryRefundStatus(refundFood)) {//退款成功
                //修改订单状态->退款成功
                OrderFood orderFood = orderFoodMapper.selectByPrimaryKey(refundFood.getFk_tb_order_food_id());
                orderFood.setFk_tb_order_status_id(Constant.ORDER_REFUND_SUCCESS);
                orderFoodMapper.update(orderFood);
                //修改售后状态->已完成
                refundFood.setFk_tb_refund_status_id(Constant.REFUND_STATUS_SUCCESS);
                refundFood.setRefundStatus(refundStatusMapper.selectById(Constant.REFUND_STATUS_SUCCESS));
                refundFoodMapper.updateStatus(id, Constant.REFUND_STATUS_SUCCESS);
            }
        }
        return refundFood;
    }

    public PageResponse<RefundFood> selectPageByUserId(int userId, int offset, int pageSize) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        List<RefundFood> refundFoodList = refundFoodMapper.selectPageByUserId(account.getId(), offset, pageSize);
        PageResponse<RefundFood> refundFoodPageResponse = new PageResponse<>();
        for (RefundFood refundFood : refundFoodList) {
            if (refundFood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {//退款中
                //查看退款状态
                if (queryRefundStatus(refundFood)) {//退款成功
                    //修改订单状态->退款成功
                    OrderFood orderFood = orderFoodMapper.selectByPrimaryKey(refundFood.getFk_tb_order_food_id());
                    orderFood.setFk_tb_order_status_id(Constant.ORDER_REFUND_SUCCESS);
                    orderFoodMapper.update(orderFood);
                    //修改售后状态->已完成
                    refundFood.setFk_tb_refund_status_id(Constant.REFUND_STATUS_SUCCESS);
                    refundFood.setRefundStatus(refundStatusMapper.selectById(Constant.REFUND_STATUS_SUCCESS));
                    refundFoodMapper.updateStatus(refundFood.getId(), Constant.REFUND_STATUS_SUCCESS);
                }
            }
        }
        refundFoodPageResponse.setItem(refundFoodList);
        refundFoodPageResponse.setOffset(offset);
        refundFoodPageResponse.setPageSize(pageSize);
        refundFoodPageResponse.setTotal(refundFoodMapper.countByUserId(account.getId()));
        return refundFoodPageResponse;
    }

    public PageResponse<RefundFood> selectPage(int offset, int pageSize) {
        List<RefundFood> refundFoodList = refundFoodMapper.selectPage(offset, pageSize);
        PageResponse<RefundFood> refundFoodPageResponse = new PageResponse<>();
        for (RefundFood refundFood : refundFoodList) {
            if (refundFood.getFk_tb_refund_status_id() == Constant.REFUND_STATUS_REFUND) {//退款中
                //查看退款状态
                if (queryRefundStatus(refundFood)) {//退款成功
                    //修改订单状态->退款成功
                    OrderFood orderFood = orderFoodMapper.selectByPrimaryKey(refundFood.getFk_tb_order_food_id());
                    orderFood.setFk_tb_order_status_id(Constant.ORDER_REFUND_SUCCESS);
                    orderFoodMapper.update(orderFood);
                    //修改售后状态->已完成
                    refundFood.setFk_tb_refund_status_id(Constant.REFUND_STATUS_SUCCESS);
                    refundFood.setRefundStatus(refundStatusMapper.selectById(Constant.REFUND_STATUS_SUCCESS));
                    refundFoodMapper.updateStatus(refundFood.getId(), Constant.REFUND_STATUS_SUCCESS);
                }
            }
        }
        refundFoodPageResponse.setItem(refundFoodList);
        refundFoodPageResponse.setOffset(offset);
        refundFoodPageResponse.setPageSize(pageSize);
        refundFoodPageResponse.setTotal(refundFoodMapper.count());
        return refundFoodPageResponse;
    }
}
