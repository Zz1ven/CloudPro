package com.avatarcn.AppTourists.model;

/**
 * Created by z1ven on 2018/3/6 14:22
 */
public class RefundStatus {
    private int id;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
