package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.feign.UserServiceFeign;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.model.SpecialityMenu;
import com.avatarcn.AppTourists.model.SpecialityOrder;
import com.avatarcn.AppTourists.model.user.User;
import com.avatarcn.AppTourists.service.SpecialityOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by z1ven on 2018/3/2 13:51
 */
@Api(value = "/v1/speciality/order", description = "特产商场订单模块")
@RequestMapping(value = "/v1/speciality/order")
@RestController
public class SpecialityOrderController {

    @Autowired
    private SpecialityOrderService specialityOrderService;

    @Autowired
    private UserServiceFeign userServiceFeign;

    @ApiOperation("提交一个特产商城订单")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<SpecialityOrder> addSpecialityOrder(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                        @ApiParam(value = "选择的收货地址主键ID", required = true) @RequestParam(value = "address_id") Integer address_id,
                                                        @ApiParam(value = "特产商品ID和数量的对象", required = true) @RequestBody List<SpecialityMenu> specialityMenus,
                                                        @ApiParam(value = "用户优惠券ID") @RequestParam(value = "coupons_user_id", required = false) Integer coupons_user_id) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.insert(userJsonBean.getData().getId(), Constant.ORDER_WAIT_PAY, address_id, specialityMenus, coupons_user_id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("删除指定的特产商城订单")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonBean<Integer> deleteById(@ApiParam(value = "订单ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.deleteById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定的特产商城订单")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<SpecialityOrder> getSpecialityById(@ApiParam(value = "订单ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.selectById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("根据订单号获取指定的特产商城订单")
    @RequestMapping(value = "/number", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<SpecialityOrder> getSpecialityOrderByNumber(@ApiParam(value = "订单号", required = true) @RequestParam(value = "number") String number) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.getSpecialityOrderByNumber(number));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取指定用户的指定状态的特产商场订单")
    @RequestMapping(value = "/page/{order_status_id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<SpecialityOrder>> getPage(@ApiParam(value = "订单状态ID[0为查找全部]", required = true) @PathVariable(value = "order_status_id") Integer order_status_id,
                                                           @ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                           @ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                           @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.selectPageByUserId(userJsonBean.getData().getId(), order_status_id, offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取所有的特产商城订单")
    @RequestMapping(value = "/page/all", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<SpecialityOrder>> getAllPage(@ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                              @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.selectAllPage(offset, pageSize));
    }

    @ApiOperation("取消订单")
    @RequestMapping(value = "/cancel/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> cancelSpecialityOrder(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                                   @ApiParam(value = "token", required = true) @RequestParam(value = "token") String token) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.cancelSpecialityOrder(userJsonBean.getData().getId(), id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("确认收货")
    @RequestMapping(value = "/receive/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> receiveSpecialityOrder(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                                    @ApiParam(value = "token", required = true) @RequestParam(value = "token") String token) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, specialityOrderService.receiveSpecialityOrder(userJsonBean.getData().getId(), id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }
}
