package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.mapper.AccountMapper;
import com.avatarcn.AppTourists.mapper.RefundGoodMapper;
import com.avatarcn.AppTourists.mapper.SpecialityOrderMapper;
import com.avatarcn.AppTourists.mapper.UserAddressMapper;
import com.avatarcn.AppTourists.model.UserAddress;
import com.avatarcn.AppTourists.model.user.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/1 17:15
 */
@Service
public class UserAddressService {

    @Autowired
    private UserAddressMapper userAddressMapper;

    @Autowired
    private SpecialityOrderMapper specialityOrderMapper;

    @Autowired
    private RefundGoodMapper refundGoodMapper;

    @Autowired
    private AccountMapper accountMapper;

    public UserAddress insert(int userId, String name, String phone, String postalcode, String address, boolean default_tag) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        UserAddress userAddress = new UserAddress();
        userAddress.setFk_tb_user_id(account.getId());
        userAddress.setName(name);
        userAddress.setPhone(phone);
        userAddress.setPostalcode(postalcode);
        userAddress.setAddress(address);
        userAddress.setDefault_tag(false);
        userAddress.setVisible(true);
        userAddress.setTime(new Date());
        userAddress.setDefault_tag(default_tag);
        if (default_tag) {
            userAddressMapper.updateDefaultTag(account.getId(), false);
        }
        userAddressMapper.insert(userAddress);
        return userAddress;
    }

    public int deleteById(int id) throws ErrorCodeException {
        int result;
        //查询地址是否被订单或售后申请使用
        if (specialityOrderMapper.countByAddressId(id) == 0) {
            result = userAddressMapper.deleteById(id);
        } else {
            //删除地址不删除关联对应订单
            //修改地址可见状态
            result = userAddressMapper.updateVisible(id, false);
        }
        if (result != 1) {
            throw new ErrorCodeException(ErrorCodeException.DELETE_NO);
        }
        return result;
    }

    public UserAddress selectById(int id) throws ErrorCodeException {
        UserAddress userAddress = userAddressMapper.selectById(id);
        if (userAddress == null) {
            throw new ErrorCodeException(TouristsErrorCode.USER_ADDRESS_NULL);
        }
        return userAddress;
    }

    public PageResponse<UserAddress> selectPage(int userId, int offset, int pageSize) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        List<UserAddress> userAddressList = userAddressMapper.selectByUserId(account.getId(), offset, pageSize);
        PageResponse<UserAddress> userAddressPageResponse = new PageResponse<>();
        userAddressPageResponse.setItem(userAddressList);
        userAddressPageResponse.setOffset(offset);
        userAddressPageResponse.setPageSize(pageSize);
        userAddressPageResponse.setTotal(userAddressMapper.countByUserId(account.getId()));
        return userAddressPageResponse;
    }

    public UserAddress update(int id, int userId, String name, String phone, String postalcode, String address) throws ErrorCodeException {
        UserAddress userAddress = userAddressMapper.selectById(id);
        if (userAddress == null) {
            throw new ErrorCodeException(TouristsErrorCode.USER_ADDRESS_NULL);
        }
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null || account.getId() != userAddress.getFk_tb_user_id()) {
            throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
        }
        userAddress.setName(name);
        userAddress.setPhone(phone);
        userAddress.setPostalcode(postalcode);
        userAddress.setAddress(address);
        userAddress.setTime(new Date());
        userAddressMapper.update(userAddress);
        return userAddress;
    }

    public UserAddress getDefaultAddress(int userId) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        return userAddressMapper.selectDefaultAddress(account.getId());
    }

    public int updateDefaultTag(int id, int userId) throws ErrorCodeException {
        UserAddress userAddress = userAddressMapper.selectById(id);
        if (userAddress == null) {
            throw new ErrorCodeException(TouristsErrorCode.USER_ADDRESS_NULL);
        }
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null || account.getId() != userAddress.getFk_tb_user_id()) {
            throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
        }
        userAddressMapper.updateDefaultTag(account.getId(), false);
        userAddress.setDefault_tag(true);
        return userAddressMapper.update(userAddress);
    }
}
