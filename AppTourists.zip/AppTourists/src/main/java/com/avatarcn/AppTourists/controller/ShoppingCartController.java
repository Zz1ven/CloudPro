package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.feign.UserServiceFeign;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.model.ShoppingCart;
import com.avatarcn.AppTourists.model.user.User;
import com.avatarcn.AppTourists.service.ShoppingCartService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by z1ven on 2018/3/1 10:32
 */
@Api(value = "/v1/shopping/cart", description = "商城购物车模块")
@RequestMapping(value = "/v1/shopping/cart")
@RestController
public class ShoppingCartController {

    @Autowired
    private ShoppingCartService shoppingCartService;

    @Autowired
    private UserServiceFeign userServiceFeign;

    @ApiOperation("添加一个商品到购物车")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<ShoppingCart> addShoppingCart(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                  @ApiParam(value = "speciality_id", required = true) @RequestParam(value = "speciality_id") Integer speciality_id,
                                                  @ApiParam(value = "数量", required = true) @RequestParam(value = "amount") Integer amount) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, shoppingCartService.insert(userJsonBean.getData().getId(), speciality_id, amount));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("删除指定的购物车商品")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonBean<Integer> deleteById(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, shoppingCartService.deleteShoppingCart(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定用户的购物车商品总数")
    @RequestMapping(value = "/amount", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<Integer> getShoppingCartAmount(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, shoppingCartService.getShoppingCartAmount(userJsonBean.getData().getId()));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("修改指定的购物车商品的数量")
    @RequestMapping(value = "/amount/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> updateShoppingCart(@ApiParam(value = "id", required = true) @PathVariable(value = "id") Integer id,
                                                @ApiParam(value = "数量", required = true) @RequestParam(value = "amount") Integer amount) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, shoppingCartService.updateShoppingCart(id, amount));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定的购物车商品")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<ShoppingCart> getShoppingCartById(@ApiParam(value = "id", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, shoppingCartService.selectById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取指定用户的购物车商品")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<ShoppingCart>> getPageShoppingCart(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                                    @ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                                    @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, shoppingCartService.selectByUserId(userJsonBean.getData().getId(), offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }
}
