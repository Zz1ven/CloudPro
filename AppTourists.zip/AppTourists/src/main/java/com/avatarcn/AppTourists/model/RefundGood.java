package com.avatarcn.AppTourists.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/6 14:46
 */
@JsonIgnoreProperties(value = {"handler"})
public class RefundGood {
    private Integer id;
    private Integer fk_tb_refund_status_id;
    private Integer fk_tb_refund_type_id;
    private Integer fk_tb_user_id;
    private Float money;
    private String reason;
    private String order_number;//关联订单号
    private String out_request_no;//售后订单号
    private String path;
    private String express_company;
    private String express_no;
    private Boolean visible;
    private Date time;

    private RefundStatus refundStatus;
    private RefundType refundType;
    private List<RefundGoodMenu> refundGoodMenuList;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFk_tb_refund_status_id() {
        return fk_tb_refund_status_id;
    }

    public void setFk_tb_refund_status_id(Integer fk_tb_refund_status_id) {
        this.fk_tb_refund_status_id = fk_tb_refund_status_id;
    }

    public Integer getFk_tb_refund_type_id() {
        return fk_tb_refund_type_id;
    }

    public void setFk_tb_refund_type_id(Integer fk_tb_refund_type_id) {
        this.fk_tb_refund_type_id = fk_tb_refund_type_id;
    }

    public Integer getFk_tb_user_id() {
        return fk_tb_user_id;
    }

    public void setFk_tb_user_id(Integer fk_tb_user_id) {
        this.fk_tb_user_id = fk_tb_user_id;
    }

    public Float getMoney() {
        return money;
    }

    public void setMoney(Float money) {
        this.money = money;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getOrder_number() {
        return order_number;
    }

    public void setOrder_number(String order_number) {
        this.order_number = order_number;
    }

    public String getOut_request_no() {
        return out_request_no;
    }

    public void setOut_request_no(String out_request_no) {
        this.out_request_no = out_request_no;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getExpress_company() {
        return express_company;
    }

    public void setExpress_company(String express_company) {
        this.express_company = express_company;
    }

    public String getExpress_no() {
        return express_no;
    }

    public void setExpress_no(String express_no) {
        this.express_no = express_no;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public RefundStatus getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(RefundStatus refundStatus) {
        this.refundStatus = refundStatus;
    }

    public RefundType getRefundType() {
        return refundType;
    }

    public void setRefundType(RefundType refundType) {
        this.refundType = refundType;
    }

    public List<RefundGoodMenu> getRefundGoodMenuList() {
        return refundGoodMenuList;
    }

    public void setRefundGoodMenuList(List<RefundGoodMenu> refundGoodMenuList) {
        this.refundGoodMenuList = refundGoodMenuList;
    }
}
