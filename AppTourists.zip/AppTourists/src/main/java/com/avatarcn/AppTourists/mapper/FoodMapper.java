package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.json.response.FoodResponse;
import com.avatarcn.AppTourists.model.Food;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;


@Mapper
public interface FoodMapper{

	@Insert("INSERT INTO tb_food(fk_tb_food_type_id,name,description,price,rebate_id,img,insale,time) VALUES(#{fk_tb_food_type_id},#{name},#{description},#{price},#{rebate_id},#{img},#{insale},#{time})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	int insert(Food food);

	//@Delete("DELETE FROM tb_food WHERE id=#{id}")
	//int deleteByPrimaryKey(@Param(value = "id") Integer id);

	@Update("UPDATE tb_food SET fk_tb_food_type_id=#{fk_tb_food_type_id},name=#{name},description=#{description},price=#{price},rebate_id=#{rebate_id},img=#{img},insale=#{insale},time=#{time} WHERE id=#{id}")
	int update(Food food);

	@Update("UPDATE tb_food SET insale = #{insale} WHERE id = #{id}")
	int updateSaleStatus(@Param("id") Integer id, @Param("insale") boolean insale);

	@Select("SELECT * FROM tb_food WHERE id = #{id}")
	Food selectByPrimaryKey(@Param(value = "id") Integer id);

	@Select("SELECT * FROM tb_food WHERE fk_tb_food_type_id = #{fk_tb_food_type_id} AND insale = #{insale} ORDER BY time limit #{offset}, #{pageSize}")
	@Results({
			@Result(column="fk_tb_food_type_id", property="fk_tb_food_type_id"),
			@Result(property="foodType", column="fk_tb_food_type_id", one=@One(select="com.avatarcn.AppTourists.mapper.FoodTypeMapper.selectByPrimaryKey",fetchType= FetchType.LAZY))
	})
	List<FoodResponse> selectPage(@Param(value = "fk_tb_food_type_id") Integer fk_tb_food_type_id,
								  @Param(value = "insale") Boolean insale,
								  @Param(value = "offset") Integer offset,
								  @Param(value = "pageSize") Integer pageSize);

	@Select("SELECT * FROM tb_food WHERE fk_tb_food_type_id = #{fk_tb_food_type_id}")
	List<Food> selectByTypeId(@Param(value = "fk_tb_food_type_id") Integer fk_tb_food_type_id);

	@Select("SELECT COUNT(*) FROM tb_food WHERE fk_tb_food_type_id = #{fk_tb_food_type_id} AND insale = #{insale}")
	int count(@Param(value = "fk_tb_food_type_id") Integer fk_tb_food_type_id, @Param(value = "insale") Boolean insale);
}
