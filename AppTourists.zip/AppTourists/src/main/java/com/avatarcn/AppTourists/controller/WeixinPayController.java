package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.WxpayResponse;
import com.avatarcn.AppTourists.service.WxpayService;
import com.avatarcn.AppTourists.utils.ConfigUtil;
import com.avatarcn.AppTourists.utils.PayCommonUtil;
import com.avatarcn.AppTourists.utils.XMLUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.jdom.JDOMException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * Created by MDF on 2018-2-26.
 */
@Api(value = "/v1/pay", description = "微信支付")
@RequestMapping(value = "/v1/wxpay")
@RestController
public class WeixinPayController {
    private Logger logger = LoggerFactory.getLogger(AlipayController.class);
    @Autowired
    private WxpayService wxpayService;

    @ApiOperation(value = "统一下单")
    @RequestMapping(value = "/pay", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Map<String, Object>> wxPay(@ApiParam(value = "订单号", required = true) @RequestParam(value = "number") String number) {

        Map<String, Object> resultMap = new HashMap<String, Object>();

//        int price100 = new BigDecimal("1").multiply(new BigDecimal(100)).intValue();
//        if (price100 <= 0) {
//            resultMap.put("msg", "付款金额错误");
//            resultMap.put("code", "500");
//            return resultMap;
//        }

        try {
            WxpayResponse wxpayResponse = wxpayService.getObejectByNumber(number);
            SortedMap<Object, Object> parameters = new TreeMap<Object, Object>();
            parameters.put("appid", ConfigUtil.APPID);
            parameters.put("mch_id", ConfigUtil.MCH_ID);
            parameters.put("nonce_str", PayCommonUtil.CreateNoncestr());
            parameters.put("body", wxpayResponse.getBody());
            parameters.put("out_trade_no",wxpayResponse.getOut_trade_no()); //订单id
            parameters.put("fee_type", "CNY");
            parameters.put("total_fee", String.valueOf(wxpayResponse.getTotal_fee()));
            parameters.put("spbill_create_ip", "192.168.3.143");
            parameters.put("notify_url", "http://118.31.165.67:8600/app/v1/wxpay/pay/notify");
            parameters.put("trade_type", "APP");
            //设置签名
            String sign = PayCommonUtil.createSign("UTF-8", parameters);
            parameters.put("sign", sign);
            //封装请求参数结束
            String requestXML = PayCommonUtil.getRequestXml(parameters);
            //调用统一下单接口
            String result = PayCommonUtil.httpsRequest(ConfigUtil.UNIFIED_ORDER_URL, "POST", requestXML);
            try {
                /**统一下单接口返回正常的prepay_id，再按签名规范重新生成签名后，将数据传输给APP。参与签名的字段名为appId，partnerId，prepayId，nonceStr，timeStamp，package。注意：package的值格式为Sign=WXPay**/
                Map<String, String> map = XMLUtil.doXMLParse(result);
                if( map !=null&&"SUCCESS".equals(map.get("return_code"))&&"SUCCESS".equals(map.get("result_code"))) {
                    SortedMap<Object, Object> parameterMap2 = new TreeMap<Object, Object>();
                    parameterMap2.put("appid", ConfigUtil.APPID);
                    parameterMap2.put("partnerid", ConfigUtil.MCH_ID);
                    parameterMap2.put("prepayid", map.get("prepay_id"));
                    parameterMap2.put("package", "Sign=WXPay");
                    parameterMap2.put("noncestr", PayCommonUtil.CreateNoncestr());
                    //本来生成的时间戳是13位，但是必须是10位，所以截取了一下
                    parameterMap2.put("timestamp", Long.parseLong(String.valueOf(System.currentTimeMillis()).toString().substring(0, 10)));
                    String sign2 = PayCommonUtil.createSign("UTF-8", parameterMap2);
                    parameterMap2.put("sign", sign2);
                    resultMap.put("msg", parameterMap2);
                }else{
                   // resultMap.put("err_code", map.get("err_code"));
                  //  resultMap.put("err_code_des", map.get("err_code_des"));
                    return new JsonBean<>(new ErrorCode(1,map.get("err_code_des"),false));
                }
            } catch (JDOMException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
        return new JsonBean<>(ErrorCode.SUCCESS,resultMap);
    }

    @ApiOperation("回调地址")
    @RequestMapping(value = "/pay/notify", method = RequestMethod.POST)
    @ResponseBody
    public String payNotify(@RequestParam(value = "notify") String notify) {
        Map<Object, Object> resultMap = new HashMap<Object, Object>();
        try {
            Map<String, String> requestMap = XMLUtil.doXMLParse(notify);
            if (requestMap != null) {
                //boolean flag = wxpayService.checkSign(requestMap);
                String return_code = requestMap.get("return_code");
                String result_code = requestMap.get("result_code");
                if (/*flag && */return_code != null && result_code != null && return_code.equals("SUCCESS") && result_code.equals("SUCCESS")) {
                    String out_trade_no1 = requestMap.get("out_trade_no");
                    String total_amount1 = requestMap.get("total_fee");
                    //验签成功,校验数据
                    if (wxpayService.checkTradeData(out_trade_no1, total_amount1)) {
                        System.out.println("22222222222222");
                        //校验通过
                        //修改订单状态
                        try {
                            if (wxpayService.paySuccess(out_trade_no1)) {
                                System.out.println("333333333333333");
                                resultMap.put("return_code", "SUCCESS");
                                resultMap.put("return_msg", "OK");
                                return PayCommonUtil.getRequestXml(resultMap);
                            }
                        } catch (ErrorCodeException e) {
                            resultMap.put("return_code", "FAIL");
                            resultMap.put("return_msg", e.getErrorCode().getMsg());
                            return e.getErrorCode().getMsg();
                        }
                    }
                    resultMap.put("return_code", "FAIL");
                    resultMap.put("return_msg", "订单号和金额不正确");
                    return PayCommonUtil.getRequestXml(resultMap);
                }
                logger.warn("支付失败,验签异常");
            }
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        resultMap.put("return_code", "FAIL");
        resultMap.put("return_msg", "支付失败");
        return PayCommonUtil.getRequestXml(resultMap);
   }


    @ApiOperation("查询订单支付状态")
    @RequestMapping(value = "/pay/status", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<Map> payStatus(@ApiParam(value = "商户网站唯一订单号", required = true) @RequestParam(value = "out_trade_no") String out_trade_no) {
        SortedMap<Object, Object> parameters = new TreeMap<Object, Object>();
        parameters.put("appid", ConfigUtil.APPID);
        parameters.put("mch_id", ConfigUtil.MCH_ID);
        parameters.put("nonce_str", PayCommonUtil.CreateNoncestr());
        parameters.put("out_trade_no",out_trade_no); //订单id
        //设置签名
        String sign = PayCommonUtil.createSign("UTF-8", parameters);
        parameters.put("sign", sign);
        //封装请求参数结束
        String requestXML = PayCommonUtil.getRequestXml(parameters);
        //调用统一下单接口
        String result = PayCommonUtil.httpsRequest(ConfigUtil.UNIFIED_ORDER_STATUS, "POST", requestXML);
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, XMLUtil.doXMLParse(result));
        } catch (JDOMException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new JsonBean<>(new ErrorCode(1, "解析XML错误"));
    }
}
