package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.feign.UserServiceFeign;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.json.response.RefundDataResponse;
import com.avatarcn.AppTourists.model.RefundGood;
import com.avatarcn.AppTourists.model.SpecialityMenu;
import com.avatarcn.AppTourists.model.user.User;
import com.avatarcn.AppTourists.service.RefundGoodService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by z1ven on 2018/3/7 15:15
 */
@Api(value = "/v1/refund/good", description = "特产商城退款售后模块")
@RequestMapping(value = "/v1/refund/good")
@RestController
public class RefundGoodController {

    @Autowired
    private RefundGoodService refundGoodService;

    @Autowired
    private UserServiceFeign userServiceFeign;

    @ApiOperation("生成售后申请数据")
    @RequestMapping(value = "/data", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<RefundDataResponse> getRefundData(@ApiParam(value = "商品订单号", required = true) @RequestParam(value = "number") String number,
                                                      @ApiParam(value = "售后清单", required = true) @RequestBody List<SpecialityMenu> specialityMenuList,
                                                      @ApiParam(value = "售后类型ID", required = true) @RequestParam(value = "type_id") Integer type_id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.getRefundData(number, specialityMenuList, type_id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("提交一个售后申请")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<RefundGood> addRefundGood(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                              @ApiParam(value = "商品订单号", required = true) @RequestParam(value = "number") String number,
                                              @ApiParam(value = "售后清单", required = true) @RequestBody List<SpecialityMenu> specialityMenuList,
                                              @ApiParam(value = "售后类型ID", required = true) @RequestParam(value = "type_id") Integer type_id,
                                              @ApiParam(value = "退款金额", required = true) @RequestParam(value = "money") float money,
                                              @ApiParam(value = "说明", required = true) @RequestParam(value = "reason") String reason) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.insert(userJsonBean.getData().getId(), Constant.REFUND_STATUS_APPLYING, number, specialityMenuList, type_id, money, reason));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("删除指定的售后申请")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonBean<Integer> deleteRefundGood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.deleteRefundGood(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("是否接受处理指定的售后申请")
    @RequestMapping(value = "/handle/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> handleRefundGood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                              @ApiParam(value = "是否处理该售后申请", required = true) @RequestParam(value = "handle") Boolean handle) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.handleRefundGood(id, handle));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("(售后状态为处理中时)用户提交退货快递信息")
    @RequestMapping(value = "/express/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> commitReturnExpress(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                                 @ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                 @ApiParam(value = "快递公司", required = true) @RequestParam(value = "express_company") String express_company,
                                                 @ApiParam(value = "快递单号", required = true) @RequestParam(value = "express_no") String express_no) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.commitReturnExpress(userJsonBean.getData().getId(), id, express_company, express_no));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("后台确定已收到退货商品(进入退款流程)")
    @RequestMapping(value = "/receive/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<String> backReceiveGood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.backReceiveGood(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("取消售后请求")
    @RequestMapping(value = "/cancel/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> cancelRefundGood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.cancelRefundGood(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定的售后申请")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<RefundGood> getRefundGood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.selectById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取指定用户的售后申请")
    @RequestMapping(value = "/user/page", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<RefundGood>> getPageByUserId(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                              @ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                              @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.selectPageByUserId(userJsonBean.getData().getId(), offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取所有的售后申请")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<RefundGood>> getPage(@ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                      @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundGoodService.selectPage(offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }
}
