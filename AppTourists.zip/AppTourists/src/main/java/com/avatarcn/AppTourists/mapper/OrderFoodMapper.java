package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.OrderFood;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;


@Mapper
public interface OrderFoodMapper{

	@Insert("INSERT INTO tb_order_food(fk_tb_room_time_id,fk_tb_order_status_id,fk_tb_user_id,number,total_money,real_money,pay_method,pay_time,overdue,visible,time) VALUES(#{fk_tb_room_time_id},#{fk_tb_order_status_id},#{fk_tb_user_id},#{number},#{total_money},#{real_money},#{pay_method},#{pay_time},#{overdue},#{visible},#{time})")
	@Options(useGeneratedKeys = true, keyProperty = "id")
	int insert(OrderFood orderFood);

	@Update("UPDATE tb_order_food SET fk_tb_room_time_id=#{fk_tb_room_time_id},fk_tb_order_status_id=#{fk_tb_order_status_id},fk_tb_user_id=#{fk_tb_user_id},number=#{number},total_money=#{total_money},real_money=#{real_money},pay_method=#{pay_method},pay_time=#{pay_time},overdue=#{overdue},visible=#{visible},time=#{time} WHERE id=#{id}")
	int update(OrderFood orderFood);

	@Update("UPDATE tb_order_food SET pay_method = #{pay_method} WHERE number = #{number}")
	int updatePayMethod(@Param("number") String number, @Param("pay_method") String pay_method);

	@Update("UPDATE tb_order_food SET visible = #{visible} WHERE id = #{id}")
	int updateVisible(@Param("id") Integer id, @Param("visible") Boolean visible);

	@Select("SELECT * FROM tb_order_food WHERE id = #{id}")
	OrderFood selectByPrimaryKey(@Param(value = "id") Integer id);

	@Select("SELECT * FROM tb_order_food WHERE number = #{number}")
	OrderFood selectByNumber(String number);

	@Select("SELECT * FROM tb_order_food WHERE id = #{id}")
	@Results({
			@Result(property = "fk_tb_room_time_id", column = "fk_tb_room_time_id"),
			@Result(property = "roomTime", column = "fk_tb_room_time_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RoomTimeMapper.selectByPrimaryKey", fetchType = FetchType.LAZY)),
			@Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
			@Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY)),
			@Result(property = "id", column = "id"),
			@Result(property = "orderFoodMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.OrderFoodMenuMapper.selectAll", fetchType = FetchType.LAZY))
	})
	OrderFood selectCascadeById(@Param(value = "id") Integer id);

	@Select("SELECT * FROM tb_order_food WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1 ORDER BY time DESC limit #{offset},#{pageSize}")
	@Results({
			@Result(property = "fk_tb_room_time_id", column = "fk_tb_room_time_id"),
			@Result(property = "roomTime", column = "fk_tb_room_time_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RoomTimeMapper.selectByPrimaryKey", fetchType = FetchType.LAZY)),
			@Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
			@Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY)),
			@Result(property = "id", column = "id"),
			@Result(property = "orderFoodMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.OrderFoodMenuMapper.selectAll", fetchType = FetchType.LAZY))
	})
	List<OrderFood> selectPageByUserId(@Param("fk_tb_user_id") Integer fk_tb_user_id,@Param(value = "offset") Integer offset,
									   @Param(value = "pageSize") Integer pageSize);

	@Select("SELECT * FROM tb_order_food WHERE fk_tb_user_id = #{fk_tb_user_id} AND fk_tb_order_status_id = #{fk_tb_order_status_id} AND visible = 1 ORDER BY time DESC limit #{offset}, #{pageSize}")
	@Results({
			@Result(property = "fk_tb_room_time_id", column = "fk_tb_room_time_id"),
			@Result(property = "roomTime", column = "fk_tb_room_time_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RoomTimeMapper.selectByPrimaryKey", fetchType = FetchType.LAZY)),
			@Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
			@Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY)),
			@Result(property = "id", column = "id"),
			@Result(property = "orderFoodMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.OrderFoodMenuMapper.selectAll", fetchType = FetchType.LAZY))
	})
	List<OrderFood> selectPageByUserIdAndStatusId(@Param(value = "fk_tb_user_id") Integer fk_tb_user_id, @Param(value = "fk_tb_order_status_id") Integer fk_tb_order_status_id, @Param(value = "offset") Integer offset, @Param(value = "pageSize") Integer pageSize);

	@Select("SELECT * FROM tb_order_food ORDER BY time DESC limit #{offset}, #{pageSize}")
	@Results({
			@Result(property = "fk_tb_room_time_id", column = "fk_tb_room_time_id"),
			@Result(property = "roomTime", column = "fk_tb_room_time_id", one = @One(select = "com.avatarcn.AppTourists.mapper.RoomTimeMapper.selectByPrimaryKey", fetchType = FetchType.LAZY)),
			@Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
			@Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY)),
			@Result(property = "id", column = "id"),
			@Result(property = "orderFoodMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.OrderFoodMenuMapper.selectAll", fetchType = FetchType.LAZY))
	})
	List<OrderFood> selectPage(@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

	@Select("SELECT COUNT(*) FROM tb_order_food WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1")
	int countByUserId(Integer fk_tb_user_id);

	@Select("SELECT COUNT(*) FROM tb_order_food WHERE fk_tb_user_id = #{fk_tb_user_id} AND fk_tb_order_status_id = #{fk_tb_order_status_id} AND visible = 1")
	int countByUserIdAndStatusId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("fk_tb_order_status_id") Integer fk_tb_order_status_id);

	@Select("SELECT COUNT(*) FROM tb_order_food")
	int count();

	@Delete("DELETE FROM tb_order_food WHERE id=#{id}")
	int deleteByPrimaryKey(@Param(value = "id") Integer id);
}
