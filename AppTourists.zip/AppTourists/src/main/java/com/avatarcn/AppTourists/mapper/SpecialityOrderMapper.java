package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.SpecialityOrder;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

/**
 * Created by z1ven on 2018/3/1 16:18
 */
@Mapper
public interface SpecialityOrderMapper {

    @Insert("INSERT INTO tb_order_speciality(fk_tb_user_id, fk_tb_order_status_id, fk_tb_user_address_id, number, total_money, real_money, pay_method, finish_time, visible, pay_time, time) VALUES(#{fk_tb_user_id}, #{fk_tb_order_status_id}, #{fk_tb_user_address_id}, #{number}, #{total_money}, #{real_money}, #{pay_method}, #{finish_time}, #{visible}, #{pay_time}, #{time})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(SpecialityOrder specialityOrder);

    @Delete("DELETE FROM tb_order_speciality WHERE id = #{id}")
    int deleteById(Integer id);

    @Select("SELECT * FROM tb_order_speciality WHERE id = #{id}")
    SpecialityOrder selectById(Integer id);

    @Select("SELECT * FROM tb_order_speciality WHERE id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
            @Result(property = "fk_tb_user_address_id", column = "fk_tb_user_address_id"),
            @Result(property = "specialityOrderMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.SpecialityOrderMenuMapper.selectBySpecialityOrderId", fetchType = FetchType.LAZY)),
            @Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY)),
            @Result(property = "userAddress", column = "fk_tb_user_address_id", one = @One(select = "com.avatarcn.AppTourists.mapper.UserAddressMapper.selectById", fetchType = FetchType.LAZY))
    })
    SpecialityOrder selectDetailById(Integer id);

    @Select("SELECT * FROM tb_order_speciality WHERE number = #{number}")
    SpecialityOrder selectByNumber(String number);

    @Select("SELECT * FROM tb_order_speciality WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1 ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
            @Result(property = "specialityOrderMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.SpecialityOrderMenuMapper.selectBySpecialityOrderId", fetchType = FetchType.LAZY)),
            @Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    List<SpecialityOrder> selectPageByUserId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_order_speciality WHERE fk_tb_user_id = #{fk_tb_user_id} AND fk_tb_order_status_id = #{fk_tb_order_status_id} AND visible = 1 ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
            @Result(property = "specialityOrderMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.SpecialityOrderMenuMapper.selectBySpecialityOrderId", fetchType = FetchType.LAZY)),
            @Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    List<SpecialityOrder> selectPageByUserIdAndStatusId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("fk_tb_order_status_id") Integer fk_tb_order_status_id, @Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_order_speciality ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
            @Result(property = "specialityOrderMenus", column = "id", many = @Many(select = "com.avatarcn.AppTourists.mapper.SpecialityOrderMenuMapper.selectBySpecialityOrderId", fetchType = FetchType.LAZY)),
            @Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    List<SpecialityOrder> selectPage(@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT COUNT(*) FROM tb_order_speciality WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1")
    int countByUserId(Integer fk_tb_user_id);

    @Select("SELECT COUNT(*) FROM tb_order_speciality WHERE fk_tb_user_id = #{fk_tb_user_id} AND fk_tb_order_status_id = #{fk_tb_order_status_id} AND visible = 1")
    int countByUserIdAndStatusId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("fk_tb_order_status_id") Integer fk_tb_order_status_id);

    @Select("SELECT COUNT(*) FROM tb_order_speciality")
    int count();

    @Update("UPDATE tb_order_speciality SET fk_tb_user_id = #{fk_tb_user_id}, fk_tb_order_status_id = #{fk_tb_order_status_id}, fk_tb_user_address_id = #{fk_tb_user_address_id}, number = #{number}, total_money = #{total_money}, real_money = #{real_money}, pay_method = #{pay_method}, finish_time = #{finish_time}, visible = #{visible}, pay_time = #{pay_time}, time = #{time} WHERE id = #{id}")
    int update(SpecialityOrder specialityOrder);

    @Update("UPDATE tb_order_speciality SET visible = #{visible} WHERE id = #{id}")
    int updateVisible(@Param("id") Integer id, @Param("visible") boolean visible);

    @Update("UPDATE tb_order_speciality SET pay_method = #{pay_method} WHERE number = #{number}")
    int updatePayMethod(@Param("number") String number, @Param("pay_method") String pay_method);

    @Select("SELECT COUNT(*) FROM tb_order_speciality WHERE fk_tb_user_address_id = #{fk_tb_user_address_id}")
    int countByAddressId(Integer fk_tb_user_address_id);
}
