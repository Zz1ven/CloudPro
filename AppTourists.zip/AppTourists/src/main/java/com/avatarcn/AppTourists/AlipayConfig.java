package com.avatarcn.AppTourists;

import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by z1ven on 2018/2/26 13:17
 */
@Configuration
public class AlipayConfig {

    @Value("${alipay.appid}")
    private String appid;

    @Value("${alipay.key.public}")
    private String key_public;

    @Value("${alipay.key.private}")
    private String key_private;

    @Value("${alipay.key.alipay}")
    private String key_alipay;

    @Value("${alipay.gateway}")
    private String gateway;

    @Bean
    public AlipayClient alipayClient() {
        return new DefaultAlipayClient(gateway, appid, key_private, "json", "utf-8", key_alipay, "RSA2");
    }
}
