package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.feign.UserServiceFeign;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.model.RefundFood;
import com.avatarcn.AppTourists.model.user.User;
import com.avatarcn.AppTourists.service.RefundFoodService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by z1ven on 2018/3/13 15:22
 */
@Api(value = "/v1/refund/food", description = "餐饮售后模块")
@RequestMapping(value = "/v1/refund/food")
@RestController
public class RefundFoodController {

    @Autowired
    private RefundFoodService refundFoodService;

    @Autowired
    private UserServiceFeign userServiceFeign;

    @ApiOperation("提交一个餐饮订单售后请求")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<RefundFood> addRefundFood(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                              @ApiParam(value = "售后的餐饮订单号", required = true) @RequestParam(value = "order_number") String order_number,
                                              @ApiParam(value = "退款说明", required = true) @RequestParam(value = "reason") String reason) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundFoodService.insert(userJsonBean.getData().getId(), reason, order_number));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("取消指定的售后申请")
    @RequestMapping(value = "/cancel/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> cancelRefundFood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundFoodService.cancelRefundFood(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("(后台)处理售后申请是否通过")
    @RequestMapping(value = "/handle/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<String> handleRefundFood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id,
                                             @ApiParam(value = "是否通过", required = true) @RequestParam(value = "handle") Boolean handle) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundFoodService.handleRefundFood(id, handle));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("删除指定的售后申请")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonBean<Integer> deleteRefundFood(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundFoodService.deleteById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定的售后申请")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<RefundFood> selectById(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundFoodService.selectById(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("指定用户分页获取所有的餐饮售后申请")
    @RequestMapping(value = "/page/user", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<RefundFood>> selectPageByUserId(@ApiParam(value = "token", required = true) @RequestParam(value = "token") String token,
                                                                 @ApiParam(value = "offset") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                                 @ApiParam(value = "pageSize") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, refundFoodService.selectPageByUserId(userJsonBean.getData().getId(), offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取所有的餐饮售后申请")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<RefundFood>> selectPage(@ApiParam(value = "offset") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                         @ApiParam(value = "pageSize") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        return new JsonBean<>(ErrorCode.SUCCESS, refundFoodService.selectPage(offset, pageSize));
    }
}
