package com.avatarcn.AppTourists.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/13 10:15
 */
@JsonIgnoreProperties(value = {"handler"})
public class RefundFood {
    private Integer id;
    private Integer fk_tb_refund_status_id;
    private Integer fk_tb_refund_type_id;
    private Integer fk_tb_user_id;
    private Integer fk_tb_order_food_id;
    private Float money;
    private String reason;
    private String order_number;
    private String out_request_no;
    private String path;
    private Boolean visible;
    private Date create_time;
    private Date refund_time;

    private RefundStatus refundStatus;
    private RefundType refundType;
    private List<OrderFoodMenu> orderFoodMenus;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFk_tb_refund_status_id() {
        return fk_tb_refund_status_id;
    }

    public void setFk_tb_refund_status_id(Integer fk_tb_refund_status_id) {
        this.fk_tb_refund_status_id = fk_tb_refund_status_id;
    }

    public Integer getFk_tb_refund_type_id() {
        return fk_tb_refund_type_id;
    }

    public void setFk_tb_refund_type_id(Integer fk_tb_refund_type_id) {
        this.fk_tb_refund_type_id = fk_tb_refund_type_id;
    }

    public Integer getFk_tb_user_id() {
        return fk_tb_user_id;
    }

    public void setFk_tb_user_id(Integer fk_tb_user_id) {
        this.fk_tb_user_id = fk_tb_user_id;
    }

    public Integer getFk_tb_order_food_id() {
        return fk_tb_order_food_id;
    }

    public void setFk_tb_order_food_id(Integer fk_tb_order_food_id) {
        this.fk_tb_order_food_id = fk_tb_order_food_id;
    }

    public Float getMoney() {
        return money;
    }

    public void setMoney(Float money) {
        this.money = money;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getOrder_number() {
        return order_number;
    }

    public void setOrder_number(String order_number) {
        this.order_number = order_number;
    }

    public String getOut_request_no() {
        return out_request_no;
    }

    public void setOut_request_no(String out_request_no) {
        this.out_request_no = out_request_no;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public Date getRefund_time() {
        return refund_time;
    }

    public void setRefund_time(Date refund_time) {
        this.refund_time = refund_time;
    }

    public RefundStatus getRefundStatus() {
        return refundStatus;
    }

    public void setRefundStatus(RefundStatus refundStatus) {
        this.refundStatus = refundStatus;
    }

    public RefundType getRefundType() {
        return refundType;
    }

    public void setRefundType(RefundType refundType) {
        this.refundType = refundType;
    }

    public List<OrderFoodMenu> getOrderFoodMenus() {
        return orderFoodMenus;
    }

    public void setOrderFoodMenus(List<OrderFoodMenu> orderFoodMenus) {
        this.orderFoodMenus = orderFoodMenus;
    }
}
