package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.feign.UserServiceFeign;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.model.ActiveOrder;
import com.avatarcn.AppTourists.model.user.User;
import com.avatarcn.AppTourists.service.ActiveOrderService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by z1ven on 2018/1/19 17:47
 */
@Api(value = "/v1/active/order", description = "活动订单模块")
@RequestMapping(value = "/v1/active/order")
@RestController
public class ActiveOrderController {

    @Autowired
    private ActiveOrderService activeOrderService;

    @Autowired
    private UserServiceFeign userServiceFeign;

    @ApiOperation("添加活动订单")
    @RequestMapping(value = "", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<ActiveOrder> addActiveOrder(@ApiParam(value = "token", required = true) @RequestParam String token,
                                                @ApiParam(value = "活动ID", required = true) @RequestParam Integer active_id,
                                                @ApiParam(value = "购买数量", required = true) @RequestParam Integer amount,
                                                @ApiParam(value = "游客姓名") @RequestParam(value = "tourist_name", required = false) String tourist_name,
                                                @ApiParam(value = "游客手机号") @RequestParam(value = "tourist_phone", required = false) String tourist_phone,
                                                @ApiParam(value = "用户优惠券ID") @RequestParam(value = "coupons_user_id", required = false) Integer coupons_user_id) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.addActiveOrder(userJsonBean.getData().getId(), active_id, amount, Constant.ORDER_WAIT_PAY, tourist_name, tourist_phone, coupons_user_id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("删除指定的活动订单")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public JsonBean<Integer> deleteActiveOrder(@ApiParam(value = "活动订单ID", required = true) @PathVariable Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.deleteActiveOrder(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("获取指定的活动订单")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<ActiveOrder> getActiveOrder(@ApiParam(value = "活动订单ID", required = true) @PathVariable Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.getActiveOrder(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("根据订单号获取指定的活动订单")
    @RequestMapping(value = "/number", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<ActiveOrder> getActiveOrderByNumber(@ApiParam(value = "订单号", required = true) @RequestParam(value = "number") String number) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.getActiveOrderByNumber(number));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取指定用户的活动订单")
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<ActiveOrder>> getPageActiveOrder(@ApiParam(value = "token", required = true) @RequestParam String token,
                                                                  @ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                                  @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        JsonBean<User> userJsonBean = userServiceFeign.getUser(token);
        if (!userJsonBean.isSuccess()) {
            return new JsonBean<>(new ErrorCode(userJsonBean.getError_code(), userJsonBean.getMsg()));
        }
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.getPageActiveOrder(userJsonBean.getData().getId(), offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("分页获取所有的活动订单")
    @RequestMapping(value = "/page/all", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<PageResponse<ActiveOrder>> getAllPage(@ApiParam(value = "从第几个开始") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
                                                          @ApiParam(value = "每页的个数") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.getPage(offset, pageSize));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    /*@ApiOperation("更新活动订单")
    @RequestMapping(value = "/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonBean<ActiveOrder> updateActiveOrder(@ApiParam(value = "活动订单ID", required = true) @PathVariable Integer id,
                                                   @ApiParam(value = "订单状态ID", required = true) @RequestParam Integer status_id,
                                                   @ApiParam(value = "实际总金额", required = true) @RequestParam Float real_money) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.updateActiveOrder(id, status_id, real_money));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }*/

    @ApiOperation("取消指定的活动订单")
    @RequestMapping(value = "/cancel/{id}", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> cancelActiveOrder(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.cancelActiveOrder(id));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }

    @ApiOperation("使用指定的活动订单")
    @RequestMapping(value = "/use", method = RequestMethod.POST)
    @ResponseBody
    public JsonBean<Integer> useActiveOrder(@ApiParam(value = "订单号", required = true) @RequestParam(value = "number") String number) {
        try {
            return new JsonBean<>(ErrorCode.SUCCESS, activeOrderService.useActiveOrder(number));
        } catch (ErrorCodeException e) {
            return new JsonBean<>(e.getErrorCode());
        }
    }
}
