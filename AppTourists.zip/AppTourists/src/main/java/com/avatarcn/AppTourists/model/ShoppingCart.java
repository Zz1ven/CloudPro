package com.avatarcn.AppTourists.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Date;

/**
 * Created by z1ven on 2018/3/1 09:22
 */
@JsonIgnoreProperties(value = {"handler"})
public class ShoppingCart {
    private int id;
    private int fk_tb_user_id;
    private int fk_tb_speciality_id;
    private int amount;
    private Date time;

    private Speciality speciality;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getFk_tb_user_id() {
        return fk_tb_user_id;
    }

    public void setFk_tb_user_id(int fk_tb_user_id) {
        this.fk_tb_user_id = fk_tb_user_id;
    }

    public int getFk_tb_speciality_id() {
        return fk_tb_speciality_id;
    }

    public void setFk_tb_speciality_id(int fk_tb_speciality_id) {
        this.fk_tb_speciality_id = fk_tb_speciality_id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Speciality getSpeciality() {
        return speciality;
    }

    public void setSpeciality(Speciality speciality) {
        this.speciality = speciality;
    }
}
