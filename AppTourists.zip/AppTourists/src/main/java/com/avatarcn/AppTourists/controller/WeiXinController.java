package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.weixin.JsConfigResponse;
import com.avatarcn.AppTourists.service.WeiXinService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Created by MDF on 2018-2-6.
 */
@Api(value = "/v1/weixin", description = "集成微信公众平台模块")
@RequestMapping(value = "/v1/weixin")
@RestController
@Component
public class WeiXinController {
    @Autowired
    private WeiXinService weiXinService;

    @ApiOperation(value = "获取access_token")
    @RequestMapping(value = "/access_token", method = RequestMethod.GET)
    @ResponseBody
    @Scheduled(fixedRate = 1000 * 60 * 60 * 1)
    public JsonBean<JsConfigResponse> get_AccessToken() {

        return new JsonBean(ErrorCode.SUCCESS, weiXinService.getJsSignature());
    }


    @ApiOperation(value = "通过url获取签名")
    @RequestMapping(value = "/url", method = RequestMethod.GET)
    @ResponseBody
    public JsonBean<Map<String, String>> get_sign(@RequestParam(value = "url", required = true)String url) {

        return new JsonBean(ErrorCode.SUCCESS, weiXinService.getNewJsSignature(url));
    }
}
