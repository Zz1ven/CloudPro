package com.avatarcn.AppTourists.service;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.domain.AlipayTradeAppPayModel;
import com.alipay.api.domain.AlipayTradeFastpayRefundQueryModel;
import com.alipay.api.domain.AlipayTradeRefundApplyModel;
import com.alipay.api.domain.AlipayTradeRefundModel;
import com.alipay.api.request.AlipayTradeFastpayRefundQueryRequest;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.response.AlipayTradeFastpayRefundQueryResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.mapper.ActiveMapper;
import com.avatarcn.AppTourists.mapper.ActiveOrderMapper;
import com.avatarcn.AppTourists.mapper.OrderFoodMapper;
import com.avatarcn.AppTourists.mapper.SpecialityOrderMapper;
import com.avatarcn.AppTourists.model.Active;
import com.avatarcn.AppTourists.model.ActiveOrder;
import com.avatarcn.AppTourists.model.OrderFood;
import com.avatarcn.AppTourists.model.SpecialityOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by z1ven on 2018/2/26 14:00
 */
@Service
public class AlipayService {

    @Autowired
    private AlipayClient alipayClient;

    @Autowired
    private ActiveOrderMapper activeOrderMapper;

    @Autowired
    private ActiveMapper activeMapper;

    @Autowired
    private OrderFoodMapper orderFoodMapper;

    @Autowired
    private SpecialityOrderMapper specialityOrderMapper;

    @Autowired
    private ActiveOrderService activeOrderService;

    @Autowired
    private OrderFoodService orderFoodService;

    @Autowired
    private SpecialityOrderService specialityOrderService;

    private static Logger logger = LoggerFactory.getLogger(AlipayService.class);

    /**
     * 通过订单号获取订单信息
     * @return
     */
    public AlipayTradeAppPayModel getModelByNumber(String number) throws ErrorCodeException {
        AlipayTradeAppPayModel model = new AlipayTradeAppPayModel();
        model.setTimeoutExpress("15m");
        model.setProductCode("QUICK_MSECURITY_PAY");
        ActiveOrder activeOrder = activeOrderMapper.selectByNumber(number);
        if (activeOrder != null) {//活动订单
            if (activeOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_PAY) {
                throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
            }
            Active active = activeMapper.selectById(activeOrder.getFk_tb_active_id());
            model.setBody("武陟山庄-" + (active != null ? active.getName() : ""));
            model.setSubject("订单:" + activeOrder.getNumber());
            model.setOutTradeNo(activeOrder.getNumber());
            model.setTotalAmount(String.valueOf(activeOrder.getReal_money()));
            return model;
        }
        OrderFood orderFood = orderFoodMapper.selectByNumber(number);
        if (orderFood != null) {//餐饮订单
            if (orderFood.getFk_tb_order_status_id() != Constant.ORDER_WAIT_PAY) {
                throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
            }
            model.setBody("武陟山庄-餐饮订单");
            model.setSubject("订单:" + orderFood.getNumber());
            model.setOutTradeNo(orderFood.getNumber());
            model.setTotalAmount(String.valueOf(orderFood.getReal_money()));
            return model;
        }
        //商城订单
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(number);
        if (specialityOrder != null) {//特产商城订单
            if (specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_PAY) {
                throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
            }
            model.setBody("武陟山庄-特产商品订单");
            model.setSubject("订单:" + specialityOrder.getNumber());
            model.setOutTradeNo(specialityOrder.getNumber());
            model.setTotalAmount(String.valueOf(specialityOrder.getReal_money()));
            return model;
        }
        return model;
    }

    /**
     * 异步通知校验
     * 1.校验订单号
     * 2.校验支付金额
     * 3.校验商户ID
     * 4.校验商户AppId
     * @return
     */
    public boolean checkTradeData(String tradeNo, String totalAmount, String originSellerId, String sellerId, String originAppId, String appId) {
        //活动订单
        ActiveOrder activeOrder = activeOrderMapper.selectByNumber(tradeNo);
        if (activeOrder != null
                && totalAmount.equals(String.valueOf(activeOrder.getReal_money()))
                && originSellerId.equals(sellerId)
                && originAppId.equals(appId)) {
            return true;
        }
        //餐饮订单
        OrderFood orderFood = orderFoodMapper.selectByNumber(tradeNo);
        if (orderFood != null
                && totalAmount.equals(String.valueOf(orderFood.getReal_money()))
                && originSellerId.equals(sellerId)
                && originAppId.equals(appId)) {
            return true;
        }
        //商城订单
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(tradeNo);
        if (specialityOrder != null
                && totalAmount.equals(String.valueOf(specialityOrder.getReal_money()))
                && originSellerId.equals(sellerId)
                && originAppId.equals(appId)) {
            return true;
        }
        return false;
    }

    /**
     * 订单支付完成处理
     * @return
     */
    public boolean paySuccess(String number) throws ErrorCodeException {
        //根据订单号查找订单
        //活动订单
        ActiveOrder activeOrder = activeOrderMapper.selectByNumber(number);
        if (activeOrder != null) {
            activeOrderService.payActiveOrder(activeOrder.getId());
            activeOrderMapper.updatePayMethod(number, Constant.ALIPAY);
            return true;
        }
        //餐饮订单
        OrderFood orderFood = orderFoodMapper.selectByNumber(number);
        if (orderFood != null) {
            orderFoodService.payFoodOrder(orderFood.getId());
            orderFoodMapper.updatePayMethod(number, Constant.ALIPAY);
            return true;
        }
        //商城订单
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(number);
        if (specialityOrder != null) {
            specialityOrderService.paySpecialityOrder(specialityOrder.getId());
            specialityOrderMapper.updatePayMethod(number, Constant.ALIPAY);
            //商品销量
            return true;
        }
        return false;
    }

    /**
     * Alipay退款请求
     * @param out_trade_no 商户订单号
     * @param refund_amount 退款金额
     * @param out_request_no 退款单号
     * @return
     */
    public String refundRequest(String out_trade_no, float refund_amount, String out_request_no) {
        AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
        AlipayTradeRefundModel model = new AlipayTradeRefundModel();
        model.setOutTradeNo(out_trade_no);
        model.setRefundAmount(String.valueOf(refund_amount));
        model.setRefundReason("正常退款");
        model.setOutRequestNo(out_request_no);
        request.setBizModel(model);
        try {
            AlipayTradeRefundResponse response = alipayClient.execute(request);
            if (response.isSuccess()) {
                return "SUCCESS";
            } else {
                return response.getSubCode() + ":" + response.getSubMsg();
            }
        } catch (AlipayApiException e) {
            logger.warn(e.getErrCode() + e.getErrMsg());
            return e.getErrCode() + ":" + e.getErrMsg();
        }
    }

    /**
     * Alipay查询退款是否成功
     * @param out_trade_no 商户订单号
     * @param out_request_no 退款单号
     * @return
     */
    public boolean queryRefundStatus(String out_trade_no, String out_request_no) {
        AlipayTradeFastpayRefundQueryRequest request = new AlipayTradeFastpayRefundQueryRequest();
        AlipayTradeFastpayRefundQueryModel model = new AlipayTradeFastpayRefundQueryModel();
        model.setOutTradeNo(out_trade_no);
        model.setOutRequestNo(out_request_no);
        request.setBizModel(model);
        try {
            AlipayTradeFastpayRefundQueryResponse response = alipayClient.execute(request);
            if (response.isSuccess()) {
                if (!response.getTradeNo().isEmpty() && !response.getOutRequestNo().isEmpty()) {//查询到数据
                    //return "SUCCESS";
                    return true;//退款成功
                }
                //return "FAILURE";
            }/* else {
                return response.getSubCode() + ":" + response.getSubMsg();
            }*/
        } catch (AlipayApiException e) {
            logger.warn(e.getErrCode() + e.getErrMsg());
            //return e.getErrCode() + ":" + e.getErrMsg();
        }
        return false;
    }
}
