package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.global.Constant;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.mapper.*;
import com.avatarcn.AppTourists.model.*;
import com.avatarcn.AppTourists.model.user.Account;
import com.avatarcn.AppTourists.utils.MakeOrderUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by z1ven on 2018/3/2 10:49
 */
@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.DEFAULT, timeout = 60000, rollbackFor = Exception.class)
public class SpecialityOrderService {

    @Autowired
    private SpecialityOrderMapper specialityOrderMapper;

    @Autowired
    private SpecialityOrderMenuMapper specialityOrderMenuMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private OrderStatusMapper orderStatusMapper;

    @Autowired
    private UserAddressMapper userAddressMapper;

    @Autowired
    private SpecialityMapper specialityMapper;

    @Autowired
    private CouponsUsersMapper couponsUsersMapper;

    @Autowired
    private CouponsUsersService couponsUsersService;

    /**
     * 创建一个商品的订单
     * @return
     * @throws ErrorCodeException
     */
    public SpecialityOrder insert(Integer userId, Integer statusId, Integer addressId, List<SpecialityMenu> specialityMenus, Integer coupons_user_id) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        OrderStatus orderStatus = orderStatusMapper.selectById(statusId);
        if (orderStatus == null) {
            throw new ErrorCodeException(TouristsErrorCode.STATUS_NULL);
        }
        UserAddress userAddress = userAddressMapper.selectById(addressId);
        if (userAddress == null) {
            throw new ErrorCodeException(TouristsErrorCode.USER_ADDRESS_NULL);
        }
        SpecialityOrder specialityOrder = new SpecialityOrder();
        specialityOrder.setFk_tb_user_id(account.getId());
        specialityOrder.setFk_tb_order_status_id(statusId);
        specialityOrder.setFk_tb_user_address_id(addressId);
        specialityOrder.setNumber(MakeOrderUtil.makeOrderNum(Constant.GOOD_ORDER_TYPE));
        //计算价格
        if (specialityMenus != null && !specialityMenus.isEmpty()) {
            float total_money = 0f;
            float real_money = 0f;
            for (SpecialityMenu specialityMenu : specialityMenus) {
                Speciality speciality = specialityMapper.selectByPrimaryKey(specialityMenu.getSpeciality_id());
                if (speciality == null) {
                    throw new ErrorCodeException(TouristsErrorCode.SPECIALITY_NULL);
                }
                total_money = total_money + speciality.getPrice() * specialityMenu.getAmount();
                real_money = real_money + speciality.getPrice() * specialityMenu.getAmount();
            }
            specialityOrder.setTotal_money(total_money);
            specialityOrder.setReal_money(real_money);
        }
        specialityOrder.setFinish_time(new Date());
        specialityOrder.setVisible(true);
        specialityOrder.setTime(new Date());
        specialityOrderMapper.insert(specialityOrder);
        //使用优惠券
        if (coupons_user_id != null) {
            float realMoney = couponsUsersService.specialityUserCoupons(coupons_user_id, account.getId(), specialityOrder.getId());
            specialityOrder.setReal_money(realMoney);
        }
        //生成订单明细
        if (specialityMenus != null && !specialityMenus.isEmpty()) {
            for (SpecialityMenu menu : specialityMenus) {
                SpecialityOrderMenu specialityOrderMenu = new SpecialityOrderMenu();
                specialityOrderMenu.setFk_tb_order_speciality_id(specialityOrder.getId());
                specialityOrderMenu.setFk_tb_speciality_id(menu.getSpeciality_id());
                specialityOrderMenu.setFk_tb_good_status_id(Constant.GOOD_STATUS_NOPAY);
                specialityOrderMenu.setAmount(menu.getAmount());
                specialityOrderMenuMapper.insert(specialityOrderMenu);
            }
        }
        specialityOrder.setSpecialityOrderMenus(specialityOrderMenuMapper.selectBySpecialityOrderId(specialityOrder.getId()));
        specialityOrder.setOrderStatus(orderStatus);
        specialityOrder.setUserAddress(userAddress);
        return specialityOrder;
    }

    public int deleteById(Integer id) throws ErrorCodeException {
        SpecialityOrder specialityOrder = specialityOrderMapper.selectById(id);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        //订单未完成不允许删除
        if (specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_WAIT_DELIVER
                || specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_WAIT_RECEIVE) {//订单状态为待发货或待收货状态
            throw new ErrorCodeException(TouristsErrorCode.ORDER_UNFINISHED);
        }
        int result;
        //订单未付款
        if (specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_WAIT_PAY
                || specialityOrder.getFk_tb_order_status_id() == Constant.ORDER_CANCEL) {
            //删除该订单使用的优惠券
            //查询该订单记录但未使用的优惠券
            List<CouponsUsers> couponsUsersList = couponsUsersMapper.selectBySpecialityOrderIdAndStatusId(id, Constant.COUPON_UNUSED);
            if (couponsUsersList != null && !couponsUsersList.isEmpty()) {
                for (CouponsUsers couponsUsers : couponsUsersList) {
                    couponsUsers.setFk_tb_order_speciality_id(null);
                    couponsUsersMapper.update(couponsUsers);//取消关联
                }
            }
            couponsUsersMapper.deleteBySpecialityId(id);
            //删除关联清单
            specialityOrderMenuMapper.deleteBySpecialityOrderId(id);
            result = specialityOrderMapper.deleteById(id);
        } else {//订单完成时
            result = specialityOrderMapper.updateVisible(id, false);
        }
        if (result != 1) {
            throw new ErrorCodeException(ErrorCodeException.DELETE_NO);
        }
        return 1;
    }

    public SpecialityOrder selectById(Integer id) throws ErrorCodeException {
        SpecialityOrder specialityOrder = specialityOrderMapper.selectDetailById(id);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        return specialityOrder;
    }

    public PageResponse<SpecialityOrder> selectPageByUserId(Integer userId, Integer fk_tb_order_status_id, Integer offset, Integer pageSize) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        PageResponse<SpecialityOrder> specialityOrderPageResponse = new PageResponse<>();
        List<SpecialityOrder> specialityOrderList;
        if (fk_tb_order_status_id == 0) {
            specialityOrderList = specialityOrderMapper.selectPageByUserId(account.getId(), offset, pageSize);
            specialityOrderPageResponse.setTotal(specialityOrderMapper.countByUserId(account.getId()));
        } else {
            specialityOrderList = specialityOrderMapper.selectPageByUserIdAndStatusId(account.getId(), fk_tb_order_status_id, offset, pageSize);
            specialityOrderPageResponse.setTotal(specialityOrderMapper.countByUserIdAndStatusId(account.getId(), fk_tb_order_status_id));
        }
        specialityOrderPageResponse.setItem(specialityOrderList);
        specialityOrderPageResponse.setOffset(offset);
        specialityOrderPageResponse.setPageSize(pageSize);
        return specialityOrderPageResponse;
    }

    public PageResponse<SpecialityOrder> selectAllPage(Integer offset, Integer pageSize) {
        List<SpecialityOrder> specialityOrderList = specialityOrderMapper.selectPage(offset, pageSize);
        PageResponse<SpecialityOrder> specialityOrderPageResponse = new PageResponse<>();
        specialityOrderPageResponse.setItem(specialityOrderList);
        specialityOrderPageResponse.setOffset(offset);
        specialityOrderPageResponse.setPageSize(pageSize);
        specialityOrderPageResponse.setTotal(specialityOrderMapper.count());
        return specialityOrderPageResponse;
    }

    public SpecialityOrder getSpecialityOrderByNumber(String number) throws ErrorCodeException {
        SpecialityOrder specialityOrder = specialityOrderMapper.selectByNumber(number);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        return selectById(specialityOrder.getId());
    }

    public int cancelSpecialityOrder(Integer userId, Integer id) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        SpecialityOrder specialityOrder = specialityOrderMapper.selectById(id);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        if (account.getId() != specialityOrder.getFk_tb_user_id()) {
            throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
        }
        if (specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_PAY) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
        }
        specialityOrder.setFk_tb_order_status_id(Constant.ORDER_CANCEL);
        return specialityOrderMapper.update(specialityOrder);
    }

    public int receiveSpecialityOrder(Integer userId, Integer id) throws ErrorCodeException {
        Account account = accountMapper.selectByServerId(String.valueOf(userId));
        if (account == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACCOUNT_NULL);
        }
        SpecialityOrder specialityOrder = specialityOrderMapper.selectById(id);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        if (account.getId() != specialityOrder.getFk_tb_user_id()) {
            throw new ErrorCodeException(ErrorCodeException.PARAM_ERROR);
        }
        if (specialityOrder.getFk_tb_order_status_id() != Constant.ORDER_WAIT_RECEIVE) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_STATUS_INVALID);
        }
        specialityOrder.setFk_tb_order_status_id(Constant.ORDER_WAIT_EVALUATE);
        return specialityOrderMapper.update(specialityOrder);
    }

    /**
     * 支付完成后的特产商城订单回调
     * @param id
     * @return
     */
    public boolean paySpecialityOrder(Integer id) throws ErrorCodeException {
        SpecialityOrder specialityOrder = specialityOrderMapper.selectById(id);
        if (specialityOrder == null) {
            throw new ErrorCodeException(TouristsErrorCode.ORDER_NULL);
        }
        List<CouponsUsers> couponsUsersList = couponsUsersMapper.selectBySpecialityOrderId(id);
        for (CouponsUsers couponsUsers : couponsUsersList) {//修改优惠券使用状态
            couponsUsers.setFk_tb_coupons_status_id(Constant.COUPON_USED);
            couponsUsersMapper.update(couponsUsers);
        }
        List<SpecialityOrderMenu> specialityOrderMenus = specialityOrderMenuMapper.selectBySpecialityOrderId(id);
        for (SpecialityOrderMenu specialityOrderMenu : specialityOrderMenus) {//修改购买商品支付状态
            specialityOrderMenu.setFk_tb_good_status_id(Constant.GOOD_STATUS_PAID);
            specialityOrderMenuMapper.update(specialityOrderMenu);
        }
        specialityOrder.setFk_tb_order_status_id(Constant.ORDER_WAIT_DELIVER);
        specialityOrder.setPay_time(new Date());
        specialityOrderMapper.update(specialityOrder);
        return true;
    }
}
