package com.avatarcn.AppTourists.controller;

import com.avatarcn.AppTourists.exception.ErrorCode;
import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.json.JsonBean;
import com.avatarcn.AppTourists.json.response.PageResponse;
import com.avatarcn.AppTourists.model.Speciality;
import com.avatarcn.AppTourists.service.SpecialityService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@Api(value = "/v1/speciality", description = "特产模块")
@RequestMapping(value = "/v1/speciality")
@RestController
public class SpecialityController{
	@Autowired
	private SpecialityService specialityService;

	@ApiOperation(value = "增加Speciality")
	@RequestMapping(value = "",method = RequestMethod.POST)
	@ResponseBody
	public JsonBean<Speciality> Insert(@ApiParam(value = "特产类型ID", required = true) @RequestParam(value = "speciality_type_id") Integer speciality_type_id,
									   @ApiParam(value = "特产名称",required = false)@RequestParam(value = "name",required = false)String name,
									   @ApiParam(value = "价格",required = false)@RequestParam(value = "price",required = false)Float price,
									   @ApiParam(value = "特产图片地址",required = false)@RequestParam(value = "url",required = false)String url,
									   @ApiParam(value = "备注",required = false)@RequestParam(value = "remark",required = false)String remark){
		try{
			return new JsonBean<>(ErrorCode.SUCCESS, specialityService.insert(speciality_type_id,name,price,url,remark));
		}catch(ErrorCodeException e){
			return new JsonBean<>(e.getErrorCode());
		}
	}

	@ApiOperation(value = "修改指定的Speciality")
	@RequestMapping(value = "/{id}",method = RequestMethod.PUT)
	@ResponseBody
	public JsonBean<Speciality> update(@ApiParam(value = "查询主键", required = true)@PathVariable()Integer id,
									   @ApiParam(value = "特产类型ID", required = true) @RequestParam(value = "speciality_type_id") Integer speciality_type_id,
	                                   @ApiParam(value = "名称",required = false)@RequestParam(value = "name",required = false)String name,
	                                   @ApiParam(value = "价格",required = false)@RequestParam(value = "price",required = false)Float price,
	                                   @ApiParam(value = "图片地址",required = false)@RequestParam(value = "url",required = false)String url,
	                                   @ApiParam(value = "备注",required = false)@RequestParam(value = "remark",required = false)String remark){
		try{
			return new JsonBean<>(ErrorCode.SUCCESS, specialityService.update(id,speciality_type_id,name,price,url,remark));
		}catch(ErrorCodeException e){
			return new JsonBean<>(e.getErrorCode());
		}
	}

	@ApiOperation(value = "上架指定的特产商品")
	@RequestMapping(value = "/insale/{id}",method = RequestMethod.PUT)
	@ResponseBody
	public JsonBean<Speciality> updateInsale(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
		try {
			return new JsonBean<>(ErrorCode.SUCCESS, specialityService.updateInsale(id, true));
		} catch (ErrorCodeException e) {
			return new JsonBean<>(e.getErrorCode());
		}
	}

	@ApiOperation(value = "下架指定的特产商品")
	@RequestMapping(value = "/offsale/{id}",method = RequestMethod.PUT)
	@ResponseBody
	public JsonBean<Speciality> updateOffsale(@ApiParam(value = "主键ID", required = true) @PathVariable(value = "id") Integer id) {
		try {
			return new JsonBean<>(ErrorCode.SUCCESS, specialityService.updateInsale(id, false));
		} catch (ErrorCodeException e) {
			return new JsonBean<>(e.getErrorCode());
		}
	}

	@ApiOperation(value = "获取指定的Speciality")
	@RequestMapping(value = "/{id}",method = RequestMethod.GET)
	@ResponseBody
	public JsonBean<Speciality> selectByPrimaryKey(@ApiParam(value = "查询主键", required = true)@PathVariable()Integer id){
		try{
			return new JsonBean<>(ErrorCode.SUCCESS, specialityService.selectByPrimaryKey(id));
		}catch(ErrorCodeException e){
			return new JsonBean<>(e.getErrorCode());
		}
	}

	@ApiOperation(value = "分页列出所有的Speciality")
	@RequestMapping(value = "/page",method = RequestMethod.GET)
	@ResponseBody
	public JsonBean<PageResponse<Speciality>> selectPage(@ApiParam(value = "是否只获取在售的商品", required = true) @RequestParam(value = "insale") boolean insale,
														 @ApiParam(value = "从第几个开始列出") @RequestParam(required = false, defaultValue = "0")Integer offset,
														 @ApiParam(value = "每页内容数量") @RequestParam(required = false, defaultValue = "10")Integer pageSize){
		return new JsonBean<>(ErrorCode.SUCCESS, specialityService.selectPage(offset,pageSize, insale));
	}

	@ApiOperation(value = "根据类型分页获取Speciality")
	@RequestMapping(value = "/page/{speciality_type_id}", method = RequestMethod.GET)
	@ResponseBody
	public JsonBean<PageResponse<Speciality>> selectPageByTypeId(@ApiParam(value = "特产类型ID", required = true) @PathVariable(value = "speciality_type_id") Integer speciality_type_id,
																 @ApiParam(value = "是否只获取在售的商品", required = true) @RequestParam(value = "insale") boolean insale,
																 @ApiParam(value = "从第几个开始列出") @RequestParam(value = "offset", required = false, defaultValue = "0") Integer offset,
																 @ApiParam(value = "每页内容数量") @RequestParam(value = "pageSize", required = false, defaultValue = "10") Integer pageSize) {
		return new JsonBean<>(ErrorCode.SUCCESS, specialityService.selectPageByType(speciality_type_id, offset, pageSize, insale));
	}

	/*@ApiOperation(value = "删除指定的Speciality")
	@RequestMapping(value = "/{id}",method = RequestMethod.DELETE)
	@ResponseBody
	public JsonBean deletePrimaryKey(@ApiParam(value = "查询主键", required = true)@PathVariable()Integer id){
		return new JsonBean<>(ErrorCode.SUCCESS, specialityService.deleteByPrimaryKey(id));
	}*/

}
