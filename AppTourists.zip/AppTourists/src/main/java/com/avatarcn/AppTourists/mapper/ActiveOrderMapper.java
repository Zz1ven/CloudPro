package com.avatarcn.AppTourists.mapper;

import com.avatarcn.AppTourists.model.ActiveOrder;
import org.apache.ibatis.annotations.*;
import org.apache.ibatis.mapping.FetchType;

import java.util.List;

/**
 * Created by z1ven on 2018/1/19 15:53
 */
@Mapper
public interface ActiveOrderMapper {

    @Insert("INSERT INTO tb_order_active(fk_tb_active_id, fk_tb_user_id, fk_tb_order_status_id, number, amount, available, total_money, real_money, tourist_name, tourist_phone, pay_method, pay_time, visible, time) VALUES(#{fk_tb_active_id}, #{fk_tb_user_id}, #{fk_tb_order_status_id}, #{number}, #{amount}, #{available}, #{total_money}, #{real_money}, #{tourist_name}, #{tourist_phone}, #{pay_method}, #{pay_time}, #{visible}, #{time})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(ActiveOrder activeOrder);

    @Delete("DELETE FROM tb_order_active WHERE id = #{id}")
    int deleteById(Integer id);

    @Select("SELECT * FROM tb_order_active WHERE id = #{id}")
    ActiveOrder selectById(Integer id);

    @Select("SELECT * FROM tb_order_active WHERE id = #{id}")
    @Results({
            @Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
            @Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    ActiveOrder selectCascadeById(Integer id);

    @Select("SELECT * FROM tb_order_active WHERE number = #{number}")
    ActiveOrder selectByNumber(String number);

    @Select("SELECT * FROM tb_order_active WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1 ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
            @Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    List<ActiveOrder> selectPageByUserId(@Param("fk_tb_user_id") Integer fk_tb_user_id, @Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_order_active ORDER BY time DESC LIMIT #{offset}, #{pageSize}")
    @Results({
            @Result(property = "fk_tb_order_status_id", column = "fk_tb_order_status_id"),
            @Result(property = "orderStatus", column = "fk_tb_order_status_id", one = @One(select = "com.avatarcn.AppTourists.mapper.OrderStatusMapper.selectById", fetchType = FetchType.LAZY))
    })
    List<ActiveOrder> selectPage(@Param("offset") Integer offset, @Param("pageSize") Integer pageSize);

    @Select("SELECT * FROM tb_order_active WHERE fk_tb_active_id = #{fk_tb_active_id}")
    List<ActiveOrder> selectByActiveId(Integer fk_tb_active_id);

    @Select("SELECT COUNT(*) FROM tb_order_active WHERE fk_tb_user_id = #{fk_tb_user_id} AND visible = 1")
    int countByUserId(Integer fk_tb_user_id);

    @Select("SELECT COUNT(*) FROM tb_order_active")
    int count();

    @Update("UPDATE tb_order_active SET fk_tb_active_id = #{fk_tb_active_id}, fk_tb_user_id = #{fk_tb_user_id}, fk_tb_order_status_id = #{fk_tb_order_status_id}, number = #{number}, amount = #{amount}, available = #{available}, total_money = #{total_money}, real_money = #{real_money}, tourist_name = #{tourist_name}, tourist_phone = #{tourist_phone}, pay_method = #{pay_method}, pay_time = #{pay_time}, visible = #{visible}, time = #{time} WHERE id = #{id}")
    int update(ActiveOrder activeOrder);

    @Update("UPDATE tb_order_active SET pay_method = #{pay_method} WHERE number = #{number}")
    int updatePayMethod(@Param("number") String number, @Param("pay_method") String pay_method);

    @Update("UPDATE tb_order_active SET visible = #{visible} WHERE id = #{id}")
    int updateVisible(@Param("id") Integer id, @Param("visible") Boolean visible);
}
