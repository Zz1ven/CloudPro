package com.avatarcn.AppTourists.service;

import com.avatarcn.AppTourists.exception.ErrorCodeException;
import com.avatarcn.AppTourists.exception.TouristsErrorCode;
import com.avatarcn.AppTourists.mapper.ActiveMapper;
import com.avatarcn.AppTourists.mapper.ActiveRemarkMapper;
import com.avatarcn.AppTourists.mapper.RemarkMapper;
import com.avatarcn.AppTourists.model.ActiveRemark;
import com.avatarcn.AppTourists.model.Remark;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by z1ven on 2018/1/20 09:25
 */
@Service
public class ActiveRemarkService {

    @Autowired
    private ActiveRemarkMapper activeRemarkMapper;

    @Autowired
    private ActiveMapper activeMapper;

    @Autowired
    private RemarkMapper remarkMapper;

    public ActiveRemark addActiveRemark(Integer activeId, Integer remarkId) throws ErrorCodeException {
        if (activeMapper.selectById(activeId) == null) {
            throw new ErrorCodeException(TouristsErrorCode.ACTIVE_NULL);
        }
        Remark remark = remarkMapper.selectById(remarkId);
        if (remark == null) {
            throw new ErrorCodeException(ErrorCodeException.DATA_NO_ERROR);
        }
        ActiveRemark activeRemark = activeRemarkMapper.selectByActiveIdAndRemarkId(activeId, remarkId);
        if (activeRemark == null) {
            activeRemark = new ActiveRemark();
            activeRemark.setFk_tb_active_id(activeId);
            activeRemark.setFk_tb_remark_id(remarkId);
            activeRemarkMapper.insert(activeRemark);
            activeRemark.setRemark_name(remark.getName());
            return activeRemark;
        }
        return activeRemark;
    }

    public int deleteActiveRemark(Integer activeId, Integer remarkId) throws ErrorCodeException {
        return activeRemarkMapper.deleteByRemarkIdAndActiveId(remarkId, activeId);
    }
}
